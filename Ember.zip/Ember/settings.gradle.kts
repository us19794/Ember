pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        // GeckoView comes only from Mozilla's repository
        exclusiveContent {
            forRepository { maven("https://maven.mozilla.org/maven2/") }
            filter { includeGroupByRegex("org\\.mozilla.*") }
        }
        google()
        mavenCentral()
    }
}
rootProject.name = "Ember"
include(":app")
