plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Single place to bump the Gecko engine (release channel, arm64 only).
val geckoVersion = "159.0.20261022150525"

android {
    namespace = "app.ember.browser"
    compileSdk = 36

    defaultConfig {
        applicationId = "app.ember.browser"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "0.3.0"
        ndk { abiFilters += "arm64-v8a" }
    }

    buildTypes {
        debug {
            // The CI build is the one you install, so make it behave like a release build:
            // a debuggable app runs Compose far slower and drops frames.
            isDebuggable = false
            isMinifyEnabled = false
        }
    }

    // GeckoView needs Java 17 APIs
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        // GeckoView ships newer Kotlin metadata than our compiler; read it anyway
        freeCompilerArgs += "-Xskip-metadata-version-check"
    }
    buildFeatures { compose = true }

    // keep the "_locales" folder of the bundled uBlock Origin (the default pattern drops "_*" dirs)
    androidResources {
        ignoreAssetsPattern = "!.svn:!.git:!.ds_store:!*.scc:.*:!CVS:!thumbs.db:!picasa.ini:!*~"
    }
}

dependencies {
    implementation("org.mozilla.geckoview:geckoview-arm64-v8a:$geckoVersion")

    implementation(platform("androidx.compose:compose-bom:2025.05.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation-core")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.core:core-ktx:1.16.0")
}

// GeckoView 159 declares "compile against Android API 37+", but AGP 8.11 tops out
// at API 36. The check is metadata-only (nothing breaks at build or run time),
// so skip it and keep compiling against 36.
tasks.configureEach {
    if (name.startsWith("check") && name.endsWith("AarMetadata")) enabled = false
}
