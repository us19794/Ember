package app.ember.browser

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Icons drawn as 7x7 dot-matrix glyphs, in the same visual language as the
 * Nothing icon pack: lit dots are the glyph, unlit dots stay faintly visible.
 */
object DotIcons {
    val Back = listOf(
        ".......",
        "...#...",
        "..#....",
        ".######",
        "..#....",
        "...#...",
        "......."
    )
    val Forward = listOf(
        ".......",
        "...#...",
        "....#..",
        "######.",
        "....#..",
        "...#...",
        "......."
    )
    val Reload = listOf(
        "..###.#",
        ".#...##",
        "#....##",
        "#......",
        "#.....#",
        ".#...#.",
        "..###.."
    )
    val Close = listOf(
        "#.....#",
        ".#...#.",
        "..#.#..",
        "...#...",
        "..#.#..",
        ".#...#.",
        "#.....#"
    )
    val More = listOf(
        ".......",
        "...#...",
        ".......",
        "...#...",
        ".......",
        "...#...",
        "......."
    )
    val Home = listOf(
        "...#...",
        "..###..",
        ".#####.",
        "#######",
        ".#...#.",
        ".#...#.",
        ".#####."
    )
    val Palette = listOf(
        "..###..",
        ".#...#.",
        "#.#.#.#",
        "#.....#",
        "#..#..#",
        ".#...#.",
        "..###.."
    )
    val Check = listOf(
        ".......",
        "......#",
        ".....#.",
        "#...#..",
        ".#.#...",
        "..#....",
        "......."
    )
}

@Composable
fun DotIcon(
    pattern: List<String>,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
    iconSize: Dp = 24.dp
) {
    Canvas(modifier.size(iconSize)) {
        val cell = this.size.minDimension / 7f
        val radius = cell * 0.34f
        for (y in 0 until 7) {
            for (x in 0 until 7) {
                val lit = pattern.getOrNull(y)?.getOrNull(x) == '#'
                drawCircle(
                    color = if (lit) tint else tint.copy(alpha = 0.14f),
                    radius = radius,
                    center = Offset((x + 0.5f) * cell, (y + 0.5f) * cell)
                )
            }
        }
    }
}
