package app.ember.browser

import android.content.Context
import android.graphics.Color
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class WebRule(val matches: List<String>, val css: String)

/**
 * A mod is a small JSON file anyone can write and share:
 *   ui  - optional: sets how Ember itself looks (accent, black background, glass bar, tab layout)
 *   web - optional: CSS that restyles websites matching the given address patterns
 */
class Mod(
    val id: String,
    val name: String,
    val author: String,
    val version: String,
    val description: String,
    val ui: JSONObject?,
    val web: List<WebRule>,
    val builtIn: Boolean
) {
    fun toJson(): String {
        val o = JSONObject()
        o.put("ember_mod", 1)
        o.put("id", id)
        o.put("name", name)
        o.put("author", author)
        o.put("version", version)
        o.put("description", description)
        if (ui != null) o.put("ui", ui)
        if (web.isNotEmpty()) {
            val arr = JSONArray()
            web.forEach { r ->
                arr.put(JSONObject().put("match", JSONArray(r.matches)).put("css", r.css))
            }
            o.put("web", arr)
        }
        return o.toString(2)
    }
}

object ModFormat {
    private const val MAX_CHARS = 300_000
    private val layouts = setOf("cards", "top", "vertical", "list")

    fun slug(name: String): String =
        name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "mod" }

    /** Reads a mod from JSON text. Throws IllegalArgumentException with a plain-language reason. */
    fun parse(text: String): Mod {
        if (text.length > MAX_CHARS) throw IllegalArgumentException("That mod is too big.")
        val o = try {
            JSONObject(text.trim())
        } catch (e: Exception) {
            throw IllegalArgumentException("That isn't valid mod JSON.")
        }
        val name = o.optString("name").trim()
        if (name.isEmpty()) throw IllegalArgumentException("The mod needs a \"name\".")
        val id = o.optString("id").trim().ifEmpty { slug(name) }

        val ui = o.optJSONObject("ui")
        if (ui != null) {
            val accent = ui.optString("accent")
            if (accent.isNotEmpty()) {
                try { Color.parseColor(accent) } catch (e: Exception) {
                    throw IllegalArgumentException("\"accent\" must be a colour like #FF6A2B.")
                }
            }
            val layout = ui.optString("tabLayout")
            if (layout.isNotEmpty() && layout !in layouts) {
                throw IllegalArgumentException("\"tabLayout\" must be cards, top, vertical or list.")
            }
        }

        val web = ArrayList<WebRule>()
        val arr = o.optJSONArray("web")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val r = arr.optJSONObject(i) ?: continue
                val m = r.opt("match")
                val matches = when (m) {
                    is JSONArray -> (0 until m.length()).map { m.getString(it) }
                    is String -> listOf(m)
                    else -> emptyList()
                }
                val css = r.optString("css")
                if (matches.isNotEmpty() && css.isNotBlank()) web.add(WebRule(matches, css))
            }
        }
        if (ui == null && web.isEmpty()) {
            throw IllegalArgumentException("The mod doesn't change anything. Add \"ui\" or \"web\".")
        }
        return Mod(
            id, name,
            o.optString("author").ifBlank { "Unknown" },
            o.optString("version").ifBlank { "1" },
            o.optString("description"),
            ui, web, false
        )
    }

    // Address patterns look like: scheme://host/path with "*" as a wildcard, or <all_urls> for every site.
    fun matches(pattern: String, url: String): Boolean {
        if (pattern == "<all_urls>" || pattern == "*") return url.startsWith("http://") || url.startsWith("https://")
        val sep = pattern.indexOf("://")
        if (sep < 0) return false
        val scheme = pattern.substring(0, sep)
        var rest = pattern.substring(sep + 3)
        val sb = StringBuilder("^")
        sb.append(if (scheme == "*") "https?" else Regex.escape(scheme)).append("://")
        if (rest.startsWith("*.")) {
            sb.append("([^/]*\\.)?")
            rest = rest.substring(2)
        }
        sb.append(rest.split("*").joinToString(".*") { Regex.escape(it) })
        sb.append("$")
        return try { Regex(sb.toString()).matches(url) } catch (e: Exception) { false }
    }
}

/** Mods that come with Ember. */
object PrebuiltMods {
    private fun look(id: String, name: String, desc: String, accent: String, amoled: Boolean, glass: Boolean) =
        Mod(
            id, name, "Ember", "1", desc,
            JSONObject().put("accent", accent).put("amoled", amoled).put("glass", glass),
            emptyList(), true
        )

    private fun page(id: String, name: String, desc: String, match: String, css: String) =
        Mod(id, name, "Ember", "1", desc, null, listOf(WebRule(listOf(match), css.trim())), true)

    val all: List<Mod> = listOf(
        look("look-ember-classic", "Ember classic", "The original orange on black.", "#FF6A2B", true, false),
        look("look-midnight-glass", "Midnight glass", "Cool blue accent with the see-through glass bar.", "#7C9CFF", true, true),
        look("look-sakura", "Sakura", "Soft pink accent, glass bar on.", "#FF7BA9", true, true),
        look("look-moss", "Moss", "Calm green on pure black.", "#7BD88F", true, false),
        look("look-gold-dusk", "Gold dusk", "Warm gold on dark grey instead of pure black.", "#FFC24D", false, false),

        page(
            "page-dark-pages", "Dark pages",
            "Turns every website dark. Images and videos keep their colours.",
            "<all_urls>",
            """
            html{filter:invert(1) hue-rotate(180deg)!important;background:#fff}
            img,picture,video,canvas,iframe,svg image,[style*="background-image"]{filter:invert(1) hue-rotate(180deg)!important}
            """
        ),
        page(
            "page-comfort-text", "Comfort text",
            "Roomier lines for easier reading on every site.",
            "<all_urls>",
            """
            p,li,blockquote,dd{line-height:1.65!important}
            """
        ),
        page(
            "page-minimal", "Minimal pages",
            "Hides footers and side columns for a quieter page.",
            "<all_urls>",
            """
            footer,aside,[role="complementary"],[role="contentinfo"]{display:none!important}
            """
        ),
        page(
            "page-no-banners", "Cookie banner hider",
            "Hides most cookie pop-ups and frees the page to scroll (best effort).",
            "<all_urls>",
            """
            #onetrust-banner-sdk,#onetrust-consent-sdk,#CybotCookiebotDialog,#CybotCookiebotDialogBodyUnderlay,
            .cc-window,.cc-banner,.cookie-banner,.cookie-notice,.cookie-consent,.cookieconsent,#cookie-banner,
            #cookie-notice,#cookieConsent,#gdpr-banner,.gdpr-banner,.fc-consent-root,#didomi-host,
            #truste-consent-track,.qc-cmp2-container,.osano-cm-window,#usercentrics-root,
            [id^="sp_message_container"],[class*="CookieConsent"]{display:none!important}
            html,body{overflow:auto!important}
            """
        ),
        page(
            "page-calm-youtube", "Calm YouTube",
            "Hides Shorts shelves and links on YouTube (best effort, YouTube changes often).",
            "*://*.youtube.com/*",
            """
            ytm-reel-shelf-renderer,ytd-reel-shelf-renderer,ytm-shorts-lockup-view-model,
            ytm-shorts-lockup-view-model-v2,ytd-rich-shelf-renderer[is-shorts],a[href^="/shorts"]{display:none!important}
            """
        ),
        page(
            "page-wikipedia", "Wikipedia reading mode",
            "Serif text, roomier lines and no edit links on Wikipedia.",
            "*://*.wikipedia.org/*",
            """
            body{font-family:Georgia,'Noto Serif',serif!important}
            .mw-parser-output p,.mw-parser-output li{line-height:1.7!important}
            .mw-editsection,.mw-editsection-bracket{display:none!important}
            """
        )
    )
}

/** Fetches small text files for importing mods and registries. */
object ModsNet {
    fun fetch(url: String): String {
        if (!(url.startsWith("https://") || url.startsWith("http://"))) {
            throw IllegalArgumentException("Use a web link that starts with https://")
        }
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "Ember/0.4")
        if (c.responseCode !in 200..299) throw IllegalStateException("The server said " + c.responseCode)
        val text = c.inputStream.bufferedReader().use { r ->
            val buf = CharArray(8192)
            val sb = StringBuilder()
            while (true) {
                val n = r.read(buf)
                if (n < 0) break
                sb.append(buf, 0, n)
                if (sb.length > 400_000) throw IllegalArgumentException("That file is too big.")
            }
            sb.toString()
        }
        return text
    }
}

class RegistryItem(val name: String, val author: String, val description: String, val url: String)

/** Installed mods and which ones are switched on. */
class ModStore(context: Context, private val prefs: EmberPrefs) {
    private val file = File(context.filesDir, "mods.json")
    private val sp = context.getSharedPreferences("ember_mods", Context.MODE_PRIVATE)

    val imported = mutableStateListOf<Mod>()
    private val enabled = mutableStateMapOf<String, Boolean>()

    val all: List<Mod> get() = PrebuiltMods.all + imported

    init {
        try {
            if (file.exists()) {
                val arr = JSONArray(file.readText())
                for (i in 0 until arr.length()) {
                    try { imported.add(ModFormat.parse(arr.getString(i))) } catch (e: Exception) { }
                }
            }
        } catch (e: Exception) {
        }
        sp.getStringSet("enabled", emptySet())?.forEach { enabled[it] = true }
    }

    fun isEnabled(id: String): Boolean = enabled[id] == true

    fun setEnabled(mod: Mod, on: Boolean) {
        if (on && mod.ui != null) {
            // only one look at a time
            all.filter { it.ui != null && it.id != mod.id }.forEach { enabled[it.id] = false }
            applyLook(mod.ui)
        }
        enabled[mod.id] = on
        persistEnabled()
    }

    private fun applyLook(ui: JSONObject) {
        val accent = ui.optString("accent")
        if (accent.isNotEmpty()) {
            prefs.updateSeed(Color.parseColor(accent))
            prefs.updateDynamic(false)
        }
        if (ui.has("amoled")) prefs.updateAmoled(ui.optBoolean("amoled", true))
        if (ui.has("glass")) prefs.setToggle(K_GLASS, ui.optBoolean("glass", false))
        val layout = ui.optString("tabLayout")
        if (layout.isNotEmpty()) prefs.updateTabLayout(layout)
    }

    /** Returns a plain-language problem, or null when the mod was added. */
    fun import(text: String): String? {
        val mod = try { ModFormat.parse(text) } catch (e: IllegalArgumentException) { return e.message }
        if (PrebuiltMods.all.any { it.id == mod.id }) return "That id is already used by a built-in mod. Change \"id\"."
        imported.removeAll { it.id == mod.id }
        imported.add(0, mod)
        persistImports()
        return null
    }

    fun remove(mod: Mod) {
        imported.remove(mod)
        enabled.remove(mod.id)
        persistImports()
        persistEnabled()
    }

    /** Styles for a page: every switched-on mod rule whose pattern matches. */
    fun cssFor(url: String): String {
        val sb = StringBuilder()
        for (m in all) {
            if (!isEnabled(m.id)) continue
            for (r in m.web) {
                if (r.matches.any { ModFormat.matches(it, url) }) sb.append(r.css).append('\n')
            }
        }
        return sb.toString()
    }

    private fun persistEnabled() {
        sp.edit().putStringSet("enabled", enabled.filter { it.value }.keys.toSet()).apply()
    }

    private fun persistImports() {
        try {
            val arr = JSONArray()
            imported.forEach { arr.put(it.toJson()) }
            file.writeText(arr.toString())
        } catch (e: Exception) {
        }
    }

    companion object {
        /** Reads a registry: a JSON list of {name, author, description, url}. */
        fun parseRegistry(text: String): List<RegistryItem> {
            val t = text.trim()
            val arr = try {
                if (t.startsWith("[")) JSONArray(t) else JSONObject(t).optJSONArray("mods") ?: JSONArray()
            } catch (e: Exception) {
                throw IllegalArgumentException("That isn't a mod list.")
            }
            val out = ArrayList<RegistryItem>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val url = o.optString("url")
                val name = o.optString("name")
                if (url.isNotBlank() && name.isNotBlank()) {
                    out.add(RegistryItem(name, o.optString("author").ifBlank { "Unknown" }, o.optString("description"), url))
                }
            }
            return out
        }
    }
}
