package app.ember.browser

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import kotlin.math.max

/** Phone tilt, smoothed, from -1 to 1 on each axis. Only listens while it is used and enabled. */
@Composable
fun rememberTilt(enabled: Boolean): State<Offset> {
    val ctx = LocalContext.current
    val tilt = remember { mutableStateOf(Offset.Zero) }
    DisposableEffect(enabled) {
        if (!enabled) return@DisposableEffect onDispose { }
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val x = (-e.values[0] / 9.8f).coerceIn(-1f, 1f)
                val y = (e.values[2] / 9.8f).coerceIn(-1f, 1f)
                val c = tilt.value
                tilt.value = Offset(c.x + (x - c.x) * 0.12f, c.y + (y - c.y) * 0.12f)
            }

            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
        }
        if (sensor != null) sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(listener) }
    }
    return tilt
}

/**
 * Frosted-glass look: a see-through tint, a glossy top edge, a bright rim, and a
 * highlight that slides across the surface as the phone tilts.
 */
fun Modifier.glassSurface(
    tilt: State<Offset>,
    shape: Shape,
    base: Color,
    sheen: Float = 0.22f
): Modifier = this
    .clip(shape)
    .background(base)
    .drawWithContent {
        val t = tilt.value
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = sheen), Color.Transparent),
                center = Offset(w * (0.5f + t.x * 0.6f), h * (0.35f + t.y * 0.5f)),
                radius = max(w, h) * 0.55f
            )
        )
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.White.copy(alpha = 0.10f), Color.Transparent),
                endY = h * 0.5f
            )
        )
        drawContent()
    }
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.55f),
                Color.White.copy(alpha = 0.08f),
                Color.White.copy(alpha = 0.30f)
            )
        ),
        shape
    )

@Composable
fun GlassButton(
    text: String,
    tilt: State<Offset>,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier
            .height(40.dp)
            .glassSurface(
                tilt,
                RoundedCornerShape(20.dp),
                cs.primary.copy(alpha = if (enabled) 0.16f else 0.05f),
                sheen = 0.34f
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            fontSize = 13.sp,
            maxLines = 1,
            color = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.38f)
        )
    }
}
