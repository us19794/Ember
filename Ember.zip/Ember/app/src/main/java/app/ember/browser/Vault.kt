package app.ember.browser

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import org.mozilla.geckoview.Autocomplete
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class Login(
    val guid: String,
    val origin: String,
    val formActionOrigin: String?,
    val httpRealm: String?,
    val username: String,
    val password: String
) {
    fun toEntry(): Autocomplete.LoginEntry =
        Autocomplete.LoginEntry.Builder()
            .guid(guid)
            .origin(origin)
            .formActionOrigin(formActionOrigin)
            .httpRealm(httpRealm)
            .username(username)
            .password(password)
            .build()
}

private fun hostOf(origin: String): String =
    try { (Uri.parse(origin).host ?: origin).removePrefix("www.") } catch (e: Exception) { origin }

/** Saved logins, encrypted with a key that never leaves the Android Keystore. */
class Vault(context: Context) {
    private val file = File(context.filesDir, "vault.bin")
    val logins = mutableStateListOf<Login>()

    init {
        load()
    }

    fun forDomain(domain: String): List<Login> {
        val d = domain.removePrefix("www.")
        return logins.filter {
            val h = hostOf(it.origin)
            h == d || h.endsWith(".$d") || d.endsWith(".$h")
        }
    }

    fun all(): List<Login> = logins.toList()

    fun save(e: Autocomplete.LoginEntry) {
        val origin = e.origin ?: return
        val pass = e.password ?: return
        val user = e.username ?: ""
        val guid = e.guid
        val idx = logins.indexOfFirst { (guid != null && it.guid == guid) || (it.origin == origin && it.username == user) }
        val l = Login(guid ?: UUID.randomUUID().toString(), origin, e.formActionOrigin, e.httpRealm, user, pass)
        if (idx >= 0) logins[idx] = l else logins.add(0, l)
        persist()
    }

    fun delete(l: Login) { logins.remove(l); persist() }

    fun clear() { logins.clear(); persist() }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun persist() {
        try {
            val arr = JSONArray()
            logins.forEach {
                arr.put(
                    JSONObject().put("guid", it.guid).put("origin", it.origin)
                        .put("fao", it.formActionOrigin ?: JSONObject.NULL)
                        .put("realm", it.httpRealm ?: JSONObject.NULL)
                        .put("user", it.username).put("pass", it.password)
                )
            }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val iv = cipher.iv
            val ct = cipher.doFinal(arr.toString().toByteArray(Charsets.UTF_8))
            file.writeBytes(byteArrayOf(iv.size.toByte()) + iv + ct)
        } catch (e: Exception) {
        }
    }

    private fun load() {
        try {
            if (!file.exists()) return
            val bytes = file.readBytes()
            val ivLen = bytes[0].toInt()
            val iv = bytes.copyOfRange(1, 1 + ivLen)
            val ct = bytes.copyOfRange(1 + ivLen, bytes.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            val arr = JSONArray(String(cipher.doFinal(ct), Charsets.UTF_8))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                logins.add(
                    Login(
                        o.getString("guid"), o.getString("origin"),
                        if (o.isNull("fao")) null else o.getString("fao"),
                        if (o.isNull("realm")) null else o.getString("realm"),
                        o.getString("user"), o.getString("pass")
                    )
                )
            }
        } catch (e: Exception) {
        }
    }

    private companion object {
        const val ALIAS = "ember_vault_key"
    }
}
