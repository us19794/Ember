package app.ember.browser

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.mozilla.geckoview.WebExtension

fun prettyUrl(url: String) =
    url.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')

@Composable
private fun ListRow(
    title: String,
    subtitle: String,
    action: String?,
    onClick: (() -> Unit)?,
    onAction: () -> Unit = {}
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .background(cs.surfaceContainerHigh, MaterialTheme.shapes.large)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, maxLines = 1, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, maxLines = 1, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        if (action != null) TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
private fun SearchBox(query: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = query,
        onValueChange = onChange,
        placeholder = { Text("Search") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

private fun openFile(ctx: Context, d: DownloadItem) {
    try {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(d.uri), d.mime.ifBlank { "*/*" })
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
    }
}

// ---------- bookmarks / history / downloads ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibrarySheet(library: Library, startTab: Int, onOpen: (String) -> Unit, onDismiss: () -> Unit) {
    var tab by remember { mutableIntStateOf(startTab) }
    var query by remember { mutableStateOf("") }
    val ctx = LocalContext.current

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Bookmarks", "History", "Downloads").forEachIndexed { i, label ->
                    FilterChip(
                        selected = tab == i,
                        onClick = { tab = i; query = "" },
                        label = { Text(label) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            if (tab != 2) {
                SearchBox(query) { query = it }
                Spacer(Modifier.height(8.dp))
            }
            val q = query.trim().lowercase()

            LazyColumn(
                Modifier.fillMaxWidth().height(420.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                when (tab) {
                    0 -> {
                        val list = library.bookmarks.filter {
                            q.isEmpty() || it.title.lowercase().contains(q) || it.url.lowercase().contains(q)
                        }
                        if (list.isEmpty()) item { Text("No bookmarks yet. Use More, then Bookmark this page.") }
                        items(list) { b ->
                            ListRow(b.title, prettyUrl(b.url), "Remove", { onOpen(b.url); onDismiss() }) {
                                library.removeBookmark(b)
                            }
                        }
                    }
                    1 -> {
                        val list = library.history.filter {
                            q.isEmpty() || it.title.lowercase().contains(q) || it.url.lowercase().contains(q)
                        }
                        item {
                            TextButton(onClick = { library.clearHistory() }) { Text("Clear history") }
                        }
                        if (list.isEmpty()) item { Text("Nothing here yet.") }
                        items(list) { h ->
                            ListRow(h.title, prettyUrl(h.url), "Remove", { onOpen(h.url); onDismiss() }) {
                                library.removeHistory(h)
                            }
                        }
                    }
                    else -> {
                        if (library.downloads.isEmpty()) item { Text("No downloads yet.") }
                        items(library.downloads.toList()) { d ->
                            ListRow(d.name, d.mime.ifBlank { "File" }, "Remove", { openFile(ctx, d) }) {
                                library.removeDownload(d)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- add-ons ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddonsSheet(onDismiss: () -> Unit) {
    val runtime = geckoRuntime(LocalContext.current)
    var items by remember { mutableStateOf<List<WebExtension>>(emptyList()) }
    var status by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    val enabled = remember { mutableStateMapOf<String, Boolean>() }

    fun refresh() {
        Addons.list(runtime) { l ->
            items = l
            l.forEach { enabled[it.id] = it.metaData?.enabled ?: true }
        }
    }

    fun install(url: String) {
        status = "Installing..."
        Addons.install(runtime, url) { err ->
            status = err ?: "Installed"
            refresh()
        }
    }

    LaunchedEffect(Unit) { refresh() }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
                .padding(bottom = 24.dp)
        ) {
            Text("Add-ons", style = MaterialTheme.typography.titleLarge)
            Text(
                "uBlock Origin and Reader are built in. Add more Firefox add-ons below; the ones listed work without a toolbar button.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (status.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(status, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
            }

            Spacer(Modifier.height(14.dp))
            Text("Installed", style = MaterialTheme.typography.titleMedium)
            if (items.isEmpty()) {
                Text("Nothing extra installed yet.", style = MaterialTheme.typography.bodyMedium)
            }
            items.forEach { ext ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(ext.metaData?.name ?: ext.id, style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Version " + (ext.metaData?.version ?: ""),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = enabled[ext.id] ?: true, onCheckedChange = {
                        enabled[ext.id] = it
                        Addons.setEnabled(runtime, ext, it)
                    })
                    TextButton(onClick = { Addons.uninstall(runtime, ext) { refresh() } }) { Text("Remove") }
                }
            }

            Spacer(Modifier.height(14.dp))
            Text("Recommended", style = MaterialTheme.typography.titleMedium)
            Addons.recommended.forEach { r ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(r.name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            r.blurb,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    FilledTonalButton(onClick = { install(Addons.xpiUrl(r.slug)) }) { Text("Add") }
                }
            }

            Spacer(Modifier.height(14.dp))
            Text("Add by link", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = link,
                onValueChange = { link = it },
                label = { Text("addons.mozilla.org link or .xpi link") },
                singleLine = true,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(onClick = { if (link.isNotBlank()) install(Addons.xpiUrl(link)) }) { Text("Install") }
        }
    }
}

// ---------- passwords ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PasswordsSheet(vault: Vault, requestUnlock: ((Boolean) -> Unit) -> Unit, onDismiss: () -> Unit) {
    var unlocked by remember { mutableStateOf(false) }
    val shown = remember { mutableStateMapOf<String, Boolean>() }

    LaunchedEffect(Unit) { requestUnlock { unlocked = it } }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
        ) {
            Text("Passwords", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            if (!unlocked) {
                Text("Locked. Use your phone's lock to see saved passwords.")
                Spacer(Modifier.height(8.dp))
                FilledTonalButton(onClick = { requestUnlock { unlocked = it } }) { Text("Unlock") }
            } else if (vault.logins.isEmpty()) {
                Text("No saved passwords yet. Ember offers to save them when you sign in to a site.")
            } else {
                LazyColumn(
                    Modifier.fillMaxWidth().height(420.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(vault.logins.toList()) { l ->
                        val show = shown[l.guid] ?: false
                        val cs = MaterialTheme.colorScheme
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .background(cs.surfaceContainerHigh, MaterialTheme.shapes.large)
                                .padding(start = 16.dp, top = 8.dp, bottom = 2.dp, end = 8.dp)
                        ) {
                            Text(prettyUrl(l.origin), style = MaterialTheme.typography.titleSmall, maxLines = 1)
                            Text(
                                l.username.ifBlank { "(no username)" },
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                            Text(if (show) l.password else "••••••••", style = MaterialTheme.typography.bodyMedium)
                            Row {
                                TextButton(onClick = { shown[l.guid] = !show }) { Text(if (show) "Hide" else "Show") }
                                TextButton(onClick = { vault.delete(l) }) { Text("Delete") }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- site permissions ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SitePermsSheet(library: Library, onReset: (SitePerm) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
        ) {
            Text("Site permissions", style = MaterialTheme.typography.titleLarge)
            Text(
                "Sites ask before using your location or sending notifications. Your answers are kept here; reset one to be asked again.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            if (library.sitePerms.isEmpty()) {
                Text("No saved answers yet.")
            } else {
                LazyColumn(
                    Modifier.fillMaxWidth().height(380.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(library.sitePerms.toList()) { p ->
                        ListRow(
                            p.host,
                            (if (p.allowed) "Allowed " else "Blocked ") + p.what,
                            "Reset",
                            null
                        ) { onReset(p) }
                    }
                }
            }
        }
    }
}

// ---------- tabs ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TabsSheet(b: BrowserState, onGroup: (BrowserTab) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp)
        ) {
            Text("Tabs", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { b.newTab(); onDismiss() }) { Text("New tab") }
                OutlinedButton(onClick = { b.newTab(private = true); onDismiss() }) { Text("New private tab") }
            }
            Spacer(Modifier.height(12.dp))

            val indexed = b.tabs.withIndex().toList()
            val sections = buildList {
                val pinned = indexed.filter { it.value.pinned }
                if (pinned.isNotEmpty()) add("Pinned" to pinned)
                b.groupNames().forEach { g ->
                    val l = indexed.filter { !it.value.pinned && it.value.group == g }
                    if (l.isNotEmpty()) add(g to l)
                }
                val rest = indexed.filter { !it.value.pinned && it.value.group.isBlank() }
                if (rest.isNotEmpty()) add("Tabs" to rest)
            }

            Column(
                Modifier.fillMaxWidth().height(380.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                sections.forEach { (heading, list) ->
                    Text(
                        heading,
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.primary,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                    list.forEach { (i, t) ->
                        val isCurrent = i == b.selected
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isCurrent) cs.primaryContainer else cs.surfaceContainerHigh,
                                    MaterialTheme.shapes.large
                                )
                                .clickable { b.select(i); onDismiss() }
                                .padding(start = 16.dp, top = 8.dp, end = 8.dp, bottom = 0.dp)
                        ) {
                            val label = when {
                                t.showHome -> "New tab"
                                t.title.isNotBlank() -> t.title
                                else -> prettyUrl(t.url)
                            }
                            Text(label, maxLines = 1, style = MaterialTheme.typography.titleSmall)
                            Text(
                                (if (t.isPrivate) "Private - " else "") +
                                    (if (t.showHome) "Home" else prettyUrl(t.url)),
                                maxLines = 1,
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                            Row {
                                TextButton(onClick = { b.togglePin(t) }) { Text(if (t.pinned) "Unpin" else "Pin") }
                                TextButton(onClick = { onGroup(t) }) { Text(if (t.group.isBlank()) "Group" else "Move") }
                                TextButton(onClick = { b.closeTab(i) }) { Text("Close") }
                            }
                        }
                    }
                }
            }
        }
    }
}
