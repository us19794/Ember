package app.ember.browser

import android.content.Context
import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

const val DEFAULT_SEED = 0xFFFF6A2B.toInt()

class SearchEngine(val name: String, val url: String)

val BuiltInEngines = listOf(
    SearchEngine("DuckDuckGo", "https://duckduckgo.com/?q=%s"),
    SearchEngine("Google", "https://www.google.com/search?q=%s"),
    SearchEngine("Brave", "https://search.brave.com/search?q=%s"),
    SearchEngine("Startpage", "https://www.startpage.com/do/search?q=%s"),
    SearchEngine("Ecosia", "https://www.ecosia.org/search?q=%s"),
    SearchEngine("Bing", "https://www.bing.com/search?q=%s")
)

/** User settings: look, shield toggles, search engines. Backed by SharedPreferences, observable by Compose. */
class EmberPrefs(context: Context) {
    private val sp = context.getSharedPreferences("ember_prefs", Context.MODE_PRIVATE)

    var seed by mutableIntStateOf(sp.getInt("seed", DEFAULT_SEED))
        private set
    var amoled by mutableStateOf(sp.getBoolean("amoled", true))
        private set
    var dynamic by mutableStateOf(sp.getBoolean("dynamic", false))
        private set
    var haptics by mutableStateOf(sp.getBoolean("haptics", true))
        private set
    var onboarded by mutableStateOf(sp.getBoolean("onboarded", false))
        private set
    var engine by mutableIntStateOf(sp.getInt("engine", 0))
        private set
    var tabLayout by mutableStateOf(sp.getString("tab_layout", "cards") ?: "cards")
        private set
    var fontScale by mutableFloatStateOf(sp.getFloat("font_scale", 1f))
        private set

    /** Shield and browsing toggles. */
    private val toggles = mutableStateMapOf<String, Boolean>().apply {
        AllToggleKeys.forEach { put(it, sp.getBoolean("t_$it", toggleDefault(it))) }
    }

    val customEngines = mutableStateListOf<SearchEngine>().apply {
        try {
            val arr = JSONArray(sp.getString("engines", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(SearchEngine(o.getString("name"), o.getString("url")))
            }
        } catch (e: Exception) {
        }
    }

    fun on(key: String): Boolean = toggles[key] ?: toggleDefault(key)
    fun setToggle(key: String, v: Boolean) { toggles[key] = v; sp.edit().putBoolean("t_$key", v).apply() }

    fun updateSeed(v: Int) { seed = v; sp.edit().putInt("seed", v).apply() }
    fun updateAmoled(v: Boolean) { amoled = v; sp.edit().putBoolean("amoled", v).apply() }
    fun updateDynamic(v: Boolean) { dynamic = v; sp.edit().putBoolean("dynamic", v).apply() }
    fun updateHaptics(v: Boolean) { haptics = v; sp.edit().putBoolean("haptics", v).apply() }
    fun finishOnboarding() { onboarded = true; sp.edit().putBoolean("onboarded", true).apply() }

    fun updateTabLayout(v: String) { tabLayout = v; sp.edit().putString("tab_layout", v).apply() }
    fun updateFontScale(v: Float) { fontScale = v; sp.edit().putFloat("font_scale", v).apply() }

    var modRegistry: String
        get() = sp.getString("mod_registry", "") ?: ""
        set(v) { sp.edit().putString("mod_registry", v).apply() }

    fun engines(): List<SearchEngine> = BuiltInEngines + customEngines
    fun searchTemplate(): String = engines().getOrElse(engine) { BuiltInEngines[0] }.url
    fun updateEngine(i: Int) { engine = i; sp.edit().putInt("engine", i).apply() }

    fun addEngine(name: String, url: String): Boolean {
        val n = name.trim()
        val u = url.trim()
        if (n.isEmpty() || !u.contains("%s") || !(u.startsWith("http://") || u.startsWith("https://"))) return false
        customEngines.add(SearchEngine(n, u))
        saveEngines()
        updateEngine(engines().lastIndex)
        return true
    }

    fun removeEngine(index: Int) {
        val ci = index - BuiltInEngines.size
        if (ci !in customEngines.indices) return
        customEngines.removeAt(ci)
        saveEngines()
        when {
            engine == index || engine >= engines().size -> updateEngine(0)
            engine > index -> updateEngine(engine - 1)
        }
    }

    private fun saveEngines() {
        val arr = JSONArray()
        customEngines.forEach { arr.put(JSONObject().put("name", it.name).put("url", it.url)) }
        sp.edit().putString("engines", arr.toString()).apply()
    }

    var savedTabs: String
        get() = sp.getString("tabs", "") ?: ""
        set(v) { sp.edit().putString("tabs", v).apply() }

    var savedSelected: Int
        get() = sp.getInt("tabs_sel", 0)
        set(v) { sp.edit().putInt("tabs_sel", v).apply() }
}

private fun hsv(h: Float, s: Float, v: Float): Color =
    Color(
        android.graphics.Color.HSVToColor(
            floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))
        )
    )

/** Builds a full Material 3 dark scheme from one seed colour. */
fun emberScheme(seed: Color, amoled: Boolean): ColorScheme {
    val a = FloatArray(3)
    android.graphics.Color.colorToHSV(seed.toArgb(), a)
    val h = a[0]
    val s = a[1]
    val base = if (amoled) Color.Black else hsv(h, s * 0.25f, 0.09f)
    return darkColorScheme(
        primary = seed,
        onPrimary = if (seed.luminance() > 0.45f) Color.Black else Color.White,
        primaryContainer = hsv(h, s * 0.85f, 0.38f),
        onPrimaryContainer = hsv(h, s * 0.25f, 1f),
        secondary = hsv(h + 24f, s * 0.45f, 0.88f),
        onSecondary = Color.Black,
        secondaryContainer = hsv(h + 24f, s * 0.40f, 0.28f),
        onSecondaryContainer = hsv(h + 24f, s * 0.15f, 0.95f),
        tertiary = hsv(h + 150f, s * 0.50f, 0.90f),
        onTertiary = Color.Black,
        tertiaryContainer = hsv(h + 150f, s * 0.40f, 0.28f),
        onTertiaryContainer = hsv(h + 150f, s * 0.15f, 0.95f),
        background = base,
        onBackground = Color(0xFFEDEDED),
        surface = base,
        onSurface = Color(0xFFEDEDED),
        surfaceVariant = hsv(h, s * 0.20f, 0.16f),
        onSurfaceVariant = Color(0xFFB8B8B8),
        surfaceContainerLowest = Color.Black,
        surfaceContainerLow = hsv(h, s * 0.20f, 0.07f),
        surfaceContainer = hsv(h, s * 0.20f, 0.10f),
        surfaceContainerHigh = hsv(h, s * 0.20f, 0.13f),
        surfaceContainerHighest = hsv(h, s * 0.20f, 0.17f),
        outline = hsv(h, s * 0.20f, 0.50f),
        outlineVariant = hsv(h, s * 0.20f, 0.25f)
    )
}

private val Serif = FontFamily.Serif

private val SerifTypography: Typography = Typography().let { t ->
    Typography(
        displayLarge = t.displayLarge.copy(fontFamily = Serif),
        displayMedium = t.displayMedium.copy(fontFamily = Serif),
        displaySmall = t.displaySmall.copy(fontFamily = Serif),
        headlineLarge = t.headlineLarge.copy(fontFamily = Serif),
        headlineMedium = t.headlineMedium.copy(fontFamily = Serif),
        headlineSmall = t.headlineSmall.copy(fontFamily = Serif),
        titleLarge = t.titleLarge.copy(fontFamily = Serif),
        titleMedium = t.titleMedium.copy(fontFamily = Serif),
        titleSmall = t.titleSmall.copy(fontFamily = Serif),
        bodyLarge = t.bodyLarge.copy(fontFamily = Serif),
        bodyMedium = t.bodyMedium.copy(fontFamily = Serif),
        bodySmall = t.bodySmall.copy(fontFamily = Serif),
        labelLarge = t.labelLarge.copy(fontFamily = Serif),
        labelMedium = t.labelMedium.copy(fontFamily = Serif),
        labelSmall = t.labelSmall.copy(fontFamily = Serif)
    )
}

private val EmberShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

@Composable
fun EmberTheme(prefs: EmberPrefs, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scheme =
        if (prefs.dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val d = dynamicDarkColorScheme(ctx)
            if (prefs.amoled) d.copy(
                background = Color.Black,
                surface = Color.Black,
                surfaceContainerLowest = Color.Black
            ) else d
        } else emberScheme(Color(prefs.seed), prefs.amoled)

    MaterialTheme(
        colorScheme = scheme,
        typography = SerifTypography,
        shapes = EmberShapes,
        content = content
    )
}
