package app.ember.browser

import android.os.Build
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.animation.core.FloatExponentialDecaySpec
import androidx.compose.animation.core.animateDecay
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

private const val DETENT_DEGREES = 30f

private fun tick(v: View) {
    val c = if (Build.VERSION.SDK_INT >= 34) HapticFeedbackConstants.SEGMENT_FREQUENT_TICK
    else HapticFeedbackConstants.CLOCK_TICK
    v.performHapticFeedback(c)
}

/**
 * Three-lobed fidget spinner. Drag around the centre to spin, flick to let it
 * fly, tap to kick it. A haptic tick fires every 30 degrees of rotation.
 */
@Composable
fun FidgetSpinner(
    lobeColor: Color,
    armColor: Color,
    holeColor: Color,
    detentColor: Color,
    haptics: Boolean,
    onRpm: (Int) -> Unit,
    modifier: Modifier = Modifier,
    spinnerSize: Dp = 280.dp
) {
    val view = LocalView.current
    val hapticsOn by rememberUpdatedState(haptics)
    val scope = rememberCoroutineScope()

    var rotation by remember { mutableFloatStateOf(0f) }
    var fling by remember { mutableStateOf<Job?>(null) }
    var omega by remember { mutableFloatStateOf(0f) } // degrees per second
    var lastTick by remember { mutableLongStateOf(0L) }
    var lastRpmShown by remember { mutableIntStateOf(-1) }

    // report rpm in steps of 10 so the rest of the screen isn't redrawn every frame
    fun report(rpm: Int) {
        val r = (rpm / 10) * 10
        if (r != lastRpmShown) {
            lastRpmShown = r
            onRpm(r)
        }
    }

    LaunchedEffect(Unit) {
        snapshotFlow { floor(rotation / DETENT_DEGREES).toInt() }
            .distinctUntilChanged()
            .drop(1)
            .collect {
                val now = SystemClock.uptimeMillis()
                if (hapticsOn && now - lastTick >= 16L) {
                    lastTick = now
                    tick(view)
                }
            }
    }

    fun launchFling(velocity: Float) {
        fling?.cancel()
        fling = scope.launch {
            animateDecay(
                initialValue = rotation,
                initialVelocity = velocity,
                animationSpec = FloatExponentialDecaySpec(
                    frictionMultiplier = 0.55f,
                    absVelocityThreshold = 6f
                )
            ) { value, vel ->
                rotation = value
                report((abs(vel) / 6f).toInt())
            }
            report(0)
            if (hapticsOn && abs(velocity) > 120f) {
                view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            }
        }
    }

    Canvas(
        modifier
            .size(spinnerSize)
            .pointerInput(Unit) {
                detectTapGestures(onTap = {
                    if (hapticsOn) view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    launchFling(900f)
                })
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = {
                        fling?.cancel()
                        omega = 0f
                        if (hapticsOn) view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    },
                    onDrag = { change, _ ->
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val p = change.previousPosition - c
                        val q = change.position - c
                        var d = Math
                            .toDegrees((atan2(q.y, q.x) - atan2(p.y, p.x)).toDouble())
                            .toFloat()
                        if (d > 180f) d -= 360f
                        if (d < -180f) d += 360f
                        rotation += d
                        val dt = (change.uptimeMillis - change.previousUptimeMillis).coerceAtLeast(1L)
                        omega = 0.6f * omega + 0.4f * (d / dt * 1000f)
                        report((abs(omega) / 6f).toInt())
                        change.consume()
                    },
                    onDragEnd = { launchFling(omega) },
                    onDragCancel = { launchFling(omega) }
                )
            }
    ) {
        val c = center
        val r = this.size.minDimension / 2f

        // fixed detent dots (one per haptic tick)
        val ringR = r * 0.97f
        for (i in 0 until 12) {
            val a = Math.toRadians((i * DETENT_DEGREES).toDouble())
            drawCircle(
                color = detentColor,
                radius = r * 0.018f,
                center = Offset(c.x + ringR * cos(a).toFloat(), c.y + ringR * sin(a).toFloat())
            )
        }

        rotate(rotation, pivot = c) {
            val lobeDist = r * 0.60f
            for (i in 0 until 3) {
                rotate(i * 120f, pivot = c) {
                    val tip = Offset(c.x, c.y - lobeDist)
                    drawLine(
                        color = armColor,
                        start = c,
                        end = tip,
                        strokeWidth = r * 0.34f,
                        cap = StrokeCap.Round
                    )
                    drawCircle(lobeColor, radius = r * 0.30f, center = tip)
                    drawCircle(holeColor, radius = r * 0.15f, center = tip)
                }
            }
            drawCircle(lobeColor, radius = r * 0.23f, center = c)
            drawCircle(holeColor, radius = r * 0.11f, center = c)
            drawCircle(lobeColor, radius = r * 0.04f, center = c)
        }
    }
}
