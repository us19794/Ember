package app.ember.browser

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** kind: "search", "bookmark" or "history". target is what to open when it's tapped. */
class Suggestion(val label: String, val target: String, val kind: String)

object Suggestions {
    /** Where each built-in engine serves suggestions from. Custom engines have none. */
    fun serviceFor(engineName: String): String? = when (engineName) {
        "DuckDuckGo" -> "https://duckduckgo.com/ac/?type=list&q=%s"
        "Google" -> "https://suggestqueries.google.com/complete/search?client=firefox&q=%s"
        "Brave" -> "https://search.brave.com/api/suggest?q=%s"
        "Ecosia" -> "https://ac.ecosia.org/autocomplete?type=list&q=%s"
        "Bing" -> "https://api.bing.com/osjson.aspx?query=%s"
        else -> null
    }

    suspend fun fetch(template: String, query: String): List<String> = withContext(Dispatchers.IO) {
        try {
            val c = URL(template.replace("%s", URLEncoder.encode(query, "UTF-8"))).openConnection() as HttpURLConnection
            c.connectTimeout = 3000
            c.readTimeout = 3000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android 15; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0")
            val text = c.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(text).getJSONArray(1)
            (0 until minOf(arr.length(), 6)).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Bookmarks and history that contain what's been typed. */
    fun local(library: Library, query: String): List<Suggestion> {
        val q = query.lowercase()
        val out = ArrayList<Suggestion>()
        library.bookmarks.filter { it.title.lowercase().contains(q) || it.url.lowercase().contains(q) }
            .take(2).forEach { out.add(Suggestion(it.title, it.url, "bookmark")) }
        library.history.filter { it.title.lowercase().contains(q) || it.url.lowercase().contains(q) }
            .filter { h -> out.none { it.target == h.url } }
            .take(2).forEach { out.add(Suggestion(it.title.ifBlank { prettyUrl(it.url) }, it.url, "history")) }
        return out
    }
}

@Composable
fun SuggestionList(items: List<Suggestion>, onPick: (Suggestion) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp)
            .background(cs.surfaceContainerHigh.copy(alpha = 0.92f), MaterialTheme.shapes.large)
    ) {
        items.forEach { s ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onPick(s) }
                    .padding(horizontal = 16.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    when (s.kind) {
                        "bookmark" -> "Bookmark"
                        "history" -> "History"
                        else -> "Search"
                    },
                    color = cs.primary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(end = 12.dp)
                )
                Text(s.label, maxLines = 1, fontSize = 15.sp, modifier = Modifier.weight(1f))
            }
        }
    }
}
