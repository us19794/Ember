package app.ember.browser

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

/**
 * Full-screen transparent assistant overlay:
 * - Keeps the user's home screen 100% visible underneath.
 * - Shows the island-aligned orb at top-center.
 * - Listens immediately via SpeechRecognizer, displays the instant answer right
 *   below the orb in a frosted glass card, and speaks the reply via TextToSpeech.
 */
class AssistantOverlayView(
    context: Context,
    private val onRequestMicPermission: (() -> Unit)?,
    private val onOpenUrl: (String) -> Unit,
    private val onDismiss: () -> Unit
) : FrameLayout(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * density).toInt()
    private fun dpf(v: Float): Float = v * density

    private val blobView: AssistantBlobView
    private val cardContainer: LinearLayout
    private val queryText: TextView
    private val answerScroll: ScrollView
    private val answerText: TextView
    private val actionRow: LinearLayout
    private val openEmberBtn: TextView
    private val askAgainBtn: TextView

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var isListening = false
    private var pendingSearchUrl: String? = null

    init {
        setBackgroundColor(Color.TRANSPARENT)

        blobView = AssistantBlobView(
            context = context,
            onTapBlob = {
                stopSpeaking()
                startListeningOrPrompt()
            },
            onDismiss = {
                cleanup()
                onDismiss()
            }
        )
        addView(blobView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        // Frosted dark-glass card directly beneath the orb
        cardContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.argb(214, 16, 18, 24))
                cornerRadius = dpf(24f)
                setStroke(dp(1), Color.argb(52, 255, 255, 255))
            }
            setPadding(dp(18), dp(14), dp(18), dp(14))
            elevation = dpf(12f)
            visibility = View.INVISIBLE
            isClickable = true
        }

        queryText = TextView(context).apply {
            setTextColor(Color.argb(175, 255, 255, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            text = "Listening..."
        }
        cardContainer.addView(queryText)

        answerScroll = ScrollView(context).apply {
            visibility = View.GONE
            isVerticalScrollBarEnabled = false
        }
        answerText = TextView(context).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setLineSpacing(dpf(3f), 1.05f)
            setPadding(0, dp(6), 0, 0)
        }
        answerScroll.addView(answerText)
        val scrollLp = LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        cardContainer.addView(answerScroll, scrollLp)

        actionRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dp(10), 0, 0)
            visibility = View.GONE
        }

        askAgainBtn = makePillButton("Ask again", accent = false).apply {
            setOnClickListener {
                stopSpeaking()
                startListeningOrPrompt()
            }
        }
        openEmberBtn = makePillButton("Open in Ember", accent = true).apply {
            setOnClickListener {
                val url = pendingSearchUrl
                if (url != null) {
                    cleanup()
                    onOpenUrl(url)
                }
            }
        }
        actionRow.addView(askAgainBtn)
        val openLp = LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(8)
        }
        actionRow.addView(openEmberBtn, openLp)
        cardContainer.addView(actionRow)

        val cardLp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            leftMargin = dp(20)
            rightMargin = dp(20)
        }
        addView(cardContainer, cardLp)

        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                ttsReady = true
            }
        }
    }

    private fun makePillButton(label: String, accent: Boolean): TextView = TextView(context).apply {
        text = label
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTextColor(if (accent) Color.rgb(255, 190, 120) else Color.argb(220, 255, 255, 255))
        background = GradientDrawable().apply {
            setColor(if (accent) Color.argb(46, 255, 140, 60) else Color.argb(28, 255, 255, 255))
            cornerRadius = dpf(16f)
        }
        setPadding(dp(14), dp(7), dp(14), dp(7))
    }

    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        val res = super.onApplyWindowInsets(insets)
        post { positionCardBelowOrb() }
        return res
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        post { positionCardBelowOrb() }
    }

    private fun positionCardBelowOrb() {
        val lp = cardContainer.layoutParams as? LayoutParams ?: return
        lp.topMargin = blobView.orbBottomY().toInt()
        cardContainer.layoutParams = lp
        // Cap answer scroll height so it never covers too much of the home screen
        val maxH = (height * 0.34f).toInt().coerceAtLeast(dp(120))
        answerScroll.layoutParams = (answerScroll.layoutParams as LinearLayout.LayoutParams).apply {
            height = LayoutParams.WRAP_CONTENT
        }
        answerText.maxHeight = maxH
    }

    fun startSession() {
        positionCardBelowOrb()
        blobView.startEnterAnimation()
        cardContainer.visibility = View.VISIBLE
        cardContainer.alpha = 0f
        cardContainer.animate().alpha(1f).setDuration(260L).start()
        startListeningOrPrompt()
    }

    fun dismissSession() {
        cleanup()
        cardContainer.animate().alpha(0f).setDuration(180L).start()
        blobView.startExitAnimation()
    }

    private fun hasMicPermission(): Boolean =
        context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startListeningOrPrompt() {
        if (!hasMicPermission()) {
            queryText.text = "Microphone permission needed"
            answerText.text = "Tap the orb to allow microphone access so Ember can hear you."
            answerScroll.visibility = View.VISIBLE
            actionRow.visibility = View.GONE
            if (onRequestMicPermission != null) {
                onRequestMicPermission.invoke()
            }
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            queryText.text = "Voice recognition unavailable"
            answerText.text = "No speech recognizer is installed on this device."
            answerScroll.visibility = View.VISIBLE
            return
        }

        pendingSearchUrl = null
        answerScroll.visibility = View.GONE
        actionRow.visibility = View.GONE
        queryText.text = "Listening..."

        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListening = true
                        queryText.text = "Listening..."
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        blobView.setVoiceLevel(rmsdB)
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        isListening = false
                        blobView.setVoiceLevel(0f)
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        blobView.setVoiceLevel(0f)
                        queryText.text = "Didn't catch that"
                        answerText.text = "Tap the orb or Ask again to speak."
                        answerScroll.visibility = View.VISIBLE
                        openEmberBtn.visibility = View.GONE
                        actionRow.visibility = View.VISIBLE
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        blobView.setVoiceLevel(0f)
                        val spoken = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        handleSpokenQuery(spoken)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                        if (!partial.isNullOrBlank()) {
                            queryText.text = "\"$partial\""
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            queryText.text = "Couldn't start microphone"
            answerText.text = "Tap Ask again to retry."
            answerScroll.visibility = View.VISIBLE
            openEmberBtn.visibility = View.GONE
            actionRow.visibility = View.VISIBLE
        }
    }

    private fun handleSpokenQuery(spoken: String) {
        if (spoken.isBlank()) {
            queryText.text = "Didn't catch that"
            answerText.text = "Tap the orb or Ask again to speak."
            answerScroll.visibility = View.VISIBLE
            openEmberBtn.visibility = View.GONE
            actionRow.visibility = View.VISIBLE
            return
        }

        queryText.text = "\"$spoken\""
        answerText.text = "Thinking..."
        answerScroll.visibility = View.VISIBLE
        actionRow.visibility = View.GONE

        AssistantBrain.answer(spoken) { reply ->
            answerText.text = reply.text
            pendingSearchUrl = reply.searchUrl
            openEmberBtn.visibility = if (reply.searchUrl != null) View.VISIBLE else View.GONE
            actionRow.visibility = View.VISIBLE
            speakOut(reply.text)
        }
    }

    private fun speakOut(text: String) {
        if (ttsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ember_reply")
        }
    }

    private fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
    }

    fun cleanup() {
        isListening = false
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null
        stopSpeaking()
    }

    override fun onDetachedFromWindow() {
        cleanup()
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            if (blobView.handleTap(event.x, event.y)) {
                return true
            }
            // If tap is outside cardContainer, dismiss back into island
            val cardTop = cardContainer.top.toFloat()
            val cardBottom = cardContainer.bottom.toFloat()
            val cardLeft = cardContainer.left.toFloat()
            val cardRight = cardContainer.right.toFloat()
            val inCard = event.x in cardLeft..cardRight && event.y in cardTop..cardBottom
            if (!inCard) {
                dismissSession()
            }
            return true
        }
        return true
    }
}
