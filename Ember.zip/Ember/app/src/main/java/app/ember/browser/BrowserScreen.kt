package app.ember.browser

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.debounce
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import kotlin.math.abs

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Swiping sideways across the bar switches to the next or previous tab. */
private fun Modifier.tabSwipe(canSwipe: () -> Boolean, onSwipe: (Int) -> Unit): Modifier =
    pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var dx = 0f
            var dragging = false
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                if (!change.pressed) break
                dx += change.positionChange().x
                if (!dragging && abs(dx) > viewConfiguration.touchSlop * 2 && canSwipe()) dragging = true
                if (dragging) change.consume()
            }
            if (dragging && abs(dx) > 90.dp.toPx()) onSwipe(if (dx < 0) 1 else -1)
        }
    }

@OptIn(FlowPreview::class)
@Composable
fun BrowserScreen(
    b: BrowserState,
    prefs: EmberPrefs,
    library: Library,
    vault: Vault,
    mods: ModStore,
    onSetDefault: () -> Unit,
    onShieldChanged: () -> Unit,
    onUnlock: ((Boolean) -> Unit) -> Unit
) {
    val ctx = LocalContext.current
    val view = LocalView.current

    var showSettings by remember { mutableStateOf(false) }
    var showTabs by remember { mutableStateOf(false) }
    var showCards by remember { mutableStateOf(false) }
    var showDrawer by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }
    var showAddons by remember { mutableStateOf(false) }
    var showMods by remember { mutableStateOf(false) }
    var showPasswords by remember { mutableStateOf(false) }
    var showSitePerms by remember { mutableStateOf(false) }
    var libraryTab by remember { mutableStateOf<Int?>(null) }
    var finding by remember { mutableStateOf(false) }
    var groupTarget by remember { mutableStateOf<BrowserTab?>(null) }
    var wiping by remember { mutableStateOf(false) }
    var wipeCloseTabs by remember { mutableStateOf(false) }
    var geckoView by remember { mutableStateOf<GeckoView?>(null) }

    val tab = b.current
    val glass = prefs.on(K_GLASS)
    val tilt = rememberTilt(glass)
    val layout = prefs.tabLayout

    // keep the open tabs saved as they change, so nothing is lost if Android ends the app
    LaunchedEffect(Unit) {
        snapshotFlow { b.stateSignature() }.debounce(700).collect { b.saveTabs() }
    }

    // immersive mode while a video is full screen
    LaunchedEffect(tab.fullscreen) {
        val activity = ctx.findActivity() ?: return@LaunchedEffect
        val c = WindowCompat.getInsetsController(activity.window, view)
        if (tab.fullscreen) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    BackHandler(enabled = !tab.showHome || b.tabs.size > 1) {
        if (!tab.showHome) {
            if (tab.canGoBack) tab.session.goBack() else tab.showHome = true
        } else {
            b.closeTab(b.selected)
        }
    }
    BackHandler(enabled = finding) {
        finding = false
        tab.session.finder.clear()
    }
    BackHandler(enabled = showDrawer) { showDrawer = false }
    BackHandler(enabled = tab.fullscreen) { tab.session.exitFullScreen() }

    /** Takes a small picture of the page for the tab cards, then carries on. */
    fun snapshot(after: () -> Unit) {
        val gv = geckoView
        val t = b.current
        if (gv == null || t.showHome || t.fullscreen) {
            after()
            return
        }
        try {
            gv.capturePixels().accept({ bmp ->
                if (bmp != null) {
                    try {
                        t.thumb = Bitmap.createScaledBitmap(
                            bmp,
                            (bmp.width / 3).coerceAtLeast(1),
                            (bmp.height / 3).coerceAtLeast(1),
                            true
                        ).asImageBitmap()
                    } catch (e: Exception) {
                    }
                }
                after()
            }, { _ -> after() })
        } catch (e: Exception) {
            after()
        }
    }

    val switchTo: (Int) -> Unit = { i -> snapshot { b.select(i) } }

    fun share() {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, tab.url)
            putExtra(Intent.EXTRA_SUBJECT, tab.title)
        }
        ctx.startActivity(Intent.createChooser(i, null))
    }

    fun addToHome() {
        try {
            if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
                Toast.makeText(ctx, "Your launcher can't add shortcuts.", Toast.LENGTH_SHORT).show()
                return
            }
            val open = Intent(Intent.ACTION_VIEW, Uri.parse(tab.url)).setClass(ctx, MainActivity::class.java)
            val info = ShortcutInfoCompat.Builder(ctx, "page-" + tab.url.hashCode())
                .setShortLabel(tab.title.ifBlank { prettyUrl(tab.url) }.take(24))
                .setIcon(IconCompat.createWithResource(ctx, R.mipmap.ic_launcher))
                .setIntent(open)
                .build()
            ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Couldn't add the shortcut.", Toast.LENGTH_SHORT).show()
        }
    }

    val bar: @Composable (Modifier) -> Unit = { m ->
        BottomBar(
            modifier = m,
            b = b,
            prefs = prefs,
            library = library,
            glass = glass,
            tilt = tilt,
            finding = finding,
            onFinding = { finding = it },
            onTabs = {
                when (layout) {
                    "vertical" -> showDrawer = !showDrawer
                    "list" -> showTabs = true
                    else -> snapshot { showCards = true }
                }
            },
            onSwipeTab = { dir ->
                val ni = b.selected + dir
                if (ni in b.tabs.indices) {
                    if (prefs.haptics) view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    switchTo(ni)
                }
            },
            onSettings = { showSettings = true },
            onClear = { showClear = true },
            onSetDefault = onSetDefault,
            onLibrary = { libraryTab = it },
            onAddons = { showAddons = true },
            onMods = { showMods = true },
            onPasswords = { showPasswords = true },
            onShare = ::share,
            onAddHome = ::addToHome
        )
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .then(if (tab.fullscreen) Modifier else Modifier.statusBarsPadding())
        ) {
            if (layout == "top" && !tab.fullscreen) TopTabStrip(b, switchTo)

            Box(Modifier.weight(1f).fillMaxWidth()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c -> GeckoView(c).also { geckoView = it } },
                    update = { gv ->
                        val target = b.current.session
                        if (gv.session !== target) {
                            gv.releaseSession()
                            gv.setSession(target)
                        }
                        b.flushClosed()
                    }
                )
                if (tab.showHome) {
                    HomeScreen(
                        prefs = prefs,
                        library = library,
                        onSettings = { showSettings = true },
                        onOpen = { b.load(it) },
                        bottomInset = if (glass && !tab.fullscreen) 170.dp else 0.dp,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (tab.loading) {
                    LinearProgressIndicator(
                        progress = { tab.progress / 100f },
                        modifier = Modifier.fillMaxWidth().height(2.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = Color.Transparent
                    )
                }
                // liquid glass: the bar floats over the page
                if (glass && !tab.fullscreen) bar(Modifier.align(Alignment.BottomCenter))
            }
            if (!glass && !tab.fullscreen) bar(Modifier)
        }

        // vertical tabs: a side panel that slides in over the page
        VerticalTabsDrawer(
            b = b,
            visible = showDrawer && layout == "vertical",
            onSwitch = switchTo,
            onGroup = { groupTarget = it },
            onClose = { showDrawer = false }
        )

        // sliding cards, like Android / iPhone multitasking
        if (showCards) TabCardsOverlay(b, onGroup = { groupTarget = it }) { showCards = false }

        if (wiping) {
            WipeOverlay(
                haptics = prefs.haptics,
                onCovered = {
                    b.clearBrowsingData(wipeCloseTabs)
                    b.current.showHome = true
                },
                onDone = { wiping = false }
            )
        }
    }

    if (showSettings) {
        SettingsSheet(
            prefs = prefs,
            onShieldChanged = onShieldChanged,
            onOpenUblock = {
                val u = Shield.ublockDashboardUrl()
                if (u != null) {
                    showSettings = false
                    b.newTab(url = u)
                } else {
                    Toast.makeText(ctx, "uBlock is still starting. Try again in a moment.", Toast.LENGTH_SHORT).show()
                }
            },
            onAddons = { showSettings = false; showAddons = true },
            onSitePerms = { showSettings = false; showSitePerms = true },
            onMods = { showSettings = false; showMods = true },
            onDismiss = { showSettings = false }
        )
    }
    if (showTabs) TabsSheet(b, onGroup = { groupTarget = it }) { showTabs = false }
    if (showAddons) AddonsSheet { showAddons = false }
    if (showMods) ModsSheet(mods, prefs) { showMods = false }
    if (showPasswords) PasswordsSheet(vault, onUnlock) { showPasswords = false }
    if (showSitePerms) SitePermsSheet(library, onReset = { b.resetSitePerm(it) }) { showSitePerms = false }
    libraryTab?.let { t -> LibrarySheet(library, t, onOpen = { b.load(it) }) { libraryTab = null } }
    groupTarget?.let { t -> GroupDialog(b, t) { groupTarget = null } }
    if (showClear) {
        ClearDialog(
            onConfirm = { closeTabs ->
                wipeCloseTabs = closeTabs
                showClear = false
                wiping = true
            },
            onDismiss = { showClear = false }
        )
    }
    b.contextMenu?.let { info -> ContextMenuSheet(b, library, info) { b.contextMenu = null } }
    PromptHost(b)
}

@Composable
private fun BarButton(
    text: String,
    glass: Boolean,
    tilt: State<Offset>,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    if (glass) {
        GlassButton(text, tilt, modifier, enabled, onClick)
    } else {
        FilledTonalButton(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier.height(40.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
            Text(text, fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
private fun FindBar(tab: BrowserTab, onDone: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var text by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }

    fun run(newText: String?, flags: Int) {
        tab.session.finder.find(newText, flags).accept { r ->
            status = when {
                r == null -> ""
                !r.found -> "No matches"
                r.total >= 0 -> "${r.current}/${r.total}"
                else -> "${r.current}"
            }
        }
    }

    LaunchedEffect(Unit) {
        tab.session.finder.setDisplayFlags(GeckoSession.FINDER_DISPLAY_HIGHLIGHT_ALL)
        focus.requestFocus()
    }

    Row(
        Modifier.fillMaxWidth().padding(bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .weight(1f)
                .height(40.dp)
                .background(cs.surfaceContainerHigh, MaterialTheme.shapes.large)
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (text.isEmpty()) {
                Text("Find in page", color = cs.onSurfaceVariant, fontSize = 14.sp, fontFamily = FontFamily.Serif)
            }
            BasicTextField(
                value = text,
                onValueChange = {
                    text = it
                    if (it.isNotEmpty()) run(it, 0) else {
                        tab.session.finder.clear()
                        status = ""
                    }
                },
                singleLine = true,
                textStyle = TextStyle(color = cs.onSurface, fontSize = 14.sp, fontFamily = FontFamily.Serif),
                cursorBrush = SolidColor(cs.primary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { run(null, 0) }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus)
            )
        }
        Text(status, fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 6.dp))
        TextButton(onClick = { run(null, GeckoSession.FINDER_FIND_BACKWARDS) }) { Text("Prev") }
        TextButton(onClick = { run(null, 0) }) { Text("Next") }
        TextButton(onClick = onDone) { Text("Done") }
    }
}

@Composable
private fun BottomBar(
    modifier: Modifier,
    b: BrowserState,
    prefs: EmberPrefs,
    library: Library,
    glass: Boolean,
    tilt: State<Offset>,
    finding: Boolean,
    onFinding: (Boolean) -> Unit,
    onTabs: () -> Unit,
    onSwipeTab: (Int) -> Unit,
    onSettings: () -> Unit,
    onClear: () -> Unit,
    onSetDefault: () -> Unit,
    onLibrary: (Int) -> Unit,
    onAddons: () -> Unit,
    onMods: () -> Unit,
    onPasswords: () -> Unit,
    onShare: () -> Unit,
    onAddHome: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val tab = b.current
    val focus = LocalFocusManager.current
    var focused by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf(false) }
    var field by remember { mutableStateOf(TextFieldValue("")) }
    var menu by remember { mutableStateOf(false) }
    var suggestions by remember { mutableStateOf<List<Suggestion>>(emptyList()) }

    LaunchedEffect(tab.url, tab.showHome, focused, b.selected) {
        if (!focused) field = TextFieldValue(if (tab.showHome) "" else prettyUrl(tab.url))
    }

    // suggestions appear only while you are actually typing a word
    val query = field.text.trim()
    LaunchedEffect(query, typed, focused, prefs.engine, tab.isPrivate) {
        if (!typed || !focused || query.isEmpty()) {
            suggestions = emptyList()
            return@LaunchedEffect
        }
        val local = Suggestions.local(library, query)
        suggestions = local
        if (!prefs.on(K_SUGGEST) || tab.isPrivate || query.contains("://")) return@LaunchedEffect
        val service = Suggestions.serviceFor(prefs.engines().getOrNull(prefs.engine)?.name ?: "") ?: return@LaunchedEffect
        delay(180)
        val remote = Suggestions.fetch(service, query)
        suggestions = local + remote
            .filter { r -> local.none { it.label.equals(r, ignoreCase = true) } }
            .map { Suggestion(it, it, "search") }
    }

    fun pick(target: String) {
        typed = false
        suggestions = emptyList()
        b.load(target)
        focus.clearFocus()
    }

    val barShape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    Column(
        modifier
            .fillMaxWidth()
            .then(
                if (glass) Modifier.glassSurface(tilt, barShape, cs.background.copy(alpha = 0.50f), sheen = 0.20f)
                else Modifier.background(cs.background)
            )
            .tabSwipe(canSwipe = { !focused }, onSwipe = onSwipeTab)
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        if (typed && suggestions.isNotEmpty()) {
            SuggestionList(suggestions) { pick(it.target) }
        }

        if (finding && !tab.showHome) {
            FindBar(tab) {
                onFinding(false)
                tab.session.finder.clear()
            }
        } else if (!tab.showHome && suggestions.isEmpty()) {
            val shieldOn = prefs.on(K_UBLOCK) || prefs.on(K_TRACKERS)
            Text(
                (if (shieldOn) "Shield on" else "Shield off") +
                    " · ${tab.blocked} trackers blocked" +
                    (if (tab.url.startsWith("http://")) " · Not secure" else "") +
                    (if (tab.isPrivate) " · Private tab" else ""),
                color = cs.onSurfaceVariant,
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 4.dp)
            )
        }

        Box(
            Modifier
                .fillMaxWidth()
                .height(46.dp)
                .then(
                    if (glass) Modifier.glassSurface(tilt, MaterialTheme.shapes.extraLarge, Color.White.copy(alpha = 0.08f), sheen = 0.16f)
                    else Modifier.background(cs.surfaceContainerHigh, MaterialTheme.shapes.extraLarge)
                )
                .padding(horizontal = 18.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (field.text.isEmpty()) {
                Text(
                    if (tab.isPrivate) "Private search or address" else "Search or enter address",
                    color = cs.onSurfaceVariant,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Serif
                )
            }
            BasicTextField(
                value = field,
                onValueChange = {
                    if (it.text != field.text) typed = true
                    field = it
                },
                singleLine = true,
                textStyle = TextStyle(color = cs.onSurface, fontSize = 15.sp, fontFamily = FontFamily.Serif),
                cursorBrush = SolidColor(cs.primary),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { pick(field.text) }),
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { s ->
                        focused = s.isFocused
                        typed = false
                        if (s.isFocused) {
                            val u = if (tab.showHome) "" else tab.url
                            field = TextFieldValue(u, TextRange(0, u.length))
                        }
                    }
            )
        }

        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BarButton("Back", glass, tilt, Modifier.weight(1f), enabled = !tab.showHome) {
                if (tab.canGoBack) tab.session.goBack() else tab.showHome = true
            }
            BarButton("Forward", glass, tilt, Modifier.weight(1.2f), enabled = tab.canGoForward && !tab.showHome) {
                tab.session.goForward()
            }
            BarButton(
                if (tab.loading) "Stop" else "Reload",
                glass,
                tilt,
                Modifier.weight(1.1f),
                enabled = !tab.showHome
            ) { if (tab.loading) tab.session.stop() else tab.session.reload() }
            BarButton("Tabs ${b.tabs.size}", glass, tilt, Modifier.weight(1.2f), onClick = onTabs)
            Box(Modifier.weight(1f)) {
                BarButton("More", glass, tilt, Modifier.fillMaxWidth()) { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    val page = !tab.showHome
                    val bookmarked = library.isBookmarked(tab.url)
                    DropdownMenuItem(text = { Text("Home") }, onClick = { menu = false; tab.showHome = true })
                    DropdownMenuItem(
                        text = { Text(if (bookmarked) "Remove bookmark" else "Bookmark this page") },
                        enabled = page,
                        onClick = { menu = false; library.toggleBookmark(tab.url, tab.title) }
                    )
                    DropdownMenuItem(text = { Text("Bookmarks and history") }, onClick = { menu = false; onLibrary(0) })
                    DropdownMenuItem(text = { Text("Downloads") }, onClick = { menu = false; onLibrary(2) })
                    DropdownMenuItem(
                        text = { Text("Reopen closed tab") },
                        enabled = b.closedCount > 0,
                        onClick = { menu = false; b.reopenClosed() }
                    )
                    DropdownMenuItem(
                        text = { Text("Find in page") },
                        enabled = page,
                        onClick = { menu = false; onFinding(true) }
                    )
                    DropdownMenuItem(text = { Text("Share") }, enabled = page, onClick = { menu = false; onShare() })
                    DropdownMenuItem(
                        text = { Text("Add to home screen") },
                        enabled = page,
                        onClick = { menu = false; onAddHome() }
                    )
                    DropdownMenuItem(
                        text = { Text(if (tab.desktop) "Desktop site: on" else "Desktop site: off") },
                        enabled = page,
                        onClick = { menu = false; b.toggleDesktop(tab) }
                    )
                    DropdownMenuItem(text = { Text("Mods") }, onClick = { menu = false; onMods() })
                    DropdownMenuItem(text = { Text("Add-ons") }, onClick = { menu = false; onAddons() })
                    DropdownMenuItem(text = { Text("Passwords") }, onClick = { menu = false; onPasswords() })
                    DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; onSettings() })
                    DropdownMenuItem(text = { Text("Clear browsing data") }, onClick = { menu = false; onClear() })
                    DropdownMenuItem(text = { Text("Set as default browser") }, onClick = { menu = false; onSetDefault() })
                }
            }
        }
    }
}
