package app.ember.browser

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.mozilla.geckoview.GeckoView

@Composable
fun BrowserScreen(
    b: BrowserState,
    prefs: EmberPrefs,
    onSetDefault: () -> Unit,
    onShieldChanged: () -> Unit
) {
    var showSettings by remember { mutableStateOf(false) }
    var showTabs by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }

    val tab = b.current

    BackHandler(enabled = !tab.showHome || b.tabs.size > 1) {
        if (!tab.showHome) {
            if (tab.canGoBack) tab.session.goBack() else tab.showHome = true
        } else {
            b.closeTab(b.selected)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
    ) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx -> GeckoView(ctx) },
                update = { gv ->
                    val target = b.current.session
                    if (gv.session !== target) {
                        gv.releaseSession()
                        gv.setSession(target)
                    }
                    b.flushClosed()
                }
            )
            if (tab.showHome) {
                HomeScreen(
                    prefs = prefs,
                    onSettings = { showSettings = true },
                    modifier = Modifier.fillMaxSize()
                )
            } else if (tab.loading) {
                LinearProgressIndicator(
                    progress = { tab.progress / 100f },
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color.Transparent
                )
            }
        }

        BottomBar(
            b = b,
            prefs = prefs,
            onTabs = { showTabs = true },
            onSettings = { showSettings = true },
            onClear = { showClear = true },
            onSetDefault = onSetDefault
        )
    }

    if (showSettings) SettingsSheet(prefs, onShieldChanged) { showSettings = false }
    if (showTabs) TabsSheet(b) { showTabs = false }
    if (showClear) ClearDialog(
        onConfirm = { closeTabs -> b.clearBrowsingData(closeTabs); showClear = false },
        onDismiss = { showClear = false }
    )
}

private fun pretty(url: String) =
    url.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')

@Composable
private fun BarButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    FilledTonalButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(40.dp),
        contentPadding = PaddingValues(horizontal = 2.dp)
    ) {
        Text(text, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
private fun BottomBar(
    b: BrowserState,
    prefs: EmberPrefs,
    onTabs: () -> Unit,
    onSettings: () -> Unit,
    onClear: () -> Unit,
    onSetDefault: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val tab = b.current
    val focus = LocalFocusManager.current
    var focused by remember { mutableStateOf(false) }
    var field by remember { mutableStateOf(TextFieldValue("")) }
    var menu by remember { mutableStateOf(false) }

    LaunchedEffect(tab.url, tab.showHome, focused, b.selected) {
        if (!focused) field = TextFieldValue(if (tab.showHome) "" else pretty(tab.url))
    }

    Column(
        Modifier
            .fillMaxWidth()
            .background(cs.background)
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        if (!tab.showHome) {
            val shieldOn = prefs.on(K_UBLOCK) || prefs.on(K_TRACKERS)
            Text(
                (if (shieldOn) "Shield on" else "Shield off") +
                    " · ${tab.blocked} trackers blocked" +
                    (if (tab.isPrivate) " · Private tab" else ""),
                color = cs.onSurfaceVariant,
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 4.dp)
            )
        }

        Box(
            Modifier
                .fillMaxWidth()
                .height(46.dp)
                .background(cs.surfaceContainerHigh, MaterialTheme.shapes.extraLarge)
                .padding(horizontal = 18.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (field.text.isEmpty()) {
                Text(
                    if (tab.isPrivate) "Private search or address" else "Search or enter address",
                    color = cs.onSurfaceVariant,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Serif
                )
            }
            BasicTextField(
                value = field,
                onValueChange = { field = it },
                singleLine = true,
                textStyle = TextStyle(
                    color = cs.onSurface,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Serif
                ),
                cursorBrush = SolidColor(cs.primary),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Uri,
                    imeAction = ImeAction.Go
                ),
                keyboardActions = KeyboardActions(onGo = {
                    b.load(field.text)
                    focus.clearFocus()
                }),
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { s ->
                        focused = s.isFocused
                        if (s.isFocused) {
                            val u = if (tab.showHome) "" else tab.url
                            field = TextFieldValue(u, TextRange(0, u.length))
                        }
                    }
            )
        }

        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            BarButton("Back", Modifier.weight(1f), enabled = !tab.showHome) {
                if (tab.canGoBack) tab.session.goBack() else tab.showHome = true
            }
            BarButton("Forward", Modifier.weight(1.2f), enabled = tab.canGoForward && !tab.showHome) {
                tab.session.goForward()
            }
            BarButton(
                if (tab.loading) "Stop" else "Reload",
                Modifier.weight(1.1f),
                enabled = !tab.showHome
            ) { if (tab.loading) tab.session.stop() else tab.session.reload() }
            BarButton("Tabs ${b.tabs.size}", Modifier.weight(1.2f), onClick = onTabs)
            Box(Modifier.weight(1f)) {
                BarButton("More", Modifier.fillMaxWidth()) { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Home") }, onClick = { menu = false; tab.showHome = true })
                    DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; onSettings() })
                    DropdownMenuItem(text = { Text("Clear browsing data") }, onClick = { menu = false; onClear() })
                    DropdownMenuItem(text = { Text("Set as default browser") }, onClick = { menu = false; onSetDefault() })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TabsSheet(b: BrowserState, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp)
        ) {
            Text("Tabs", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { b.newTab(); onDismiss() }) { Text("New tab") }
                OutlinedButton(onClick = { b.newTab(private = true); onDismiss() }) { Text("New private tab") }
            }
            Spacer(Modifier.height(12.dp))

            Column(
                Modifier
                    .fillMaxWidth()
                    .height(320.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                b.tabs.forEachIndexed { i, t ->
                    val isCurrent = i == b.selected
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(
                                if (isCurrent) cs.primaryContainer else cs.surfaceContainerHigh,
                                MaterialTheme.shapes.large
                            )
                            .clickable { b.select(i); onDismiss() }
                            .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            val label = when {
                                t.showHome -> "New tab"
                                t.title.isNotBlank() -> t.title
                                else -> pretty(t.url)
                            }
                            Text(label, maxLines = 1, style = MaterialTheme.typography.titleSmall)
                            Text(
                                (if (t.isPrivate) "Private · " else "") +
                                    (if (t.showHome) "Home" else pretty(t.url)),
                                maxLines = 1,
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                        TextButton(onClick = { b.closeTab(i) }) { Text("Close") }
                    }
                }
            }
        }
    }
}

@Composable
private fun ClearDialog(onConfirm: (closeTabs: Boolean) -> Unit, onDismiss: () -> Unit) {
    var closeTabs by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Clear browsing data?") },
        text = {
            Column {
                Text("Removes cookies, cache, site data, saved permissions and page history.")
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().clickable { closeTabs = !closeTabs },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = closeTabs, onCheckedChange = { closeTabs = it })
                    Text("Also close all tabs")
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(closeTabs) }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
