package app.ember.browser

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.mozilla.geckoview.GeckoView

@Composable
fun BrowserScreen(
    b: BrowserState,
    prefs: EmberPrefs,
    onSetDefault: () -> Unit
) {
    var showAppearance by remember { mutableStateOf(false) }

    BackHandler(enabled = !b.showHome) {
        if (b.canGoBack) b.session.goBack() else b.showHome = true
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
    ) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx -> GeckoView(ctx).apply { setSession(b.session) } }
            )
            if (b.showHome) {
                HomeScreen(
                    prefs = prefs,
                    onAppearance = { showAppearance = true },
                    modifier = Modifier.fillMaxSize()
                )
            } else if (b.loading) {
                LinearProgressIndicator(
                    progress = { b.progress / 100f },
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color.Transparent
                )
            }
        }
        BottomBar(b, onSetDefault, onAppearance = { showAppearance = true })
    }

    if (showAppearance) AppearanceSheet(prefs) { showAppearance = false }
}

private fun pretty(url: String) =
    url.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')

@Composable
private fun BottomBar(b: BrowserState, onSetDefault: () -> Unit, onAppearance: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val focus = LocalFocusManager.current
    var focused by remember { mutableStateOf(false) }
    var field by remember { mutableStateOf(TextFieldValue("")) }
    var menu by remember { mutableStateOf(false) }

    LaunchedEffect(b.url, b.showHome, focused) {
        if (!focused) field = TextFieldValue(if (b.showHome) "" else pretty(b.url))
    }

    Row(
        Modifier
            .fillMaxWidth()
            .background(cs.background)
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = { if (b.canGoBack) b.session.goBack() else b.showHome = true },
            enabled = !b.showHome
        ) { DotIcon(DotIcons.Back) }

        IconButton(onClick = { b.session.goForward() }, enabled = b.canGoForward && !b.showHome) {
            DotIcon(DotIcons.Forward)
        }

        Box(
            Modifier
                .weight(1f)
                .height(46.dp)
                .background(cs.surfaceContainerHigh, MaterialTheme.shapes.extraLarge)
                .padding(horizontal = 18.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (field.text.isEmpty()) {
                Text(
                    "Search or enter address",
                    color = cs.onSurfaceVariant,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Serif
                )
            }
            BasicTextField(
                value = field,
                onValueChange = { field = it },
                singleLine = true,
                textStyle = TextStyle(
                    color = cs.onSurface,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Serif
                ),
                cursorBrush = SolidColor(cs.primary),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Uri,
                    imeAction = ImeAction.Go
                ),
                keyboardActions = KeyboardActions(onGo = {
                    b.load(field.text)
                    focus.clearFocus()
                }),
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { s ->
                        focused = s.isFocused
                        if (s.isFocused) {
                            val u = if (b.showHome) "" else b.url
                            field = TextFieldValue(u, TextRange(0, u.length))
                        }
                    }
            )
        }

        IconButton(
            onClick = { if (b.loading) b.session.stop() else b.session.reload() },
            enabled = !b.showHome
        ) { DotIcon(if (b.loading) DotIcons.Close else DotIcons.Reload) }

        Box {
            IconButton(onClick = { menu = true }) { DotIcon(DotIcons.More) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Home") },
                    leadingIcon = { DotIcon(DotIcons.Home) },
                    onClick = { menu = false; b.showHome = true }
                )
                DropdownMenuItem(
                    text = { Text("Appearance") },
                    leadingIcon = { DotIcon(DotIcons.Palette) },
                    onClick = { menu = false; onAppearance() }
                )
                DropdownMenuItem(
                    text = { Text("Set as default browser") },
                    leadingIcon = { DotIcon(DotIcons.Check) },
                    onClick = { menu = false; onSetDefault() }
                )
            }
        }
    }
}
