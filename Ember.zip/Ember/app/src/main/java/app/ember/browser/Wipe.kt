package app.ember.browser

import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs

/**
 * Colour-scheme wipe: three bands in the accent colours sweep across the screen,
 * the data is cleared while the screen is covered, then the bands sweep away.
 */
@Composable
fun WipeOverlay(haptics: Boolean, onCovered: () -> Unit, onDone: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val view = LocalView.current
    val p = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        p.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
        onCovered()
        if (haptics) {
            view.performHapticFeedback(
                if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
                else HapticFeedbackConstants.LONG_PRESS
            )
        }
        delay(380)
        p.animateTo(2f, tween(560, easing = FastOutSlowInEasing))
        onDone()
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {} // block touches while wiping
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            // leading band first, accent colour last so it trails on top
            val layers = listOf(
                0f to cs.tertiary,
                0.07f to cs.primaryContainer,
                0.14f to cs.primary
            )
            for ((lag, color) in layers) {
                val v = (p.value - lag).coerceIn(0f, 2f)
                val left = if (v <= 1f) 0f else (v - 1f) * w
                val right = if (v <= 1f) v * w else w
                if (right > left) {
                    drawRect(color, topLeft = Offset(left, 0f), size = Size(right - left, h))
                }
            }
        }
        val a = (1f - abs(p.value - 1f) * 4f).coerceIn(0f, 1f)
        Text(
            "Clean slate",
            color = cs.onPrimary,
            fontSize = 34.sp,
            fontStyle = FontStyle.Italic,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.Center).graphicsLayer { alpha = a }
        )
    }
}
