package app.ember.browser

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import org.mozilla.geckoview.GeckoSession

private const val T_NONE = GeckoSession.ContentDelegate.ContextElement.TYPE_NONE
private const val T_IMAGE = GeckoSession.ContentDelegate.ContextElement.TYPE_IMAGE
private const val T_VIDEO = GeckoSession.ContentDelegate.ContextElement.TYPE_VIDEO
private const val T_AUDIO = GeckoSession.ContentDelegate.ContextElement.TYPE_AUDIO

private fun copyText(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
}

private fun shareText(ctx: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(i, null))
}

@Composable
private fun MenuAction(label: String, onClick: () -> Unit) {
    TextButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(label, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
    }
}

@Composable
private fun InfoLine(label: String, value: String?) {
    if (value.isNullOrBlank()) return
    Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
    Text(value, style = MaterialTheme.typography.bodySmall, maxLines = 6)
    Spacer(Modifier.height(8.dp))
}

/** The tap-and-hold menu: what you pressed, its full details, and everything you can do with it. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContextMenuSheet(b: BrowserState, library: Library, info: ContextInfo, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val cs = MaterialTheme.colorScheme

    LaunchedEffect(Unit) { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) }

    val link = info.linkUri
    val media = if (info.type != T_NONE) info.srcUri else null
    val kind = when (info.type) {
        T_IMAGE -> "image"
        T_VIDEO -> "video"
        T_AUDIO -> "audio"
        else -> ""
    }
    val heading = when {
        link != null && media != null -> "Linked $kind"
        link != null -> "Link"
        else -> kind.replaceFirstChar { it.uppercase() }
    }

    fun bookmark(url: String, name: String?) {
        if (!library.isBookmarked(url)) library.toggleBookmark(url, name?.takeIf { it.isNotBlank() } ?: url)
        Toast.makeText(ctx, "Saved to bookmarks", Toast.LENGTH_SHORT).show()
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp)
        ) {
            Text(heading, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(10.dp))

            // everything we know about it
            SelectionContainer {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(cs.surfaceContainerHigh, MaterialTheme.shapes.large)
                        .padding(14.dp)
                ) {
                    InfoLine("Type", heading)
                    InfoLine("Link address", link)
                    InfoLine(
                        when (info.type) {
                            T_VIDEO -> "Video address"
                            T_AUDIO -> "Audio address"
                            else -> "Image address"
                        },
                        media
                    )
                    InfoLine("Title", info.title)
                    InfoLine("Description (alt text)", info.alt)
                    InfoLine("Found on", info.baseUri)
                    if (info.privateTab) InfoLine("Tab", "Private")
                }
            }
            Spacer(Modifier.height(10.dp))

            if (link != null) {
                Text("Link", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                MenuAction("Open in new tab") { b.newTab(private = info.privateTab, url = link); onDismiss() }
                MenuAction("Open in new private tab") { b.newTab(private = true, url = link); onDismiss() }
                MenuAction("Copy link") { copyText(ctx, "Link", link); onDismiss() }
                MenuAction("Share link") { shareText(ctx, link); onDismiss() }
                MenuAction("Save link") { b.downloader.saveToDownloads(link); onDismiss() }
                MenuAction("Save link as...") { b.saveAs(link); onDismiss() }
                MenuAction("Save link address (bookmark)") { bookmark(link, info.title); onDismiss() }
                Spacer(Modifier.height(6.dp))
            }

            if (media != null) {
                Text(
                    kind.replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.primary
                )
                MenuAction("Open $kind in new tab") { b.newTab(private = info.privateTab, url = media); onDismiss() }
                MenuAction("Save $kind") { b.downloader.saveToDownloads(media); onDismiss() }
                MenuAction("Save $kind as...") { b.saveAs(media); onDismiss() }
                MenuAction("Copy address") { copyText(ctx, "Address", media); onDismiss() }
                MenuAction("Share address") { shareText(ctx, media); onDismiss() }
                MenuAction("Save $kind address (bookmark)") {
                    bookmark(media, info.title ?: info.alt)
                    onDismiss()
                }
            }
        }
    }
}
