package app.ember.browser

import org.json.JSONObject
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

const val K_UBLOCK = "ublock"
const val K_TRACKERS = "trackers"
const val K_COOKIES = "cookies"
const val K_SOCIAL = "social"
const val K_FINGERPRINT = "fingerprint"
const val K_POPUPS = "popups"
const val K_SAFE = "safe"
const val K_HTTPS = "https_only"
const val K_DOH = "secure_dns"
const val K_CLEAR = "clear_exit"
const val K_DARK = "dark_web"
const val K_READER = "reader"
const val K_PASSWORDS = "passwords"
const val K_LOCK = "lock"
const val K_GLASS = "glass"
const val K_SUGGEST = "suggest"
const val K_MODS = "mods"

val ShieldKeys = listOf(K_UBLOCK, K_TRACKERS, K_COOKIES, K_SOCIAL, K_FINGERPRINT, K_POPUPS, K_SAFE)
val AllToggleKeys = ShieldKeys + listOf(K_HTTPS, K_DOH, K_CLEAR, K_DARK, K_READER, K_PASSWORDS, K_LOCK, K_GLASS, K_SUGGEST, K_MODS)

/** Everything is on by default except the few that change how sites behave. */
fun toggleDefault(key: String): Boolean =
    key != K_HTTPS && key != K_CLEAR && key != K_DARK && key != K_LOCK && key != K_GLASS

class ShieldToggle(val key: String, val title: String, val blurb: String)

val ShieldToggles = listOf(
    ShieldToggle(K_UBLOCK, "uBlock Origin", "Blocks ads, video ads, pop-ups and trackers on every site."),
    ShieldToggle(K_TRACKERS, "Live tracker blocking", "Strict mode: stops ad and analytics trackers as pages load, with a running count."),
    ShieldToggle(K_COOKIES, "Isolate cross-site cookies", "Each site keeps its cookies in its own box, so ads can't follow you around."),
    ShieldToggle(K_SOCIAL, "Block social trackers", "Stops share buttons and embedded widgets from watching you."),
    ShieldToggle(K_FINGERPRINT, "Block fingerprinters and miners", "Blocks scripts that identify your device or mine crypto in the background."),
    ShieldToggle(K_POPUPS, "Block pop-ups", "Ignores new windows that you didn't ask for with a tap."),
    ShieldToggle(K_SAFE, "Malware and phishing protection", "Warns you before loading dangerous sites.")
)

val PrivacyToggles = listOf(
    ShieldToggle(K_HTTPS, "HTTPS-only mode", "Warns before opening any site that doesn't use a secure connection."),
    ShieldToggle(K_DOH, "Secure DNS", "Encrypts site lookups (Cloudflare) and falls back to normal lookups if it fails."),
    ShieldToggle(K_CLEAR, "Clear data on exit", "Wipes cookies, cache and history when Ember closes (or at the next start if Android ended it first)."),
    ShieldToggle(K_PASSWORDS, "Save and fill passwords", "Offers to save logins and fills them in for you. Stored encrypted on this phone."),
    ShieldToggle(K_SUGGEST, "Search suggestions", "Suggests searches as you type a word. What you type is sent to your search engine (never from private tabs)."),
    ShieldToggle(K_LOCK, "Sign in with your phone lock", "Ember asks for your PIN, pattern or fingerprint when you open it, and hides its screen in the recent apps list.")
)

val BrowsingToggles = listOf(
    ShieldToggle(K_DARK, "Prefer dark websites", "Sites that have a dark theme will use it."),
    ShieldToggle(K_READER, "Reader button", "Shows a Reader pill on article pages for a clean, serif reading view."),
    ShieldToggle(K_MODS, "Mods", "Lets the mods you switch on restyle web pages."),
    ShieldToggle(K_GLASS, "Liquid glass bar", "A see-through bottom bar with glossy buttons that catch the light as you tilt your phone.")
)

const val UBLOCK_ID = "uBlock0@raymondhill.net"
const val READER_ID = "reader@ember.app"
const val MODS_ID = "mods@ember.app"
private const val UBLOCK_URI = "resource://android/assets/ublock/"
private const val READER_URI = "resource://android/assets/reader/"
private const val MODS_URI = "resource://android/assets/mods/"

private class Bundled(val uri: String, val id: String) {
    var ext: WebExtension? = null
    var onReady: ((WebExtension) -> Unit)? = null
}

/** Applies the user's toggles to Gecko: tracking protection, network settings and the two built-in extensions. */
object Shield {
    private val ublock = Bundled(UBLOCK_URI, UBLOCK_ID)
    private val reader = Bundled(READER_URI, READER_ID)
    private val modsExt = Bundled(MODS_URI, MODS_ID)

    /** Set by the activity: the CSS of every enabled mod that matches a page address. */
    var cssProvider: ((String) -> String)? = null

    private val modsDelegate = object : WebExtension.MessageDelegate {
        override fun onMessage(
            nativeApp: String,
            message: Any,
            sender: WebExtension.MessageSender
        ): GeckoResult<Any>? {
            val url = (message as? JSONObject)?.optString("url") ?: ""
            val css = try { cssProvider?.invoke(url) ?: "" } catch (e: Exception) { "" }
            return GeckoResult.fromValue<Any>(JSONObject().put("css", css))
        }
    }

    init {
        modsExt.onReady = { ext -> ext.setMessageDelegate(modsDelegate, "ember") }
    }

    fun apply(runtime: GeckoRuntime, prefs: EmberPrefs) {
        val settings = runtime.settings
        val cb = settings.contentBlocking

        var anti = ContentBlocking.AntiTracking.NONE
        if (prefs.on(K_TRACKERS)) {
            anti = anti or ContentBlocking.AntiTracking.AD or ContentBlocking.AntiTracking.ANALYTIC
        }
        if (prefs.on(K_SOCIAL)) anti = anti or ContentBlocking.AntiTracking.SOCIAL
        if (prefs.on(K_FINGERPRINT)) {
            anti = anti or ContentBlocking.AntiTracking.CRYPTOMINING or ContentBlocking.AntiTracking.FINGERPRINTING
        }
        cb.setAntiTracking(anti)
        cb.setEnhancedTrackingProtectionLevel(
            when {
                anti == ContentBlocking.AntiTracking.NONE -> ContentBlocking.EtpLevel.NONE
                prefs.on(K_TRACKERS) -> ContentBlocking.EtpLevel.STRICT
                else -> ContentBlocking.EtpLevel.DEFAULT
            }
        )
        cb.setStrictSocialTrackingProtection(prefs.on(K_SOCIAL))
        cb.setCookieBehavior(
            if (prefs.on(K_COOKIES)) ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS
            else ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS
        )
        cb.setSafeBrowsing(
            if (prefs.on(K_SAFE)) ContentBlocking.SafeBrowsing.DEFAULT
            else ContentBlocking.SafeBrowsing.NONE
        )

        settings.setAllowInsecureConnections(
            if (prefs.on(K_HTTPS)) GeckoRuntimeSettings.HTTPS_ONLY else GeckoRuntimeSettings.ALLOW_ALL
        )
        settings.setTrustedRecursiveResolverUri("https://mozilla.cloudflare-dns.com/dns-query")
        settings.setTrustedRecursiveResolverMode(
            if (prefs.on(K_DOH)) GeckoRuntimeSettings.TRR_MODE_FIRST else GeckoRuntimeSettings.TRR_MODE_OFF
        )
        settings.setPreferredColorScheme(
            if (prefs.on(K_DARK)) GeckoRuntimeSettings.COLOR_SCHEME_DARK else GeckoRuntimeSettings.COLOR_SCHEME_SYSTEM
        )
        settings.setLoginAutofillEnabled(prefs.on(K_PASSWORDS))
        settings.setFontSizeFactor(prefs.fontScale)

        val ctl = runtime.webExtensionController
        sync(ctl, ublock, prefs.on(K_UBLOCK))
        sync(ctl, reader, prefs.on(K_READER))
        sync(ctl, modsExt, prefs.on(K_MODS))
    }

    private fun sync(ctl: WebExtensionController, b: Bundled, enabled: Boolean) {
        val cur = b.ext
        if (enabled) {
            if (cur == null) {
                ctl.ensureBuiltIn(b.uri, b.id).accept { ext ->
                    if (ext != null) {
                        b.ext = ext
                        b.onReady?.invoke(ext)
                        ctl.setAllowedInPrivateBrowsing(ext, true)
                    }
                }
            } else {
                ctl.enable(cur, WebExtensionController.EnableSource.APP)
            }
        } else if (cur != null) {
            ctl.disable(cur, WebExtensionController.EnableSource.APP)
        }
    }

    /** Address of uBlock's dashboard page, once the extension has started. */
    fun ublockDashboardUrl(): String? {
        val base = ublock.ext?.metaData?.baseUrl ?: return null
        return base.trimEnd('/') + "/dashboard.html#3p-filters.html"
    }
}
