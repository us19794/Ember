package app.ember.browser

import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

const val K_UBLOCK = "ublock"
const val K_TRACKERS = "trackers"
const val K_COOKIES = "cookies"
const val K_SOCIAL = "social"
const val K_FINGERPRINT = "fingerprint"
const val K_POPUPS = "popups"
const val K_SAFE = "safe"

val ShieldKeys = listOf(K_UBLOCK, K_TRACKERS, K_COOKIES, K_SOCIAL, K_FINGERPRINT, K_POPUPS, K_SAFE)

class ShieldToggle(val key: String, val title: String, val blurb: String)

val ShieldToggles = listOf(
    ShieldToggle(K_UBLOCK, "uBlock Origin", "Blocks ads, video ads, pop-ups and trackers on every site."),
    ShieldToggle(K_TRACKERS, "Live tracker blocking", "Strict mode: stops ad and analytics trackers as pages load, with a running count."),
    ShieldToggle(K_COOKIES, "Isolate cross-site cookies", "Each site keeps its cookies in its own box, so ads can't follow you around."),
    ShieldToggle(K_SOCIAL, "Block social trackers", "Stops share buttons and embedded widgets from watching you."),
    ShieldToggle(K_FINGERPRINT, "Block fingerprinters and miners", "Blocks scripts that identify your device or mine crypto in the background."),
    ShieldToggle(K_POPUPS, "Block pop-ups", "Ignores new windows that you didn't ask for with a tap."),
    ShieldToggle(K_SAFE, "Malware and phishing protection", "Warns you before loading dangerous sites.")
)

private const val UBLOCK_URI = "resource://android/assets/ublock/"
private const val UBLOCK_ID = "uBlock0@raymondhill.net"

/** Applies the user's shield toggles to Gecko (tracking protection + uBlock Origin). */
object Shield {
    private var ublock: WebExtension? = null

    fun apply(runtime: GeckoRuntime, prefs: EmberPrefs) {
        val cb = runtime.settings.contentBlocking

        var anti = ContentBlocking.AntiTracking.NONE
        if (prefs.on(K_TRACKERS)) {
            anti = anti or ContentBlocking.AntiTracking.AD or ContentBlocking.AntiTracking.ANALYTIC
        }
        if (prefs.on(K_SOCIAL)) anti = anti or ContentBlocking.AntiTracking.SOCIAL
        if (prefs.on(K_FINGERPRINT)) {
            anti = anti or ContentBlocking.AntiTracking.CRYPTOMINING or ContentBlocking.AntiTracking.FINGERPRINTING
        }
        cb.setAntiTracking(anti)
        cb.setEnhancedTrackingProtectionLevel(
            when {
                anti == ContentBlocking.AntiTracking.NONE -> ContentBlocking.EtpLevel.NONE
                prefs.on(K_TRACKERS) -> ContentBlocking.EtpLevel.STRICT
                else -> ContentBlocking.EtpLevel.DEFAULT
            }
        )
        cb.setStrictSocialTrackingProtection(prefs.on(K_SOCIAL))
        cb.setCookieBehavior(
            if (prefs.on(K_COOKIES)) ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS
            else ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS
        )
        cb.setSafeBrowsing(
            if (prefs.on(K_SAFE)) ContentBlocking.SafeBrowsing.DEFAULT
            else ContentBlocking.SafeBrowsing.NONE
        )

        val ctl = runtime.webExtensionController
        val current = ublock
        if (prefs.on(K_UBLOCK)) {
            if (current == null) {
                ctl.ensureBuiltIn(UBLOCK_URI, UBLOCK_ID).accept { ext ->
                    if (ext != null) {
                        ublock = ext
                        ctl.setAllowedInPrivateBrowsing(ext, true)
                    }
                }
            } else {
                ctl.enable(current, WebExtensionController.EnableSource.APP)
            }
        } else if (current != null) {
            ctl.disable(current, WebExtensionController.EnableSource.APP)
        }
    }
}
