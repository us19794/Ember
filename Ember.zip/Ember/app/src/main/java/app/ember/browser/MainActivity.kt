package app.ember.browser

import android.app.Activity
import android.app.KeyguardManager
import android.app.PictureInPictureParams
import android.app.role.RoleManager
import android.content.Intent
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import android.os.SystemClock
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.StorageController

class MainActivity : ComponentActivity() {
    private lateinit var runtime: GeckoRuntime
    private lateinit var browser: BrowserState
    private lateinit var prefs: EmberPrefs
    private lateinit var library: Library
    private lateinit var vault: Vault

    private val roleRequest =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    private var pendingAndroid: ((Boolean) -> Unit)? = null
    private val androidPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            val cb = pendingAndroid
            pendingAndroid = null
            cb?.invoke(res.values.all { it })
        }

    private var pendingSaveAs: ((android.net.Uri) -> Unit)? = null
    private val saveAsLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
            val cb = pendingSaveAs
            pendingSaveAs = null
            if (uri != null) cb?.invoke(uri)
        }

    private var pendingFiles: ((List<Uri>) -> Unit)? = null
    private val pickOne =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val cb = pendingFiles
            pendingFiles = null
            cb?.invoke(if (uri == null) emptyList() else listOf(uri))
        }
    private val pickMany =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val cb = pendingFiles
            pendingFiles = null
            cb?.invoke(uris)
        }

    // sign-in with the phone's own lock
    private var locked by mutableStateOf(false)
    private var unlocking = false
    private var leftAt = 0L

    private var pendingUnlock: ((Boolean) -> Unit)? = null
    private val unlockLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val cb = pendingUnlock
            pendingUnlock = null
            cb?.invoke(r.resultCode == Activity.RESULT_OK)
        }

    /** Pins the window to the highest refresh rate the screen offers (120 Hz on most new phones). */
    @Suppress("DEPRECATION")
    private fun requestHighRefreshRate() {
        try {
            val display = windowManager.defaultDisplay ?: return
            val cur = display.mode
            val best = display.supportedModes
                .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                .maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            lp.preferredRefreshRate = best.refreshRate
            window.attributes = lp
        } catch (e: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        requestHighRefreshRate()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestHighRefreshRate()
        // The UI is always dark, so keep system bar icons light.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )

        runtime = geckoRuntime(this)
        prefs = EmberPrefs(this)
        library = Library(this)
        vault = Vault(this)
        val downloader = Downloader(this, library)

        Shield.apply(runtime, prefs) // tracking protection + uBlock Origin, on from the very first launch
        if (prefs.on(K_CLEAR)) wipeData()

        browser = BrowserState(runtime, prefs, library, vault, downloader)
        browser.androidPermissionRequester = { perms, cb ->
            if (perms.isEmpty()) {
                cb(true)
            } else {
                pendingAndroid = cb
                androidPermLauncher.launch(perms)
            }
        }
        browser.appContext = applicationContext
        browser.filePickerRequester = { multiple, mimes, cb ->
            pendingFiles = cb
            if (multiple) pickMany.launch(mimes) else pickOne.launch(mimes)
        }
        locked = prefs.on(K_LOCK) && deviceIsSecure()
        browser.saveAsRequester = { name, cb ->
            pendingSaveAs = cb
            saveAsLauncher.launch(name)
        }
        intent?.dataString?.let { browser.newTab(url = it) }

        val applyShield = {
            if (prefs.on(K_LOCK) && !deviceIsSecure()) {
                prefs.setToggle(K_LOCK, false)
                Toast.makeText(this, "Set a PIN, pattern or fingerprint on your phone first.", Toast.LENGTH_LONG).show()
            }
            Shield.apply(runtime, prefs)
        }

        setContent {
            EmberTheme(prefs) {
                // hide the app in the recent-apps list while sign-in is switched on
                LaunchedEffect(prefs.on(K_LOCK)) {
                    if (prefs.on(K_LOCK)) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ) {
                    Box(Modifier.fillMaxSize()) {
                        if (!prefs.onboarded) {
                            Onboarding(prefs, onShieldChanged = applyShield) { prefs.finishOnboarding() }
                        } else {
                            BrowserScreen(
                                browser,
                                prefs,
                                library,
                                vault,
                                onSetDefault = ::requestDefaultBrowser,
                                onShieldChanged = applyShield,
                                onUnlock = ::requestUnlock
                            )
                        }
                        if (locked) {
                            LockScreen { requestUnlock { ok -> if (ok) locked = false } }
                        }
                    }
                }
            }
        }
    }

    private fun deviceIsSecure(): Boolean =
        getSystemService(KeyguardManager::class.java)?.isDeviceSecure == true

    override fun onStart() {
        super.onStart()
        if (::prefs.isInitialized && prefs.on(K_LOCK) && !unlocking && leftAt > 0L &&
            SystemClock.elapsedRealtime() - leftAt > 30_000L && deviceIsSecure()
        ) {
            locked = true
        }
    }

    private fun wipeData() {
        runtime.storageController.clearData(StorageController.ClearFlags.ALL)
        library.clearHistory()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.dataString?.let { browser.newTab(url = it) }
    }

    override fun onPause() {
        super.onPause()
        if (::browser.isInitialized) browser.saveTabs()
    }

    override fun onStop() {
        super.onStop()
        leftAt = SystemClock.elapsedRealtime()
        browser.saveTabs()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // keep a full-screen video playing in a small window
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && browser.current.fullscreen) {
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                )
            } catch (e: Exception) {
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing && prefs.on(K_CLEAR)) wipeData()
        super.onDestroy()
    }

    private fun requestUnlock(cb: (Boolean) -> Unit) {
        val km = getSystemService(KeyguardManager::class.java)
        if (km == null || !km.isDeviceSecure) {
            cb(true)
            return
        }
        val i = km.createConfirmDeviceCredentialIntent("Unlock passwords", "Confirm it's you to see saved passwords")
        if (i == null) {
            cb(true)
            return
        }
        unlocking = true
        pendingUnlock = { ok -> unlocking = false; cb(ok) }
        unlockLauncher.launch(i)
    }

    private fun requestDefaultBrowser() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_BROWSER) && !rm.isRoleHeld(RoleManager.ROLE_BROWSER)) {
                roleRequest.launch(rm.createRequestRoleIntent(RoleManager.ROLE_BROWSER))
                return
            }
        }
        startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
    }
}
