package app.ember.browser

import android.graphics.Color as AColor
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(prefs: EmberPrefs, onAppearance: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    var rpm by remember { mutableIntStateOf(0) }

    Column(
        modifier
            .background(cs.background)
            // swallow touches so the web view underneath never sees them
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) awaitPointerEvent().changes.forEach { it.consume() }
                }
            }
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Ember",
                    color = cs.primary,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                    fontStyle = FontStyle.Italic
                )
                Text("a quiet browser", color = cs.onSurfaceVariant, fontSize = 14.sp)
            }
            IconButton(onClick = onAppearance) { DotIcon(DotIcons.Palette, tint = cs.onSurface) }
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                FidgetSpinner(
                    lobeColor = cs.primary,
                    armColor = cs.primaryContainer,
                    holeColor = cs.background,
                    detentColor = cs.outlineVariant,
                    haptics = prefs.haptics,
                    onRpm = { rpm = it }
                )
                Spacer(Modifier.height(20.dp))
                Text(
                    if (rpm > 0) "$rpm rpm" else "spin me",
                    color = cs.onSurfaceVariant,
                    fontSize = 16.sp,
                    fontStyle = FontStyle.Italic
                )
            }
        }

        Text(
            "Search or type an address below",
            color = cs.onSurfaceVariant,
            fontSize = 13.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp)
        )
    }
}

private val Swatches = listOf(
    0xFFFF6A2B, 0xFFFFC24D, 0xFF7BD88F, 0xFF4DA3FF, 0xFFC77DFF, 0xFFFF5C8A, 0xFFE6E6E6
).map { it.toInt() }

private fun hueOf(argb: Int): Float {
    val a = FloatArray(3)
    AColor.colorToHSV(argb, a)
    return a[0]
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppearanceSheet(prefs: EmberPrefs, onDismiss: () -> Unit) {
    var hue by remember { mutableStateOf(hueOf(prefs.seed)) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
                .padding(bottom = 24.dp)
        ) {
            Text("Appearance", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(16.dp))

            Text("Accent colour", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Swatches.forEach { argb ->
                    val selected = prefs.seed == argb
                    Box(
                        Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(argb))
                            .border(
                                if (selected) 3.dp else 1.dp,
                                if (selected) MaterialTheme.colorScheme.onSurface
                                else MaterialTheme.colorScheme.outlineVariant,
                                CircleShape
                            )
                            .clickable {
                                prefs.updateSeed(argb)
                                hue = hueOf(argb)
                            }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Custom hue", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = hue,
                onValueChange = {
                    hue = it
                    prefs.updateSeed(AColor.HSVToColor(floatArrayOf(it, 0.75f, 1f)))
                },
                valueRange = 0f..360f
            )

            SwitchRow("Pure black (AMOLED)", prefs.amoled) { prefs.updateAmoled(it) }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                SwitchRow("Material You (wallpaper colours)", prefs.dynamic) { prefs.updateDynamic(it) }
            }
            SwitchRow("Haptic feedback", prefs.haptics) { prefs.updateHaptics(it) }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
