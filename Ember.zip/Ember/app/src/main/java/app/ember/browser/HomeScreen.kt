package app.ember.browser

import android.graphics.Color as AColor
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    prefs: EmberPrefs,
    library: Library,
    onSettings: () -> Unit,
    onOpen: (String) -> Unit,
    bottomInset: androidx.compose.ui.unit.Dp = 0.dp,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val rpm = remember { mutableIntStateOf(0) }
    val widgetNames = remember { listOf("Spinner", "Tic-Tac-Toe", "Chess", "Sudoku") }

    LaunchedEffect(prefs.homeAutoHourly) {
        while (prefs.homeAutoHourly) {
            val autoIdx = ((System.currentTimeMillis() / 3_600_000L) % 4L).toInt()
            if (prefs.homeWidgetIndex != autoIdx) {
                prefs.updateHomeWidgetIndex(autoIdx)
            }
            delay(30_000L)
        }
    }

    Column(
        modifier
            .background(cs.background)
            // swallow touches so the web view underneath never sees them
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) awaitPointerEvent().changes.forEach { it.consume() }
                }
            }
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .padding(bottom = bottomInset)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Ember",
                    color = cs.primary,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                    fontStyle = FontStyle.Italic
                )
                Text("a quiet browser", color = cs.onSurfaceVariant, fontSize = 14.sp)
            }
            FilledTonalButton(onClick = onSettings) { Text("Settings") }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(top = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = prefs.homeAutoHourly,
                onClick = { prefs.updateHomeAutoHourly(!prefs.homeAutoHourly) },
                label = { Text(if (prefs.homeAutoHourly) "Auto: 1h" else "Manual", fontSize = 12.sp) }
            )
            widgetNames.forEachIndexed { idx, label ->
                FilterChip(
                    selected = prefs.homeWidgetIndex == idx,
                    onClick = {
                        prefs.updateHomeAutoHourly(false)
                        prefs.updateHomeWidgetIndex(idx)
                    },
                    label = { Text(label, fontSize = 12.sp) }
                )
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            when (prefs.homeWidgetIndex) {
                1 -> TicTacToeWidget()
                2 -> ChessPuzzleWidget()
                3 -> SudokuWidget()
                else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FidgetSpinner(
                        lobeColor = cs.primary,
                        armColor = cs.primaryContainer,
                        holeColor = cs.background,
                        detentColor = cs.outlineVariant,
                        haptics = prefs.haptics,
                        onRpm = { rpm.intValue = it }
                    )
                    Spacer(Modifier.height(20.dp))
                    RpmLabel(rpm)
                }
            }
        }

        if (library.bookmarks.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                library.bookmarks.take(8).forEach { b ->
                    FilledTonalButton(onClick = { onOpen(b.url) }) {
                        Text(b.title.take(18), maxLines = 1, fontSize = 13.sp)
                    }
                }
            }
        } else {
            Text(
                "Search or type an address below",
                color = cs.onSurfaceVariant,
                fontSize = 13.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp)
            )
        }
    }
}

@Composable
private fun RpmLabel(rpm: androidx.compose.runtime.MutableIntState) {
    Text(
        if (rpm.intValue > 0) "${rpm.intValue} rpm" else "spin me",
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 16.sp,
        fontStyle = FontStyle.Italic
    )
}

// ---------- shared controls ----------

@Composable
fun ToggleRow(title: String, blurb: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (blurb != null) {
                Text(
                    blurb,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun ToggleList(items: List<ShieldToggle>, prefs: EmberPrefs, onChanged: () -> Unit) {
    items.forEach { t ->
        ToggleRow(t.title, t.blurb, prefs.on(t.key)) {
            prefs.setToggle(t.key, it)
            onChanged()
        }
    }
}

@Composable
fun ShieldSwitches(prefs: EmberPrefs, onChanged: () -> Unit) = ToggleList(ShieldToggles, prefs, onChanged)

private val Swatches = listOf(
    0xFFFF6A2B, 0xFFFFC24D, 0xFF7BD88F, 0xFF4DA3FF, 0xFFC77DFF, 0xFFFF5C8A, 0xFFE6E6E6
).map { it.toInt() }

private fun hueOf(argb: Int): Float {
    val a = FloatArray(3)
    AColor.colorToHSV(argb, a)
    return a[0]
}

@Composable
fun ColourControls(prefs: EmberPrefs, showHaptics: Boolean = true) {
    var hue by remember { mutableStateOf(hueOf(prefs.seed)) }

    Text("Accent colour", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(10.dp))
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Swatches.forEach { argb ->
            val selected = prefs.seed == argb
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(argb))
                    .border(
                        if (selected) 3.dp else 1.dp,
                        if (selected) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.outlineVariant,
                        CircleShape
                    )
                    .clickable {
                        prefs.updateSeed(argb)
                        hue = hueOf(argb)
                    }
            )
        }
    }

    Spacer(Modifier.height(14.dp))
    Text("Custom hue", style = MaterialTheme.typography.titleMedium)
    Slider(
        value = hue,
        onValueChange = {
            hue = it
            prefs.updateSeed(AColor.HSVToColor(floatArrayOf(it, 0.75f, 1f)))
        },
        valueRange = 0f..360f
    )

    ToggleRow("Pure black (AMOLED)", null, prefs.amoled) { prefs.updateAmoled(it) }
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
        ToggleRow("Material You (wallpaper colours)", null, prefs.dynamic) { prefs.updateDynamic(it) }
    }
    if (showHaptics) {
        ToggleRow("Haptic feedback", null, prefs.haptics) { prefs.updateHaptics(it) }
    }
}
