package app.ember.browser

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs

fun tabLabel(t: BrowserTab): String = when {
    t.showHome -> "New tab"
    t.title.isNotBlank() -> t.title
    else -> prettyUrl(t.url)
}

// ---------------- top tabs (like Chrome) ----------------

@Composable
fun TopTabStrip(b: BrowserState, onSwitch: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val listState = rememberLazyListState()
    LaunchedEffect(b.selected, b.tabs.size) {
        if (b.tabs.isNotEmpty()) listState.animateScrollToItem(b.selected.coerceIn(0, b.tabs.lastIndex))
    }
    Row(
        Modifier.fillMaxWidth().height(42.dp).background(cs.surfaceContainer),
        verticalAlignment = Alignment.Bottom
    ) {
        LazyRow(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxHeight(),
            contentPadding = PaddingValues(start = 6.dp, end = 6.dp, top = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            itemsIndexed(b.tabs.toList()) { i, t ->
                val sel = i == b.selected
                Row(
                    Modifier
                        .widthIn(min = 90.dp, max = 170.dp)
                        .fillMaxHeight()
                        .background(
                            if (sel) cs.background else cs.surfaceContainerHigh,
                            RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
                        )
                        .clickable { onSwitch(i) }
                        .padding(start = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        (if (t.isPrivate) "Private: " else "") + tabLabel(t),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 13.sp,
                        color = if (sel) cs.onSurface else cs.onSurfaceVariant,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Text(
                        "×",
                        fontSize = 18.sp,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.clickable { b.closeTab(i) }.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
        TextButton(onClick = { b.newTab() }) { Text("New") }
    }
}

// ---------------- vertical tabs (side panel) ----------------

private sealed class TabEntry {
    class Header(val text: String) : TabEntry()
    class Item(val index: Int, val tab: BrowserTab) : TabEntry()
}

private fun entries(b: BrowserState): List<TabEntry> {
    val idx = b.tabs.withIndex().toList()
    val out = ArrayList<TabEntry>()
    val pinned = idx.filter { it.value.pinned }
    if (pinned.isNotEmpty()) {
        out.add(TabEntry.Header("Pinned"))
        pinned.forEach { out.add(TabEntry.Item(it.index, it.value)) }
    }
    b.groupNames().forEach { g ->
        val l = idx.filter { !it.value.pinned && it.value.group == g }
        if (l.isNotEmpty()) {
            out.add(TabEntry.Header(g))
            l.forEach { out.add(TabEntry.Item(it.index, it.value)) }
        }
    }
    val rest = idx.filter { !it.value.pinned && it.value.group.isBlank() }
    if (rest.isNotEmpty()) {
        out.add(TabEntry.Header("Tabs"))
        rest.forEach { out.add(TabEntry.Item(it.index, it.value)) }
    }
    return out
}

@Composable
fun VerticalTabsDrawer(
    b: BrowserState,
    visible: Boolean,
    onSwitch: (Int) -> Unit,
    onGroup: (BrowserTab) -> Unit,
    onClose: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.45f))
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onClose() }
        )
    }
    AnimatedVisibility(
        visible = visible,
        enter = slideInHorizontally { -it },
        exit = slideOutHorizontally { -it }
    ) {
        Column(
            Modifier
                .fillMaxHeight()
                .width(292.dp)
                .background(cs.surfaceContainer)
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(12.dp)
        ) {
            Text("Tabs", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { b.newTab(); onClose() }) { Text("New tab") }
                OutlinedButton(onClick = { b.newTab(private = true); onClose() }) { Text("Private") }
            }
            Spacer(Modifier.height(10.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(entries(b)) { e ->
                    when (e) {
                        is TabEntry.Header -> Text(
                            e.text,
                            style = MaterialTheme.typography.labelLarge,
                            color = cs.primary,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                        is TabEntry.Item -> {
                            val t = e.tab
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .background(
                                        if (e.index == b.selected) cs.primaryContainer else cs.surfaceContainerHigh,
                                        MaterialTheme.shapes.large
                                    )
                                    .clickable { onSwitch(e.index); onClose() }
                                    .padding(start = 14.dp, top = 8.dp, end = 6.dp)
                            ) {
                                Text(tabLabel(t), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    (if (t.isPrivate) "Private - " else "") + (if (t.showHome) "Home" else prettyUrl(t.url)),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant
                                )
                                Row {
                                    TextButton(onClick = { b.togglePin(t) }) { Text(if (t.pinned) "Unpin" else "Pin") }
                                    TextButton(onClick = { onGroup(t) }) { Text(if (t.group.isBlank()) "Group" else "Move") }
                                    TextButton(onClick = { b.closeTab(e.index) }) { Text("Close") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- sliding cards (like Android / iPhone multitasking) ----------------

@Composable
fun TabCardsOverlay(b: BrowserState, onGroup: (BrowserTab) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    BackHandler { onDismiss() }

    Box(
        Modifier
            .fillMaxSize()
            .background(cs.background.copy(alpha = 0.97f))
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) awaitPointerEvent().changes.forEach { it.consume() }
                }
            }
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${b.tabs.size} " + if (b.tabs.size == 1) "tab" else "tabs",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { b.reopenClosed() }, enabled = b.closedCount > 0) { Text("Reopen closed") }
                TextButton(onClick = onDismiss) { Text("Done") }
            }
            Text(
                "Swipe sideways to browse, tap to open, swipe a card up to close it.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp)
            )

            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp)) {
                val cardW = 280.dp
                val pad = ((maxWidth - cardW) / 2).coerceAtLeast(0.dp)
                val pager = rememberPagerState(initialPage = b.selected.coerceIn(0, (b.tabs.size - 1).coerceAtLeast(0))) {
                    b.tabs.size
                }
                HorizontalPager(
                    state = pager,
                    pageSize = PageSize.Fixed(cardW),
                    contentPadding = PaddingValues(horizontal = pad),
                    pageSpacing = 16.dp,
                    key = { b.tabs.getOrNull(it)?.hashCode() ?: it },
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    val t = b.tabs.getOrNull(page)
                    if (t != null) {
                        TabCard(b, t, selected = page == b.selected, onGroup = onGroup) {
                            b.select(page)
                            onDismiss()
                        }
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
            ) {
                FilledTonalButton(onClick = { b.newTab(); onDismiss() }) { Text("New tab") }
                OutlinedButton(onClick = { b.newTab(private = true); onDismiss() }) { Text("New private tab") }
            }
        }
    }
}

@Composable
private fun TabCard(
    b: BrowserState,
    tab: BrowserTab,
    selected: Boolean,
    onGroup: (BrowserTab) -> Unit,
    onOpen: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val off = remember(tab) { Animatable(0f) }
    val shape = RoundedCornerShape(24.dp)

    Column(
        Modifier
            .fillMaxSize()
            .padding(vertical = 8.dp)
            .graphicsLayer {
                translationY = off.value
                alpha = (1f - abs(off.value) / 900f).coerceIn(0f, 1f)
            }
            .pointerInput(tab) {
                detectVerticalDragGestures(
                    onVerticalDrag = { change, dy ->
                        change.consume()
                        scope.launch { off.snapTo((off.value + dy).coerceAtMost(40f)) }
                    },
                    onDragEnd = {
                        scope.launch {
                            if (off.value < -240f) {
                                off.animateTo(-1400f, tween(180))
                                b.closeTab(b.tabs.indexOf(tab))
                            } else {
                                off.animateTo(0f)
                            }
                        }
                    },
                    onDragCancel = { scope.launch { off.animateTo(0f) } }
                )
            }
    ) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(shape)
                .border(if (selected) 2.dp else 1.dp, if (selected) cs.primary else cs.outlineVariant, shape)
                .clickable(onClick = onOpen)
        ) {
            val thumb = tab.thumb
            if (thumb != null) {
                Image(
                    bitmap = thumb,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alignment = Alignment.TopCenter,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(cs.primaryContainer, cs.surfaceContainer))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        (if (tab.showHome) "E" else prettyUrl(tab.url).take(1).uppercase().ifEmpty { "E" }),
                        fontSize = 72.sp,
                        fontFamily = FontFamily.Serif,
                        fontStyle = FontStyle.Italic,
                        fontWeight = FontWeight.Bold,
                        color = cs.onPrimaryContainer.copy(alpha = 0.6f)
                    )
                }
            }
            Column(
                Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.78f), Color.Transparent)))
                    .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 26.dp)
            ) {
                Text(
                    tabLabel(tab),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    listOfNotNull(
                        if (tab.isPrivate) "Private" else null,
                        if (tab.pinned) "Pinned" else null,
                        tab.group.takeIf { it.isNotBlank() },
                        if (tab.showHome) "Home" else prettyUrl(tab.url)
                    ).joinToString(" · "),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 12.sp
                )
            }
        }
        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = { b.togglePin(tab) }) { Text(if (tab.pinned) "Unpin" else "Pin") }
            TextButton(onClick = { onGroup(tab) }) { Text(if (tab.group.isBlank()) "Group" else "Move") }
            TextButton(onClick = { b.closeTab(b.tabs.indexOf(tab)) }) { Text("Close") }
        }
    }
}
