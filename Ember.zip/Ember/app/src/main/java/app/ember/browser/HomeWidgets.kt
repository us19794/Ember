package app.ember.browser

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

// ==================== 1. TIC-TAC-TOE ====================

@Composable
fun TicTacToeWidget() {
    val cs = MaterialTheme.colorScheme
    val board = remember { mutableStateListOf(*Array(9) { "" }) }
    var status by remember { mutableStateOf("Your turn (X)") }
    var gameOver by remember { mutableStateOf(false) }

    fun winnerOf(b: List<String>): String? {
        val lines = arrayOf(
            intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(6, 7, 8),
            intArrayOf(0, 3, 6), intArrayOf(1, 4, 7), intArrayOf(2, 5, 8),
            intArrayOf(0, 4, 8), intArrayOf(2, 4, 6)
        )
        for (l in lines) {
            if (b[l[0]].isNotEmpty() && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) return b[l[0]]
        }
        return null
    }

    fun pickAiMove(b: List<String>): Int {
        val empty = b.indices.filter { b[it].isEmpty() }
        if (empty.isEmpty()) return -1
        // 1. Win if possible
        for (i in empty) {
            val copy = b.toMutableList().apply { this[i] = "O" }
            if (winnerOf(copy) == "O") return i
        }
        // 2. Block X
        for (i in empty) {
            val copy = b.toMutableList().apply { this[i] = "X" }
            if (winnerOf(copy) == "X") return i
        }
        // 3. Center or random corner/side
        if (4 in empty && Random.nextFloat() < 0.75f) return 4
        return empty.random()
    }

    fun reset() {
        for (i in 0 until 9) board[i] = ""
        status = "Your turn (X)"
        gameOver = false
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(status, color = cs.onSurfaceVariant, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(12.dp))
        Column(
            modifier = Modifier
                .size(228.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(cs.surfaceContainerLow)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (r in 0 until 3) {
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (c in 0 until 3) {
                        val idx = r * 3 + c
                        val v = board[idx]
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .clip(RoundedCornerShape(12.dp))
                                .background(cs.surfaceContainerHigh)
                                .clickable(enabled = !gameOver && v.isEmpty()) {
                                    board[idx] = "X"
                                    when {
                                        winnerOf(board) == "X" -> {
                                            status = "You win!"
                                            gameOver = true
                                        }
                                        board.none { it.isEmpty() } -> {
                                            status = "Draw"
                                            gameOver = true
                                        }
                                        else -> {
                                            val ai = pickAiMove(board)
                                            if (ai >= 0) board[ai] = "O"
                                            when {
                                                winnerOf(board) == "O" -> {
                                                    status = "Ember wins!"
                                                    gameOver = true
                                                }
                                                board.none { it.isEmpty() } -> {
                                                    status = "Draw"
                                                    gameOver = true
                                                }
                                                else -> status = "Your turn (X)"
                                            }
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = v,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (v == "X") cs.primary else cs.onSurface
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        FilledTonalButton(onClick = ::reset) { Text("New game") }
    }
}

// ==================== 2. BEST MOVE IN CHESS ====================

private data class ChessPuzzle(
    val title: String,
    val pieces: Map<Int, String>, // index 0..63 (row*8 + col, row 0 = rank 8)
    val from: Int,
    val to: Int,
    val solutionLabel: String
)

private fun sq(file: Char, rank: Int): Int = (8 - rank) * 8 + (file - 'a')

private val ChessPuzzles = listOf(
    ChessPuzzle(
        title = "White to move · Mate in 1",
        pieces = mapOf(
            sq('g', 1) to "♔", sq('e', 1) to "♖", sq('f', 2) to "♙", sq('g', 2) to "♙", sq('h', 2) to "♙",
            sq('g', 8) to "♚", sq('a', 8) to "♜", sq('f', 7) to "♟", sq('g', 7) to "♟", sq('h', 7) to "♟"
        ),
        from = sq('e', 1), to = sq('e', 8), solutionLabel = "Re8#"
    ),
    ChessPuzzle(
        title = "White to move · Mate in 1",
        pieces = mapOf(
            sq('g', 1) to "♔", sq('d', 3) to "♕", sq('c', 2) to "♗", sq('f', 2) to "♙", sq('g', 2) to "♙", sq('h', 2) to "♙",
            sq('g', 8) to "♚", sq('f', 8) to "♜", sq('f', 7) to "♟", sq('g', 7) to "♟", sq('h', 6) to "♟"
        ),
        from = sq('d', 3), to = sq('h', 7), solutionLabel = "Qh7#"
    ),
    ChessPuzzle(
        title = "White to move · Smothered mate",
        pieces = mapOf(
            sq('g', 1) to "♔", sq('g', 5) to "♘", sq('f', 2) to "♙", sq('g', 2) to "♙", sq('h', 2) to "♙",
            sq('h', 8) to "♚", sq('g', 8) to "♜", sq('g', 7) to "♟", sq('h', 7) to "♟"
        ),
        from = sq('g', 5), to = sq('f', 7), solutionLabel = "Nf7#"
    ),
    ChessPuzzle(
        title = "White to move · Win the rook",
        pieces = mapOf(
            sq('g', 1) to "♔", sq('d', 5) to "♘",
            sq('e', 8) to "♚", sq('a', 8) to "♜", sq('d', 7) to "♟", sq('e', 7) to "♟", sq('f', 7) to "♟"
        ),
        from = sq('d', 5), to = sq('c', 7), solutionLabel = "Nc7+"
    ),
    ChessPuzzle(
        title = "White to move · Arabian mate",
        pieces = mapOf(
            sq('g', 1) to "♔", sq('e', 7) to "♖", sq('f', 6) to "♘",
            sq('h', 8) to "♚", sq('a', 7) to "♟"
        ),
        from = sq('e', 7), to = sq('h', 7), solutionLabel = "Rh7#"
    ),
    ChessPuzzle(
        title = "White to move · Mate in 1",
        pieces = mapOf(
            sq('g', 1) to "♔", sq('f', 6) to "♕", sq('h', 6) to "♗",
            sq('g', 8) to "♚", sq('f', 8) to "♜", sq('f', 7) to "♟", sq('h', 7) to "♟"
        ),
        from = sq('f', 6), to = sq('g', 7), solutionLabel = "Qg7#"
    )
)

private val WhitePieces = setOf("♔", "♕", "♖", "♗", "♘", "♙")

@Composable
fun ChessPuzzleWidget() {
    val cs = MaterialTheme.colorScheme
    var puzzleIdx by remember { mutableIntStateOf(0) }
    val puzzle = ChessPuzzles[puzzleIdx % ChessPuzzles.size]
    var selected by remember(puzzleIdx) { mutableStateOf<Int?>(null) }
    var solved by remember(puzzleIdx) { mutableStateOf(false) }
    var feedback by remember(puzzleIdx) { mutableStateOf(puzzle.title) }
    var showHint by remember(puzzleIdx) { mutableStateOf(false) }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            feedback,
            color = if (solved) cs.primary else cs.onSurfaceVariant,
            fontSize = 14.sp,
            fontWeight = if (solved) FontWeight.Bold else FontWeight.Medium
        )
        Spacer(Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .size(248.dp)
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, cs.outlineVariant, RoundedCornerShape(14.dp))
        ) {
            for (r in 0 until 8) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    for (c in 0 until 8) {
                        val idx = r * 8 + c
                        val dark = (r + c) % 2 == 1
                        val piece = when {
                            solved && idx == puzzle.to -> puzzle.pieces[puzzle.from]
                            solved && idx == puzzle.from -> null
                            else -> puzzle.pieces[idx]
                        }
                        val isSelected = selected == idx || (showHint && idx == puzzle.from)
                        val isSolvedTarget = solved && idx == puzzle.to
                        val bg = when {
                            isSolvedTarget -> cs.primary.copy(alpha = 0.45f)
                            isSelected -> cs.primary.copy(alpha = 0.30f)
                            dark -> cs.surfaceContainerHigh
                            else -> cs.surfaceContainerLow
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .background(bg)
                                .clickable(enabled = !solved) {
                                    val curSel = selected
                                    if (curSel == null) {
                                        if (piece != null && piece in WhitePieces) {
                                            selected = idx
                                        }
                                    } else if (curSel == idx) {
                                        selected = null
                                    } else if (piece != null && piece in WhitePieces) {
                                        selected = idx
                                    } else {
                                        if (curSel == puzzle.from && idx == puzzle.to) {
                                            solved = true
                                            selected = null
                                            feedback = "Best move: ${puzzle.solutionLabel}"
                                        } else {
                                            selected = null
                                            feedback = "Not the best move — try again"
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (piece != null) {
                                Text(
                                    text = piece,
                                    fontSize = 19.sp,
                                    color = if (piece in WhitePieces) Color.White else Color(0xFFB8BEC8)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { showHint = true; selected = puzzle.from }) { Text("Hint") }
            FilledTonalButton(onClick = { puzzleIdx = (puzzleIdx + 1) % ChessPuzzles.size }) {
                Text("Next puzzle")
            }
        }
    }
}

// ==================== 3. SUDOKU ====================

private data class SudokuGame(val clues: IntArray, val solution: IntArray)

private fun generateSudoku(): SudokuGame {
    val base = intArrayOf(
        5, 3, 4, 6, 7, 8, 9, 1, 2,
        6, 7, 2, 1, 9, 5, 3, 4, 8,
        1, 9, 8, 3, 4, 2, 5, 6, 7,
        8, 5, 9, 7, 6, 1, 4, 2, 3,
        4, 2, 6, 8, 5, 3, 7, 9, 1,
        7, 1, 3, 9, 2, 4, 8, 5, 6,
        9, 6, 1, 5, 3, 7, 2, 8, 4,
        2, 8, 7, 4, 1, 9, 6, 3, 5,
        3, 4, 5, 2, 8, 6, 1, 7, 9
    )
    // Shuffle digits 1..9 and swap rows/cols within bands to produce a fresh valid grid
    val digits = (1..9).shuffled()
    val rowOrder = (0..2).flatMap { band -> (0..2).shuffled().map { band * 3 + it } }
    val colOrder = (0..2).flatMap { band -> (0..2).shuffled().map { band * 3 + it } }
    val sol = IntArray(81)
    for (r in 0 until 9) {
        for (c in 0 until 9) {
            val v = base[rowOrder[r] * 9 + colOrder[c]]
            sol[r * 9 + c] = digits[v - 1]
        }
    }
    val clues = sol.copyOf()
    val indices = (0 until 81).shuffled().take(42)
    for (i in indices) clues[i] = 0
    return SudokuGame(clues, sol)
}

@Composable
fun SudokuWidget() {
    val cs = MaterialTheme.colorScheme
    var game by remember { mutableStateOf(generateSudoku()) }
    val entries = remember(game) { mutableStateListOf(*game.clues.toTypedArray()) }
    var selected by remember(game) { mutableIntStateOf(-1) }
    var solved by remember(game) { mutableStateOf(false) }

    fun checkSolved() {
        if ((0 until 81).all { entries[it] == game.solution[it] }) {
            solved = true
        }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            if (solved) "Sudoku solved!" else "Tap a cell, then a number",
            color = if (solved) cs.primary else cs.onSurfaceVariant,
            fontSize = 13.sp,
            fontWeight = if (solved) FontWeight.Bold else FontWeight.Normal
        )
        Spacer(Modifier.height(8.dp))

        Column(
            modifier = Modifier
                .size(234.dp)
                .border(1.5.dp, cs.outline, RoundedCornerShape(8.dp))
                .clip(RoundedCornerShape(8.dp))
        ) {
            for (r in 0 until 9) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    for (c in 0 until 9) {
                        val idx = r * 9 + c
                        val isClue = game.clues[idx] != 0
                        val valNum = entries[idx]
                        val isSel = selected == idx
                        val sameNum = selected >= 0 && entries[selected] != 0 && entries[selected] == valNum
                        val bg = when {
                            isSel -> cs.primary.copy(alpha = 0.28f)
                            sameNum -> cs.primary.copy(alpha = 0.12f)
                            ((r / 3) + (c / 3)) % 2 == 0 -> cs.surfaceContainerLow
                            else -> cs.surfaceContainer
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .background(bg)
                                .border(0.5.dp, cs.outlineVariant.copy(alpha = 0.5f))
                                .clickable(enabled = !isClue && !solved) { selected = idx },
                            contentAlignment = Alignment.Center
                        ) {
                            if (valNum != 0) {
                                Text(
                                    text = valNum.toString(),
                                    fontSize = 13.sp,
                                    fontWeight = if (isClue) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isClue) cs.onSurface else cs.primary
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally)
        ) {
            for (n in 1..9) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(cs.surfaceContainerHigh)
                        .clickable(enabled = selected >= 0 && !solved && game.clues[selected] == 0) {
                            entries[selected] = n
                            checkSolved()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(n.toString(), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                }
            }
            Box(
                modifier = Modifier
                    .width(34.dp)
                    .height(28.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(cs.surfaceContainerHigh)
                    .clickable(enabled = selected >= 0 && !solved && game.clues[selected] == 0) {
                        entries[selected] = 0
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("⌫", fontSize = 13.sp, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(8.dp))
        FilledTonalButton(
            onClick = { game = generateSudoku() },
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            modifier = Modifier.height(34.dp)
        ) { Text("New puzzle", fontSize = 12.sp) }
    }
}
