package app.ember.browser

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

data class AssistantReply(
    val text: String,
    val searchUrl: String? = null
)

/**
 * Fast, zero-config answer engine for the Ember assistant overlay:
 * - Instant local replies for time, date, and math expressions.
 * - Live concise answers via DuckDuckGo Instant Answer + Wikipedia REST APIs.
 */
object AssistantBrain {
    private val mainHandler = Handler(Looper.getMainLooper())

    fun answer(query: String, onResult: (AssistantReply) -> Unit) {
        val q = query.trim()
        if (q.isEmpty()) {
            onResult(AssistantReply("Didn't catch that. Tap the orb to try again."))
            return
        }

        localAnswer(q)?.let {
            onResult(AssistantReply(it))
            return
        }

        thread(start = true) {
            val reply = fetchOnlineAnswer(q)
            mainHandler.post { onResult(reply) }
        }
    }

    private fun localAnswer(raw: String): String? {
        val q = raw.lowercase(Locale.getDefault()).trim().trimEnd('?', '.', '!')

        if (q == "what time is it" || q == "time" || q == "current time" || q == "what is the time" || q == "tell me the time") {
            val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
            return "It's ${fmt.format(Date())}."
        }
        if (q == "what's the date" || q == "what is the date" || q == "today's date" || q == "what day is it" || q == "what's today's date" || q == "date") {
            val fmt = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault())
            return "Today is ${fmt.format(Date())}."
        }

        // Quick math: "what is 25 * 48", "calculate 100 / 4", "15 + 27"
        val mathCandidate = q
            .removePrefix("what is ")
            .removePrefix("what's ")
            .removePrefix("calculate ")
            .removePrefix("compute ")
            .replace("times", "*")
            .replace("multiplied by", "*")
            .replace("divided by", "/")
            .replace("plus", "+")
            .replace("minus", "-")
            .replace("x", "*")
            .trim()
        if (mathCandidate.any { it.isDigit() } &&
            mathCandidate.any { it in "+-*/" } &&
            mathCandidate.all { it.isDigit() || it in "+-*/.() " }
        ) {
            evalMath(mathCandidate)?.let { res ->
                val formatted = if (abs(res - res.toLong()) < 1e-9) res.toLong().toString()
                else String.format(Locale.US, "%.4f", res).trimEnd('0').trimEnd('.')
                return "$mathCandidate = $formatted"
            }
        }
        return null
    }

    private fun fetchOnlineAnswer(query: String): AssistantReply {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val searchUrl = "https://duckduckgo.com/?q=$encoded"

        // 1. DuckDuckGo Instant Answer API
        try {
            val ddgJson = httpGet("https://api.duckduckgo.com/?q=$encoded&format=json&no_html=1&skip_disambig=1")
            if (ddgJson != null) {
                val obj = JSONObject(ddgJson)
                val answer = obj.optString("Answer").trim()
                if (answer.isNotEmpty()) return AssistantReply(answer, searchUrl)

                val absText = obj.optString("AbstractText").trim()
                if (absText.isNotEmpty()) return AssistantReply(trimToSentences(absText, 3), searchUrl)

                val defText = obj.optString("Definition").trim()
                if (defText.isNotEmpty()) return AssistantReply(trimToSentences(defText, 3), searchUrl)
            }
        } catch (_: Exception) {
        }

        // 2. Wikipedia Search -> Summary REST API
        try {
            val cleanQuery = query
                .replace(Regex("^(who is|who was|what is|what are|what was|tell me about|define|explain)\\s+", RegexOption.IGNORE_CASE), "")
                .trim()
            val wikiEnc = URLEncoder.encode(cleanQuery.ifEmpty { query }, "UTF-8")
            val searchJson = httpGet("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=$wikiEnc&srlimit=1&format=json")
            if (searchJson != null) {
                val hits = JSONObject(searchJson).optJSONObject("query")?.optJSONArray("search")
                if (hits != null && hits.length() > 0) {
                    val title = hits.getJSONObject(0).optString("title")
                    if (title.isNotEmpty()) {
                        val titleSlug = URLEncoder.encode(title.replace(' ', '_'), "UTF-8")
                        val sumJson = httpGet("https://en.wikipedia.org/api/rest_v1/page/summary/$titleSlug")
                        if (sumJson != null) {
                            val extract = JSONObject(sumJson).optString("extract").trim()
                            if (extract.isNotEmpty()) {
                                return AssistantReply(trimToSentences(extract, 3), searchUrl)
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }

        return AssistantReply(
            "I couldn't find an instant summary for \"$query\". Tap below to view full results in Ember.",
            searchUrl
        )
    }

    private fun trimToSentences(text: String, maxSentences: Int): String {
        val parts = text.split(Regex("(?<=[.!?])\\s+"))
        return parts.take(maxSentences).joinToString(" ").trim()
    }

    private fun httpGet(urlStr: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("User-Agent", "EmberBrowser/1.0 (Android)")
            }
            if (conn.responseCode in 200..299) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else null
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun evalMath(expr: String): Double? {
        return try {
            object {
                var pos = -1
                var ch = 0
                fun nextChar() { ch = if (++pos < expr.length) expr[pos].code else -1 }
                fun eat(charToEat: Int): Boolean {
                    while (ch == ' '.code) nextChar()
                    if (ch == charToEat) { nextChar(); return true }
                    return false
                }
                fun parse(): Double {
                    nextChar()
                    val x = parseExpression()
                    if (pos < expr.length) throw RuntimeException("Unexpected")
                    return x
                }
                fun parseExpression(): Double {
                    var x = parseTerm()
                    while (true) {
                        when {
                            eat('+'.code) -> x += parseTerm()
                            eat('-'.code) -> x -= parseTerm()
                            else -> return x
                        }
                    }
                }
                fun parseTerm(): Double {
                    var x = parseFactor()
                    while (true) {
                        when {
                            eat('*'.code) -> x *= parseFactor()
                            eat('/'.code) -> x /= parseFactor()
                            else -> return x
                        }
                    }
                }
                fun parseFactor(): Double {
                    if (eat('+'.code)) return parseFactor()
                    if (eat('-'.code)) return -parseFactor()
                    val startPos = pos
                    val x: Double
                    if (eat('('.code)) {
                        x = parseExpression()
                        if (!eat(')'.code)) throw RuntimeException("Missing )")
                    } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                        while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                        x = expr.substring(startPos, pos).toDouble()
                    } else {
                        throw RuntimeException("Unexpected")
                    }
                    return x
                }
            }.parse()
        } catch (_: Exception) {
            null
        }
    }
}
