package app.ember.browser

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.widget.Toast
import org.mozilla.geckoview.WebResponse
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

private const val FETCH_UA = "Mozilla/5.0 (Android 15; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0"

/** Saves files into the phone's Downloads folder, or into a place you pick. */
class Downloader(private val context: Context, private val library: Library) {
    private val main = Handler(Looper.getMainLooper())

    private fun toast(text: String) = main.post { Toast.makeText(context, text, Toast.LENGTH_SHORT).show() }

    /** A download that Gecko already fetched and hands over as a stream. */
    fun handle(response: WebResponse) {
        val body = response.body ?: return
        val headers = response.headers
        fun header(name: String): String? =
            headers.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value
        val mime = header("content-type")?.substringBefore(';')?.trim()
        val name = URLUtil.guessFileName(response.uri, header("content-disposition"), mime)
        toast("Downloading $name")
        Thread {
            try {
                val uri = save(name, mime ?: "application/octet-stream", body)
                done(name, uri, mime)
            } catch (e: Exception) {
                try { body.close() } catch (ignored: Exception) { }
                toast("Download failed")
            }
        }.start()
    }

    private class Fetched(val stream: InputStream, val mime: String?, val disposition: String?)

    private fun open(url: String): Fetched {
        if (url.startsWith("data:")) {
            val comma = url.indexOf(',')
            if (comma < 0) throw IllegalArgumentException("Bad data address")
            val meta = url.substring(5, comma)
            val data = url.substring(comma + 1)
            val bytes = if (meta.endsWith(";base64")) Base64.decode(data, Base64.DEFAULT)
            else Uri.decode(data).toByteArray()
            return Fetched(ByteArrayInputStream(bytes), meta.substringBefore(';').ifBlank { null }, null)
        }
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            throw IllegalArgumentException("This kind of address can't be saved")
        }
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", FETCH_UA)
        c.connect()
        if (c.responseCode !in 200..299) throw IllegalStateException("HTTP " + c.responseCode)
        return Fetched(c.inputStream, c.contentType?.substringBefore(';')?.trim(), c.getHeaderField("Content-Disposition"))
    }

    /** A sensible file name to suggest for an address. */
    fun suggestName(url: String): String {
        if (url.startsWith("data:")) {
            val mime = url.substringAfter("data:").substringBefore(';').substringBefore(',')
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
            return "file.$ext"
        }
        return URLUtil.guessFileName(url, null, null)
    }

    /** Fetches an address and saves it into Downloads. */
    fun saveToDownloads(url: String) {
        toast("Downloading...")
        Thread {
            try {
                val f = open(url)
                val name = if (url.startsWith("data:")) suggestName(url)
                else URLUtil.guessFileName(url, f.disposition, f.mime)
                val uri = save(name, f.mime ?: "application/octet-stream", f.stream)
                done(name, uri, f.mime)
            } catch (e: Exception) {
                toast("Couldn't save: " + (e.message ?: "download failed"))
            }
        }.start()
    }

    /** Fetches an address and writes it to a place the user picked. */
    fun saveToUri(url: String, target: Uri) {
        toast("Saving...")
        Thread {
            try {
                val f = open(url)
                f.stream.use { src ->
                    context.contentResolver.openOutputStream(target)!!.use { out -> src.copyTo(out) }
                }
                toast("Saved")
            } catch (e: Exception) {
                toast("Couldn't save: " + (e.message ?: "download failed"))
            }
        }.start()
    }

    private fun done(name: String, uri: Uri, mime: String?) {
        main.post {
            library.addDownload(DownloadItem(name, uri.toString(), mime ?: "", System.currentTimeMillis()))
            Toast.makeText(context, "Saved to Downloads: $name", Toast.LENGTH_LONG).show()
        }
    }

    private fun save(name: String, mime: String, input: InputStream): Uri {
        input.use { src ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create file")
                resolver.openOutputStream(uri)!!.use { out -> src.copyTo(out) }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                return uri
            } else {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                    ?: throw IllegalStateException("No storage")
                val f = File(dir, name)
                f.outputStream().use { out -> src.copyTo(out) }
                return Uri.fromFile(f)
            }
        }
    }
}
