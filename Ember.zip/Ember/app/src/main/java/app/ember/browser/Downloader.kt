package app.ember.browser

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.URLUtil
import android.widget.Toast
import org.mozilla.geckoview.WebResponse
import java.io.File
import java.io.InputStream

/** Saves files that Gecko hands over as downloads into the phone's Downloads folder. */
class Downloader(private val context: Context, private val library: Library) {
    private val main = Handler(Looper.getMainLooper())

    private fun toast(text: String) = main.post { Toast.makeText(context, text, Toast.LENGTH_SHORT).show() }

    fun handle(response: WebResponse) {
        val body = response.body ?: return
        val headers = response.headers
        fun header(name: String): String? =
            headers.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value
        val mime = header("content-type")?.substringBefore(';')?.trim()
        val name = URLUtil.guessFileName(response.uri, header("content-disposition"), mime)
        toast("Downloading $name")
        Thread {
            try {
                val uri = save(name, mime ?: "application/octet-stream", body)
                main.post {
                    library.addDownload(DownloadItem(name, uri.toString(), mime ?: "", System.currentTimeMillis()))
                    Toast.makeText(context, "Saved to Downloads: $name", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                try { body.close() } catch (ignored: Exception) { }
                toast("Download failed")
            }
        }.start()
    }

    private fun save(name: String, mime: String, input: InputStream): Uri {
        input.use { src ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create file")
                resolver.openOutputStream(uri)!!.use { out -> src.copyTo(out) }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                return uri
            } else {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                    ?: throw IllegalStateException("No storage")
                val f = File(dir, name)
                f.outputStream().use { out -> src.copyTo(out) }
                return Uri.fromFile(f)
            }
        }
    }
}
