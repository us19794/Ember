package app.ember.browser

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Shows whichever site, password or add-on question is waiting for an answer. */
@Composable
fun PromptHost(b: BrowserState) {
    val perm = b.permQueue.firstOrNull()
    if (perm != null) {
        val respond = { allow: Boolean -> perm.answer(allow); b.permQueue.remove(perm); Unit }
        AlertDialog(
            onDismissRequest = { respond(false) },
            title = { Text("Allow ${perm.host}?") },
            text = { Text("${perm.host} wants ${perm.what}.") },
            confirmButton = { TextButton(onClick = { respond(true) }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { respond(false) }) { Text("Block") } }
        )
    }

    val save = b.savePrompt
    if (save != null) {
        val respond = { ok: Boolean -> save.answer(ok); b.savePrompt = null }
        AlertDialog(
            onDismissRequest = { respond(false) },
            title = { Text("Save password?") },
            text = {
                Text(
                    (if (save.username.isBlank()) "Ember will save this login" else "Ember will save the login for ${save.username}") +
                        " on ${prettyUrl(save.origin)}. It's stored encrypted on this phone."
                )
            },
            confirmButton = { TextButton(onClick = { respond(true) }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { respond(false) }) { Text("Not now") } }
        )
    }

    val choice = b.loginChoice
    if (choice != null) {
        val respond = { idx: Int? -> choice.answer(idx); b.loginChoice = null }
        AlertDialog(
            onDismissRequest = { respond(null) },
            title = { Text("Fill in a login") },
            text = {
                Column {
                    Text(prettyUrl(choice.origin))
                    choice.names.forEachIndexed { i, n ->
                        TextButton(onClick = { respond(i) }) { Text(n) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { respond(null) }) { Text("Cancel") } }
        )
    }

    val addon = b.addonPrompt
    if (addon != null) {
        val respond = { ok: Boolean -> addon.answer(ok); b.addonPrompt = null }
        AlertDialog(
            onDismissRequest = { respond(false) },
            title = { Text("Add ${addon.name}?") },
            text = {
                Text(
                    if (addon.permissions.isEmpty()) "It asks for no special permissions."
                    else "It asks for access to: " + addon.permissions.take(8).joinToString(", ") +
                        if (addon.permissions.size > 8) " and more." else "."
                )
            },
            confirmButton = { TextButton(onClick = { respond(true) }) { Text("Add") } },
            dismissButton = { TextButton(onClick = { respond(false) }) { Text("Cancel") } }
        )
    }

    val js = b.jsDialog
    if (js != null) {
        var text by remember(js) { mutableStateOf(js.default) }
        val finish = { ok: Boolean -> js.answer(ok, text); b.jsDialog = null }
        AlertDialog(
            onDismissRequest = { finish(false) },
            title = { Text("This page says") },
            text = {
                Column {
                    Text(js.message)
                    if (js.kind == 2) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = text,
                            onValueChange = { text = it },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { finish(true) }) { Text("OK") } },
            dismissButton = if (js.kind == 0) null else ({ TextButton(onClick = { finish(false) }) { Text("Cancel") } })
        )
    }

    val ch = b.choiceDialog
    if (ch != null) {
        val picked = remember(ch) {
            mutableStateListOf<String>().apply {
                ch.items.filter { it.selected && !it.header }.forEach { add(it.id) }
            }
        }
        val close = { ids: List<String>? -> ch.answer(ids); b.choiceDialog = null }
        AlertDialog(
            onDismissRequest = { close(null) },
            title = { Text(ch.title.ifBlank { "Choose" }) },
            text = {
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    ch.items.forEach { item ->
                        if (item.header) {
                            Text(
                                item.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        } else if (ch.multiple) {
                            Row(
                                Modifier.fillMaxWidth().clickable(enabled = !item.disabled) {
                                    if (item.id in picked) picked.remove(item.id) else picked.add(item.id)
                                },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = item.id in picked,
                                    enabled = !item.disabled,
                                    onCheckedChange = {
                                        if (it) picked.add(item.id) else picked.remove(item.id)
                                    }
                                )
                                Text(item.label)
                            }
                        } else {
                            TextButton(
                                onClick = { close(listOf(item.id)) },
                                enabled = !item.disabled,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    item.label,
                                    modifier = Modifier.fillMaxWidth(),
                                    textAlign = TextAlign.Start,
                                    fontWeight = if (item.selected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (ch.multiple) TextButton(onClick = { close(picked.toList()) }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { close(null) }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ClearDialog(onConfirm: (closeTabs: Boolean) -> Unit, onDismiss: () -> Unit) {
    var closeTabs by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Clear browsing data?") },
        text = {
            Column {
                Text("Removes cookies, cache, site data, saved site permissions and page history.")
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().clickable { closeTabs = !closeTabs },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = closeTabs, onCheckedChange = { closeTabs = it })
                    Text("Also close all tabs (pinned tabs stay)")
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(closeTabs) }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun GroupDialog(b: BrowserState, tab: BrowserTab, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tab group") },
        text = {
            Column {
                b.groupNames().forEach { g ->
                    TextButton(onClick = { b.setGroup(tab, g); onDismiss() }) { Text(g) }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("New group name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) { b.setGroup(tab, name); onDismiss() } }) { Text("Create") }
        },
        dismissButton = {
            Row {
                if (tab.group.isNotBlank()) {
                    TextButton(onClick = { b.setGroup(tab, ""); onDismiss() }) { Text("Ungroup") }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}

/** Shown over everything until the user signs in with the phone's own lock. */
@Composable
fun LockScreen(onSignIn: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    LaunchedEffect(Unit) { onSignIn() }
    Column(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) awaitPointerEvent().changes.forEach { it.consume() }
                }
            }
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Ember",
            color = cs.primary,
            fontSize = 40.sp,
            fontWeight = FontWeight.Bold,
            fontStyle = FontStyle.Italic
        )
        Text("Locked", color = cs.onSurfaceVariant, fontSize = 16.sp)
        Spacer(Modifier.height(28.dp))
        Button(onClick = onSignIn) { Text("Sign in") }
        Spacer(Modifier.height(12.dp))
        Text(
            "Use your phone's PIN, pattern or fingerprint.",
            color = cs.onSurfaceVariant,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )
    }
}
