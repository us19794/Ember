package app.ember.browser

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.clickable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Shows whichever site, password or add-on question is waiting for an answer. */
@Composable
fun PromptHost(b: BrowserState) {
    val perm = b.permQueue.firstOrNull()
    if (perm != null) {
        val respond = { allow: Boolean -> perm.answer(allow); b.permQueue.remove(perm); Unit }
        AlertDialog(
            onDismissRequest = { respond(false) },
            title = { Text("Allow ${perm.host}?") },
            text = { Text("${perm.host} wants ${perm.what}.") },
            confirmButton = { TextButton(onClick = { respond(true) }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { respond(false) }) { Text("Block") } }
        )
    }

    val save = b.savePrompt
    if (save != null) {
        val respond = { ok: Boolean -> save.answer(ok); b.savePrompt = null }
        AlertDialog(
            onDismissRequest = { respond(false) },
            title = { Text("Save password?") },
            text = {
                Text(
                    (if (save.username.isBlank()) "Ember will save this login" else "Ember will save the login for ${save.username}") +
                        " on ${prettyUrl(save.origin)}. It's stored encrypted on this phone."
                )
            },
            confirmButton = { TextButton(onClick = { respond(true) }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { respond(false) }) { Text("Not now") } }
        )
    }

    val choice = b.loginChoice
    if (choice != null) {
        val respond = { idx: Int? -> choice.answer(idx); b.loginChoice = null }
        AlertDialog(
            onDismissRequest = { respond(null) },
            title = { Text("Fill in a login") },
            text = {
                Column {
                    Text(prettyUrl(choice.origin))
                    choice.names.forEachIndexed { i, n ->
                        TextButton(onClick = { respond(i) }) { Text(n) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { respond(null) }) { Text("Cancel") } }
        )
    }

    val addon = b.addonPrompt
    if (addon != null) {
        val respond = { ok: Boolean -> addon.answer(ok); b.addonPrompt = null }
        AlertDialog(
            onDismissRequest = { respond(false) },
            title = { Text("Add ${addon.name}?") },
            text = {
                Text(
                    if (addon.permissions.isEmpty()) "It asks for no special permissions."
                    else "It asks for access to: " + addon.permissions.take(8).joinToString(", ") +
                        if (addon.permissions.size > 8) " and more." else "."
                )
            },
            confirmButton = { TextButton(onClick = { respond(true) }) { Text("Add") } },
            dismissButton = { TextButton(onClick = { respond(false) }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ClearDialog(onConfirm: (closeTabs: Boolean) -> Unit, onDismiss: () -> Unit) {
    var closeTabs by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Clear browsing data?") },
        text = {
            Column {
                Text("Removes cookies, cache, site data, saved site permissions and page history.")
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().clickable { closeTabs = !closeTabs },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = closeTabs, onCheckedChange = { closeTabs = it })
                    Text("Also close all tabs (pinned tabs stay)")
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(closeTabs) }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun GroupDialog(b: BrowserState, tab: BrowserTab, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tab group") },
        text = {
            Column {
                b.groupNames().forEach { g ->
                    TextButton(onClick = { b.setGroup(tab, g); onDismiss() }) { Text(g) }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("New group name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) { b.setGroup(tab, name); onDismiss() } }) { Text("Create") }
        },
        dismissButton = {
            Row {
                if (tab.group.isNotBlank()) {
                    TextButton(onClick = { b.setGroup(tab, ""); onDismiss() }) { Text("Ungroup") }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}
