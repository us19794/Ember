package app.ember.browser

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val TEMPLATE = """{
  "ember_mod": 1,
  "id": "my-mod",
  "name": "My mod",
  "author": "Your name",
  "version": "1",
  "description": "What it does",
  "ui": { "accent": "#FF6A2B", "amoled": true, "glass": false, "tabLayout": "cards" },
  "web": [
    { "match": ["*://*.example.com/*"], "css": "body { background: #111 !important; }" }
  ]
}"""

private fun shareModText(ctx: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(i, null))
}

@Composable
private fun ModCard(
    mod: Mod,
    on: Boolean,
    onToggle: (Boolean) -> Unit,
    onRemove: (() -> Unit)?,
    onShare: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .background(cs.surfaceContainerHigh, MaterialTheme.shapes.large)
            .padding(start = 16.dp, top = 12.dp, end = 8.dp, bottom = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(end = 8.dp)) {
                Text(mod.name, style = MaterialTheme.typography.titleSmall)
                Text(
                    "by ${mod.author} · v${mod.version}" + if (mod.builtIn) " · built in" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
            Switch(checked = on, onCheckedChange = onToggle)
        }
        if (mod.description.isNotBlank()) {
            Text(mod.description, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp, end = 8.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                (if (mod.ui != null) "Changes Ember's look" else "") +
                    (if (mod.ui != null && mod.web.isNotEmpty()) " and " else "") +
                    (if (mod.web.isNotEmpty()) "Restyles websites" else ""),
                color = cs.primary,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onShare) { Text("Share") }
            if (onRemove != null) TextButton(onClick = onRemove) { Text("Remove") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModsSheet(mods: ModStore, prefs: EmberPrefs, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    var status by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var showFormat by remember { mutableStateOf(false) }
    var registryUrl by remember { mutableStateOf(prefs.modRegistry) }
    var community by remember { mutableStateOf<List<RegistryItem>>(emptyList()) }

    fun addFromText(text: String) {
        val err = mods.import(text)
        status = err ?: "Mod added. Switch it on below."
        if (err == null) input = ""
    }

    fun addFromLink(url: String) {
        status = "Fetching..."
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                try { Result.success(ModsNet.fetch(url)) } catch (e: Exception) { Result.failure<String>(e) }
            }
            r.onSuccess { addFromText(it) }.onFailure { status = it.message ?: "Couldn't fetch that link." }
        }
    }

    fun loadRegistry() {
        prefs.modRegistry = registryUrl.trim()
        status = "Loading the list..."
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                try { Result.success(ModStore.parseRegistry(ModsNet.fetch(registryUrl.trim()))) } catch (e: Exception) { Result.failure<List<RegistryItem>>(e) }
            }
            r.onSuccess { community = it; status = if (it.isEmpty()) "That list is empty." else "" }
                .onFailure { status = it.message ?: "Couldn't load that list." }
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            Text("Mods", style = MaterialTheme.typography.titleLarge)
            Text(
                "Mods are small files anyone can write and share. They can change how Ember looks and restyle websites. Page mods apply to pages you open or reload after switching them on.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            if (!prefs.on(K_MODS)) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "Mods are switched off in Settings, so page mods won't apply.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.error
                )
            }
            if (status.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(status, style = MaterialTheme.typography.bodyMedium, color = cs.primary)
            }

            Spacer(Modifier.height(14.dp))
            Text("Looks (one at a time)", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                mods.all.filter { it.ui != null }.forEach { m ->
                    ModCard(
                        m, mods.isEnabled(m.id),
                        onToggle = { mods.setEnabled(m, it) },
                        onRemove = if (m.builtIn) null else ({ mods.remove(m) }),
                        onShare = { shareModText(ctx, m.toJson()) }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Page mods", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                mods.all.filter { it.ui == null }.forEach { m ->
                    ModCard(
                        m, mods.isEnabled(m.id),
                        onToggle = { mods.setEnabled(m, it) },
                        onRemove = if (m.builtIn) null else ({ mods.remove(m) }),
                        onShare = { shareModText(ctx, m.toJson()) }
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            Text("Add a mod", style = MaterialTheme.typography.titleMedium)
            Text(
                "Paste a mod, or paste a link to one. Only add mods from people you trust.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("Mod JSON or https:// link") },
                minLines = 3,
                maxLines = 6,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(onClick = {
                val t = input.trim()
                if (t.startsWith("http://") || t.startsWith("https://")) addFromLink(t) else addFromText(t)
            }) { Text("Add mod") }

            Spacer(Modifier.height(18.dp))
            Text("Community list", style = MaterialTheme.typography.titleMedium)
            Text(
                "Anyone can publish a list of mods (a JSON file with name, author, description and url for each). Paste the link to one to browse it.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = registryUrl,
                onValueChange = { registryUrl = it },
                label = { Text("Link to a mod list") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(onClick = { loadRegistry() }) { Text("Load list") }
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                community.forEach { item ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(cs.surfaceContainerHigh, MaterialTheme.shapes.large)
                            .padding(start = 16.dp, top = 8.dp, end = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f).padding(end = 8.dp)) {
                            Text(item.name, style = MaterialTheme.typography.titleSmall)
                            Text("by ${item.author}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                            if (item.description.isNotBlank()) Text(item.description, style = MaterialTheme.typography.bodySmall)
                        }
                        OutlinedButton(onClick = { addFromLink(item.url) }) { Text("Add") }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Make your own", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = { showFormat = !showFormat }) { Text(if (showFormat) "Hide" else "Show format") }
            }
            if (showFormat) {
                Text(
                    "A mod is a JSON file. \"ui\" changes Ember (accent colour, black background, glass bar, tab layout). \"web\" holds CSS for sites matching the address patterns. Share the file anywhere, such as a GitHub page, and others can add it by link. JavaScript isn't supported, so mods stay safe to try.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    TEMPLATE,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(cs.surfaceContainerHigh, MaterialTheme.shapes.medium)
                        .padding(12.dp)
                )
                TextButton(onClick = { shareModText(ctx, TEMPLATE) }) { Text("Share this template") }
            }
        }
    }
}
