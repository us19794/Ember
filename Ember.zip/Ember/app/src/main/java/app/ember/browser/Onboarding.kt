package app.ember.browser

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** First-launch flow: page one has the ad-free shield toggles, page two has colours and "Let's go". */
@Composable
fun Onboarding(prefs: EmberPrefs, onShieldChanged: () -> Unit, onDone: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var page by remember { mutableIntStateOf(0) }

    Column(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 20.dp)
    ) {
        Text(
            "Ember",
            color = cs.primary,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            fontStyle = FontStyle.Italic
        )
        Text("${page + 1} of 2", color = cs.onSurfaceVariant, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            if (page == 0) {
                Text("Ad-free from the first tap", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Every shield below is already on. Switch off anything you don't want; you can change these later in Settings.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                ShieldSwitches(prefs, onShieldChanged)
            } else {
                Text("Make it yours", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Pick a colour scheme. The change shows up right here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
                Spacer(Modifier.height(16.dp))
                ColourControls(prefs)
            }
        }

        Spacer(Modifier.height(12.dp))
        if (page == 0) {
            Button(
                onClick = { page = 1 },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Continue", fontSize = 16.sp) }
        } else {
            Row(Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { page = 0 },
                    modifier = Modifier.weight(1f).height(52.dp)
                ) { Text("Back", fontSize = 16.sp) }
                Spacer(Modifier.padding(6.dp))
                Button(
                    onClick = onDone,
                    modifier = Modifier.weight(2f).height(52.dp)
                ) { Text("Let's go", fontSize = 16.sp) }
            }
        }
    }
}
