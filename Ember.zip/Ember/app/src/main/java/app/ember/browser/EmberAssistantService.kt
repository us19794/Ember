package app.ember.browser

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout

/**
 * Registers Ember as a system Digital Assistant (power-button / gesture trigger).
 */
class EmberVoiceInteractionService : VoiceInteractionService()

class EmberVoiceInteractionSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession =
        EmberVoiceInteractionSession(this)
}

class EmberVoiceInteractionSession(context: android.content.Context) : VoiceInteractionSession(context) {
    private var blobView: AssistantBlobView? = null

    override fun onCreateContentView(): View {
        val container = FrameLayout(context).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }
        val blob = AssistantBlobView(
            context = context,
            onTapBlob = {
                context.startActivity(
                    Intent(context, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    }
                )
                hide()
            },
            onDismiss = {
                hide()
            }
        )
        blobView = blob
        container.addView(
            blob,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        return container
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        window?.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            @Suppress("DEPRECATION")
            w.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                w.attributes = w.attributes.apply {
                    layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    } else {
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
                }
            }
        }
        blobView?.post { blobView?.startEnterAnimation() }
    }

    override fun onHide() {
        blobView?.stopAnimations()
        super.onHide()
    }
}

/**
 * Minimal RecognitionService stub required by Android's VoiceInteractionServiceInfo
 * so Ember is accepted as a valid Default Digital Assistant across all Android versions.
 */
class EmberRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        listener?.error(android.speech.SpeechRecognizer.ERROR_NO_MATCH)
    }

    override fun onCancel(listener: Callback?) {}

    override fun onStopListening(listener: Callback?) {}
}
