package app.ember.browser

import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

class Recommended(val name: String, val blurb: String, val slug: String)

/** Add-ons that work on their own, with no toolbar popup needed. */
object Addons {
    val builtIn = setOf(UBLOCK_ID, READER_ID)

    val recommended = listOf(
        Recommended("Dark Reader", "Turns any website dark.", "darkreader"),
        Recommended("SponsorBlock", "Skips sponsor segments in YouTube videos.", "sponsorblock"),
        Recommended("Return YouTube Dislike", "Brings back dislike counts on YouTube.", "return-youtube-dislike"),
        Recommended("ClearURLs", "Strips tracking junk from links.", "clearurls"),
        Recommended("I still don't care about cookies", "Dismisses cookie banners.", "istilldontcareaboutcookies"),
        Recommended("Decentraleyes", "Serves common web libraries locally instead of from trackers.", "decentraleyes")
    )

    /** Accepts an add-on page link, a direct .xpi link, or just the add-on's name from its address. */
    fun xpiUrl(input: String): String {
        val t = input.trim()
        if (t.endsWith(".xpi", ignoreCase = true)) return t
        val slug = Regex("/addon/([^/?#]+)").find(t)?.groupValues?.get(1) ?: t.trim('/')
        return "https://addons.mozilla.org/firefox/downloads/latest/$slug/latest.xpi"
    }

    fun list(runtime: GeckoRuntime, onResult: (List<WebExtension>) -> Unit) {
        runtime.webExtensionController.list().accept { l ->
            onResult((l ?: emptyList()).filter { it.id !in builtIn })
        }
    }

    fun install(runtime: GeckoRuntime, url: String, onDone: (String?) -> Unit) {
        runtime.webExtensionController
            .install(url, WebExtensionController.INSTALLATION_METHOD_MANAGER)
            .accept({ onDone(null) }, { e -> onDone(e?.message ?: "Could not install that add-on") })
    }

    fun uninstall(runtime: GeckoRuntime, ext: WebExtension, onDone: () -> Unit) {
        runtime.webExtensionController.uninstall(ext).accept { onDone() }
    }

    fun setEnabled(runtime: GeckoRuntime, ext: WebExtension, enabled: Boolean) {
        val ctl = runtime.webExtensionController
        if (enabled) ctl.enable(ext, WebExtensionController.EnableSource.USER)
        else ctl.disable(ext, WebExtensionController.EnableSource.USER)
    }
}
