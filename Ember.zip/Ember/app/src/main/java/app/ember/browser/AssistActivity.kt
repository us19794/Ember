package app.ember.browser

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts

/**
 * Transparent overlay activity launched when Android invokes ACTION_ASSIST
 * (or when microphone permission needs to be requested from the user).
 */
class AssistActivity : ComponentActivity() {
    private lateinit var overlayView: AssistantOverlayView

    private val micPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                overlayView.post { overlayView.startSession() }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                } else {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
        }
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )

        overlayView = AssistantOverlayView(
            context = this,
            onRequestMicPermission = {
                micPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
            },
            onOpenUrl = { url ->
                startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse(url), this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    }
                )
                finish()
                overridePendingTransition(0, 0)
            },
            onDismiss = {
                finish()
                overridePendingTransition(0, 0)
            }
        )
        setContentView(overlayView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                overlayView.dismissSession()
            }
        })

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
        overlayView.post { overlayView.startSession() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        overlayView.post { overlayView.startSession() }
    }

    override fun onDestroy() {
        if (::overlayView.isInitialized) overlayView.cleanup()
        super.onDestroy()
    }
}
