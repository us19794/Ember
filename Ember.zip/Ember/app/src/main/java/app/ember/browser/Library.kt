package app.ember.browser

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Bookmark(val url: String, val title: String)
class HistoryItem(val url: String, val title: String, val time: Long)
class DownloadItem(val name: String, val uri: String, val mime: String, val time: Long)
class SitePerm(val host: String, val what: String, val allowed: Boolean, val json: String)

/** Bookmarks, history, downloads and remembered site permissions, kept in one small JSON file. */
class Library(context: Context) {
    private val file = File(context.filesDir, "library.json")

    val bookmarks = mutableStateListOf<Bookmark>()
    val history = mutableStateListOf<HistoryItem>()
    val downloads = mutableStateListOf<DownloadItem>()
    val sitePerms = mutableStateListOf<SitePerm>()

    init {
        load()
    }

    fun isBookmarked(url: String) = bookmarks.any { it.url == url }

    fun toggleBookmark(url: String, title: String) {
        val existing = bookmarks.firstOrNull { it.url == url }
        if (existing != null) bookmarks.remove(existing)
        else bookmarks.add(0, Bookmark(url, title.ifBlank { url }))
        save()
    }

    fun removeBookmark(b: Bookmark) { bookmarks.remove(b); save() }

    fun addHistory(url: String, title: String) {
        if (url.isBlank() || url.startsWith("about:") || url.startsWith("moz-extension:")) return
        val first = history.firstOrNull()
        if (first != null && first.url == url) {
            history[0] = HistoryItem(url, title.ifBlank { first.title }, System.currentTimeMillis())
        } else {
            history.add(0, HistoryItem(url, title.ifBlank { url }, System.currentTimeMillis()))
            while (history.size > 500) history.removeAt(history.lastIndex)
        }
        save()
    }

    fun removeHistory(h: HistoryItem) { history.remove(h); save() }
    fun clearHistory() { history.clear(); save() }

    fun addDownload(d: DownloadItem) { downloads.add(0, d); save() }
    fun removeDownload(d: DownloadItem) { downloads.remove(d); save() }

    fun recordSitePerm(host: String, what: String, allowed: Boolean, json: String) {
        sitePerms.removeAll { it.host == host && it.what == what }
        sitePerms.add(0, SitePerm(host, what, allowed, json))
        save()
    }

    fun removeSitePerm(p: SitePerm) { sitePerms.remove(p); save() }

    private fun save() {
        try {
            val o = JSONObject()
            o.put("bookmarks", JSONArray().also { a ->
                bookmarks.forEach { a.put(JSONObject().put("url", it.url).put("title", it.title)) }
            })
            o.put("history", JSONArray().also { a ->
                history.forEach { a.put(JSONObject().put("url", it.url).put("title", it.title).put("time", it.time)) }
            })
            o.put("downloads", JSONArray().also { a ->
                downloads.forEach {
                    a.put(JSONObject().put("name", it.name).put("uri", it.uri).put("mime", it.mime).put("time", it.time))
                }
            })
            o.put("sitePerms", JSONArray().also { a ->
                sitePerms.forEach {
                    a.put(JSONObject().put("host", it.host).put("what", it.what).put("allowed", it.allowed).put("json", it.json))
                }
            })
            file.writeText(o.toString())
        } catch (e: Exception) {
        }
    }

    private fun load() {
        try {
            if (!file.exists()) return
            val o = JSONObject(file.readText())
            o.optJSONArray("bookmarks")?.let { a ->
                for (i in 0 until a.length()) {
                    val j = a.getJSONObject(i)
                    bookmarks.add(Bookmark(j.getString("url"), j.optString("title")))
                }
            }
            o.optJSONArray("history")?.let { a ->
                for (i in 0 until a.length()) {
                    val j = a.getJSONObject(i)
                    history.add(HistoryItem(j.getString("url"), j.optString("title"), j.optLong("time")))
                }
            }
            o.optJSONArray("downloads")?.let { a ->
                for (i in 0 until a.length()) {
                    val j = a.getJSONObject(i)
                    downloads.add(DownloadItem(j.getString("name"), j.getString("uri"), j.optString("mime"), j.optLong("time")))
                }
            }
            o.optJSONArray("sitePerms")?.let { a ->
                for (i in 0 until a.length()) {
                    val j = a.getJSONObject(i)
                    sitePerms.add(SitePerm(j.getString("host"), j.getString("what"), j.optBoolean("allowed"), j.getString("json")))
                }
            }
        } catch (e: Exception) {
        }
    }
}
