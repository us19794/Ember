package app.ember.browser

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Translucent, hardware-accelerated luminous orb modeled after the Siri AI sphere:
 * - Emerges smoothly from the phone's front camera cutout (or top-center fallback).
 * - Keeps the entire home screen / background visible underneath.
 * - Renders a glassy translucent sphere, an undulating horizontal caustic light-band,
 *   and an iridescent amber/cyan rim glow.
 */
class AssistantBlobView(
    context: Context,
    private val onTapBlob: () -> Unit,
    private val onDismiss: () -> Unit
) : View(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Float = v * density

    // Camera cutout anchor in view coordinates
    private var camX = 0f
    private var camY = 0f
    private var camRadius = dp(14f)
    private var hasCutout = false

    // Animation state
    private var enterProgress = 0f
    private var idleTime = 0f
    private var pulseBoost = 0f
    private var dismissing = false

    private var enterAnimator: ValueAnimator? = null
    private var exitAnimator: ValueAnimator? = null
    private var idleAnimator: ValueAnimator? = null

    // Current rendered orb center & radius (for hit testing)
    private var currentCx = 0f
    private var currentCy = 0f
    private var currentRadius = 0f

    // Reusable drawing objects (no allocations in onDraw)
    private val blobPath = Path()
    private val causticPath = Path()
    private val gradMatrix = Matrix()
    private val boundsRect = RectF()

    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glassPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val innerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val causticBloomPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val causticCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rimGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val rimCrispPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val specPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = true
        isFocusable = true
    }

    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        resolveCameraAnchor(insets)
        return super.onApplyWindowInsets(insets)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        resolveCameraAnchor(rootWindowInsets)
    }

    private fun resolveCameraAnchor(insets: WindowInsets?) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        var found = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && insets != null) {
            val cutout = insets.displayCutout
            if (cutout != null) {
                val topRect = cutout.boundingRects
                    .filter { it.top < h * 0.25f && it.width() > 0 && it.height() > 0 }
                    .minByOrNull { it.top }
                if (topRect != null) {
                    camX = topRect.exactCenterX()
                    camY = topRect.exactCenterY()
                    camRadius = max(topRect.width(), topRect.height()) * 0.5f
                    found = true
                }
            }
        }
        hasCutout = found
        if (!found) {
            @Suppress("DEPRECATION")
            val topInset = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && insets != null) {
                insets.getInsets(WindowInsets.Type.statusBars()).top.toFloat()
            } else {
                insets?.systemWindowInsetTop?.toFloat() ?: dp(28f)
            }
            camX = w * 0.5f
            camY = max(topInset * 0.5f, dp(22f))
            camRadius = dp(13f)
        }
    }

    fun startEnterAnimation() {
        exitAnimator?.cancel()
        enterAnimator?.cancel()
        dismissing = false
        enterProgress = 0f
        pulseBoost = 0f

        startIdleLoop()

        enterAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 540L
            interpolator = OvershootInterpolator(1.12f)
            addUpdateListener { anim ->
                enterProgress = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun startExitAnimation() {
        if (dismissing) return
        dismissing = true
        enterAnimator?.cancel()
        exitAnimator?.cancel()

        val startVal = enterProgress
        exitAnimator = ValueAnimator.ofFloat(startVal, 0f).apply {
            duration = 260L
            interpolator = AccelerateInterpolator(1.4f)
            addUpdateListener { anim ->
                enterProgress = anim.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    stopAnimations()
                    onDismiss()
                }
            })
            start()
        }
    }

    fun stopAnimations() {
        enterAnimator?.cancel()
        exitAnimator?.cancel()
        idleAnimator?.cancel()
        enterAnimator = null
        exitAnimator = null
        idleAnimator = null
    }

    private fun startIdleLoop() {
        if (idleAnimator?.isRunning == true) return
        idleAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 10_000L
            repeatCount = ValueAnimator.INFINITE
            var lastTick = System.nanoTime()
            addUpdateListener {
                val now = System.nanoTime()
                val dt = ((now - lastTick) / 1_000_000_000f).coerceIn(0f, 0.05f)
                lastTick = now
                idleTime += dt
                if (pulseBoost > 0f) {
                    pulseBoost = (pulseBoost - dt * 2.2f).coerceAtLeast(0f)
                }
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        stopAnimations()
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val dist = hypot(event.x - currentCx, event.y - currentCy)
            if (dist <= currentRadius * 1.25f && !dismissing) {
                pulseBoost = 1f
                onTapBlob()
            } else {
                startExitAnimation()
            }
            return true
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val p = enterProgress.coerceAtLeast(0f)
        if (p <= 0.005f || width <= 0 || height <= 0) return

        val clampedAlpha = enterProgress.coerceIn(0f, 1f)
        val targetRadius = dp(76f) * (1f + 0.04f * sin(idleTime * 2.2f) + 0.06f * pulseBoost)
        val startRadius = camRadius * 0.65f
        val r = startRadius + (targetRadius - startRadius) * p

        val dropOffset = dp(96f) * p
        val cx = if (camX > 0f) camX else width * 0.5f
        val cy = (if (camY > 0f) camY else dp(24f)) + dropOffset

        currentCx = cx
        currentCy = cy
        currentRadius = r

        // 1. Soft atmospheric outer halo (keeps background wallpaper & icons crisp)
        val haloR = r * 1.85f
        haloPaint.shader = RadialGradient(
            cx, cy, haloR,
            intArrayOf(
                Color.argb((72 * clampedAlpha).toInt(), 255, 195, 130),
                Color.argb((36 * clampedAlpha).toInt(), 120, 200, 255),
                Color.TRANSPARENT
            ),
            floatArrayOf(0.35f, 0.65f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, haloR, haloPaint)

        // 2. Build organic liquid-glass blob contour
        blobPath.reset()
        val steps = 72
        val wobbleAmp = 0.026f + 0.014f * pulseBoost
        for (i in 0 until steps) {
            val theta = (i.toFloat() / steps) * (2f * PI.toFloat())
            val wave = 1f +
                wobbleAmp * sin(3f * theta + idleTime * 2.4f) +
                (wobbleAmp * 0.65f) * cos(5f * theta - idleTime * 1.9f) +
                (wobbleAmp * 0.4f) * sin(2f * theta - idleTime * 1.3f)
            val px = cx + r * wave * cos(theta)
            val py = cy + r * wave * sin(theta)
            if (i == 0) blobPath.moveTo(px, py) else blobPath.lineTo(px, py)
        }
        blobPath.close()

        // 3. Translucent smoky-glass sphere body so home screen shows through
        glassPaint.shader = RadialGradient(
            cx, cy - r * 0.12f, r * 1.08f,
            intArrayOf(
                Color.argb((120 * clampedAlpha).toInt(), 14, 16, 22),
                Color.argb((155 * clampedAlpha).toInt(), 8, 10, 16),
                Color.argb((95 * clampedAlpha).toInt(), 28, 34, 48)
            ),
            floatArrayOf(0f, 0.68f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(blobPath, glassPaint)

        // 4. Clip inside the glass sphere for internal caustic light-band & reflections
        canvas.save()
        canvas.clipPath(blobPath)

        // Subtle internal warm/cool ambient glow
        innerGlowPaint.shader = RadialGradient(
            cx, cy + r * 0.05f, r * 0.9f,
            intArrayOf(
                Color.argb((85 * clampedAlpha).toInt(), 255, 220, 175),
                Color.argb((30 * clampedAlpha).toInt(), 130, 200, 255),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, innerGlowPaint)

        // Signature horizontal undulating light-band (Siri AI orb equator)
        causticPath.reset()
        val bandSteps = 32
        val leftX = cx - r * 0.95f
        val rightX = cx + r * 0.95f
        for (i in 0..bandSteps) {
            val t = i.toFloat() / bandSteps
            val x = leftX + (rightX - leftX) * t
            val env = sin(t * PI.toFloat())
            val yWave = r * 0.085f * sin(t * 4.5f + idleTime * 2.8f) * env +
                r * 0.035f * cos(t * 7f - idleTime * 2.1f) * env
            val y = cy + yWave
            if (i == 0) causticPath.moveTo(x, y) else causticPath.lineTo(x, y)
        }

        // Wide warm-amber bloom around the light-band
        causticBloomPaint.strokeWidth = r * 0.34f
        causticBloomPaint.shader = LinearGradient(
            leftX, cy, rightX, cy,
            intArrayOf(
                Color.argb(0, 255, 165, 90),
                Color.argb((140 * clampedAlpha).toInt(), 255, 196, 130),
                Color.argb((210 * clampedAlpha).toInt(), 255, 248, 238),
                Color.argb((140 * clampedAlpha).toInt(), 170, 222, 255),
                Color.argb(0, 130, 205, 255)
            ),
            floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(causticPath, causticBloomPaint)

        // Crisp luminous white-gold core streak
        causticCorePaint.strokeWidth = r * 0.11f
        causticCorePaint.shader = LinearGradient(
            leftX, cy, rightX, cy,
            intArrayOf(
                Color.argb(0, 255, 255, 255),
                Color.argb((210 * clampedAlpha).toInt(), 255, 236, 205),
                Color.argb((255 * clampedAlpha).toInt(), 255, 255, 255),
                Color.argb((210 * clampedAlpha).toInt(), 225, 245, 255),
                Color.argb(0, 255, 255, 255)
            ),
            floatArrayOf(0f, 0.28f, 0.5f, 0.72f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(causticPath, causticCorePaint)

        // Top glass specular crescent
        specPaint.shader = RadialGradient(
            cx - r * 0.2f, cy - r * 0.55f, r * 0.75f,
            intArrayOf(
                Color.argb((75 * clampedAlpha).toInt(), 255, 255, 255),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx - r * 0.15f, cy - r * 0.45f, r * 0.7f, specPaint)

        canvas.restore()

        // 5. Iridescent prismatic rim lighting (amber/orange + cyan/blue + white)
        val sweep = SweepGradient(
            cx, cy,
            intArrayOf(
                Color.argb((220 * clampedAlpha).toInt(), 255, 255, 255),
                Color.argb((200 * clampedAlpha).toInt(), 130, 215, 255),
                Color.argb((120 * clampedAlpha).toInt(), 180, 150, 255),
                Color.argb((215 * clampedAlpha).toInt(), 255, 160, 85),
                Color.argb((235 * clampedAlpha).toInt(), 255, 235, 205),
                Color.argb((220 * clampedAlpha).toInt(), 255, 255, 255)
            ),
            floatArrayOf(0f, 0.22f, 0.42f, 0.65f, 0.85f, 1f)
        )
        gradMatrix.setRotate(idleTime * 28f, cx, cy)
        sweep.setLocalMatrix(gradMatrix)

        rimGlowPaint.strokeWidth = dp(5.5f)
        rimGlowPaint.alpha = (110 * clampedAlpha).toInt()
        rimGlowPaint.shader = sweep
        canvas.drawPath(blobPath, rimGlowPaint)

        rimCrispPaint.strokeWidth = dp(2.0f)
        rimCrispPaint.alpha = (230 * clampedAlpha).toInt()
        rimCrispPaint.shader = sweep
        canvas.drawPath(blobPath, rimCrispPaint)
    }
}
