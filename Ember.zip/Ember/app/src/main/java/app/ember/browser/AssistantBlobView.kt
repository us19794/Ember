package app.ember.browser

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Renders the exact user-provided orb image (assistant_orb.png, with transparent
 * outer background and deepened dark interior) emerging smoothly from and aligned
 * to the top-center island/camera cutout, pulsing with voice audio level.
 */
class AssistantBlobView(
    context: Context,
    private val onTapBlob: () -> Unit,
    private val onDismiss: () -> Unit
) : View(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Float = v * density

    private val orbBitmap: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.assistant_orb)
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val destRect = RectF()

    private var camX = 0f
    private var camY = 0f
    private var camRadius = dp(14f)

    private var enterProgress = 0f
    private var idleTime = 0f
    private var pulseBoost = 0f
    private var voiceLevel = 0f
    private var targetVoiceLevel = 0f
    private var dismissing = false

    private var enterAnimator: ValueAnimator? = null
    private var exitAnimator: ValueAnimator? = null
    private var idleAnimator: ValueAnimator? = null

    private var currentCx = 0f
    private var currentCy = 0f
    private var currentRadius = 0f

    /** Bottom Y coordinate of the fully expanded orb, used to position the answer card below it. */
    fun orbBottomY(): Float {
        val anchorY = if (camY > 0f) camY else dp(24f)
        val r = dp(78f)
        val startR = camRadius * 0.65f
        val cy = anchorY + ((r - startR) * 0.78f).coerceAtLeast(0f)
        return cy + r + dp(14f)
    }

    fun setVoiceLevel(rmsDb: Float) {
        // Normalize Android SpeechRecognizer rmsDb (-2..10+) to 0..1
        targetVoiceLevel = ((rmsDb + 2f) / 12f).coerceIn(0f, 1f)
    }

    init {
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = false
        isFocusable = false
    }

    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        resolveCameraAnchor(insets)
        return super.onApplyWindowInsets(insets)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        resolveCameraAnchor(rootWindowInsets)
    }

    private fun resolveCameraAnchor(insets: WindowInsets?) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        camX = w * 0.5f

        var foundY = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && insets != null) {
            val cutout = insets.displayCutout
            if (cutout != null) {
                val topRect = cutout.boundingRects
                    .filter { it.top < h * 0.25f && it.width() > 0 && it.height() > 0 }
                    .minByOrNull { it.top }
                if (topRect != null) {
                    camY = topRect.exactCenterY()
                    camRadius = max(topRect.height() * 0.5f, dp(13f))
                    foundY = true
                }
            }
        }
        if (!foundY) {
            @Suppress("DEPRECATION")
            val topInset = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && insets != null) {
                insets.getInsets(WindowInsets.Type.statusBars()).top.toFloat()
            } else {
                insets?.systemWindowInsetTop?.toFloat() ?: dp(28f)
            }
            camY = max(topInset * 0.5f, dp(22f))
            camRadius = dp(13f)
        }
    }

    fun startEnterAnimation() {
        exitAnimator?.cancel()
        enterAnimator?.cancel()
        dismissing = false
        enterProgress = 0f
        pulseBoost = 0f
        voiceLevel = 0f
        targetVoiceLevel = 0f

        startIdleLoop()

        enterAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 520L
            interpolator = OvershootInterpolator(1.12f)
            addUpdateListener { anim ->
                enterProgress = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun startExitAnimation() {
        if (dismissing) return
        dismissing = true
        enterAnimator?.cancel()
        exitAnimator?.cancel()

        val startVal = enterProgress
        exitAnimator = ValueAnimator.ofFloat(startVal, 0f).apply {
            duration = 240L
            interpolator = AccelerateInterpolator(1.4f)
            addUpdateListener { anim ->
                enterProgress = anim.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    stopAnimations()
                    onDismiss()
                }
            })
            start()
        }
    }

    fun stopAnimations() {
        enterAnimator?.cancel()
        exitAnimator?.cancel()
        idleAnimator?.cancel()
        enterAnimator = null
        exitAnimator = null
        idleAnimator = null
    }

    private fun startIdleLoop() {
        if (idleAnimator?.isRunning == true) return
        idleAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 10_000L
            repeatCount = ValueAnimator.INFINITE
            var lastTick = System.nanoTime()
            addUpdateListener {
                val now = System.nanoTime()
                val dt = ((now - lastTick) / 1_000_000_000f).coerceIn(0f, 0.05f)
                lastTick = now
                idleTime += dt
                voiceLevel += (targetVoiceLevel - voiceLevel) * (dt * 12f).coerceAtMost(1f)
                targetVoiceLevel = (targetVoiceLevel - dt * 1.8f).coerceAtLeast(0f)
                if (pulseBoost > 0f) {
                    pulseBoost = (pulseBoost - dt * 2.2f).coerceAtLeast(0f)
                }
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        stopAnimations()
        super.onDetachedFromWindow()
    }

    fun handleTap(x: Float, y: Float): Boolean {
        val dist = hypot(x - currentCx, y - currentCy)
        if (dist <= currentRadius * 1.15f && !dismissing) {
            pulseBoost = 1f
            onTapBlob()
            return true
        }
        return false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val p = enterProgress.coerceAtLeast(0f)
        if (p <= 0.005f || width <= 0 || height <= 0) return

        val clampedAlpha = enterProgress.coerceIn(0f, 1f)
        val breathe = 1f + 0.028f * sin(idleTime * 2.4f) + 0.09f * voiceLevel + 0.06f * pulseBoost
        val targetRadius = dp(78f) * breathe
        val startRadius = camRadius * 0.65f
        val r = startRadius + (targetRadius - startRadius) * p

        val cx = width * 0.5f
        val anchorY = if (camY > 0f) camY else dp(24f)
        val cy = anchorY + ((r - startRadius) * 0.78f).coerceAtLeast(0f)

        currentCx = cx
        currentCy = cy
        currentRadius = r

        val aspect = orbBitmap.height.toFloat() / orbBitmap.width.toFloat().coerceAtLeast(1f)
        val halfW = r
        val halfH = r * aspect

        destRect.set(cx - halfW, cy - halfH, cx + halfW, cy + halfH)
        bitmapPaint.alpha = (255f * clampedAlpha).toInt().coerceIn(0, 255)
        canvas.drawBitmap(orbBitmap, null, destRect, bitmapPaint)
    }
}
