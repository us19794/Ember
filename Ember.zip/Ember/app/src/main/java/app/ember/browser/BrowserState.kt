package app.ember.browser

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import java.net.URLEncoder

private const val SEARCH_URL = "https://duckduckgo.com/?q="

private var sRuntime: GeckoRuntime? = null

/** GeckoRuntime must exist exactly once per process. */
fun geckoRuntime(context: Context): GeckoRuntime =
    sRuntime ?: GeckoRuntime.create(context.applicationContext).also { sRuntime = it }

/** One browsing session (single tab for now) plus its observable UI state. */
class BrowserState(runtime: GeckoRuntime) {
    val session = GeckoSession()

    var showHome by mutableStateOf(true)
    var url by mutableStateOf("")
    var title by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)

    init {
        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                this@BrowserState.loading = true
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                this@BrowserState.loading = false
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                this@BrowserState.progress = progress
            }
        }

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                this@BrowserState.url = url ?: ""
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                this@BrowserState.canGoBack = canGoBack
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                this@BrowserState.canGoForward = canGoForward
            }

            // Single tab for now: links that want a new window open here.
            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny>? {
                if (request.target == GeckoSession.NavigationDelegate.TARGET_WINDOW_NEW) {
                    session.loadUri(request.uri)
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }
                return null
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                this@BrowserState.title = title ?: ""
            }
        }

        session.open(runtime)
    }

    fun load(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        showHome = false
        session.loadUri(resolve(t))
    }

    private fun resolve(t: String): String = when {
        Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*").matches(t) -> t
        t.startsWith("about:") -> t
        !t.contains(' ') && (t.contains('.') || t.startsWith("localhost")) -> "https://$t"
        else -> SEARCH_URL + URLEncoder.encode(t, "UTF-8")
    }
}
