package app.ember.browser

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import org.json.JSONArray
import org.json.JSONObject
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.Autocomplete
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.StorageController
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController
import org.mozilla.geckoview.WebResponse
import java.net.URLEncoder

private var sRuntime: GeckoRuntime? = null

/** GeckoRuntime must exist exactly once per process. */
fun geckoRuntime(context: Context): GeckoRuntime =
    sRuntime ?: GeckoRuntime.create(context.applicationContext).also { sRuntime = it }

/** One browser tab: a Gecko session plus its observable UI state. */
class BrowserTab(val session: GeckoSession, val isPrivate: Boolean) {
    var showHome by mutableStateOf(true)
    var url by mutableStateOf("")
    var title by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)
    var blocked by mutableIntStateOf(0)
    var pinned by mutableStateOf(false)
    var group by mutableStateOf("")
    var desktop by mutableStateOf(false)
    var fullscreen by mutableStateOf(false)

    /** Small picture of the page, shown on the sliding tab cards. */
    var thumb by mutableStateOf<ImageBitmap?>(null)

    /** Restored tabs wait for their first visit before loading. */
    var pending: String? = null
}

class PermRequest(val host: String, val what: String, val answer: (Boolean) -> Unit)
class SavePrompt(val origin: String, val username: String, val answer: (Boolean) -> Unit)
class LoginChoice(val origin: String, val names: List<String>, val answer: (Int?) -> Unit)
class AddonPrompt(val name: String, val permissions: List<String>, val answer: (Boolean) -> Unit)

/** kind: 0 = alert, 1 = confirm, 2 = prompt (asks for text). */
class JsDialog(val kind: Int, val message: String, val default: String, val answer: (Boolean, String) -> Unit)
class ChoiceItem(val id: String, val label: String, val selected: Boolean, val disabled: Boolean, val header: Boolean)
class ChoiceDialog(val title: String, val multiple: Boolean, val items: List<ChoiceItem>, val answer: (List<String>?) -> Unit)

/** What was under the finger on a long-press. */
class ContextInfo(
    val privateTab: Boolean,
    val linkUri: String?,
    val srcUri: String?,
    val type: Int,
    val title: String?,
    val alt: String?,
    val baseUri: String?
)

class BrowserState(
    private val runtime: GeckoRuntime,
    private val prefs: EmberPrefs,
    private val library: Library,
    private val vault: Vault,
    val downloader: Downloader
) {
    val tabs = mutableStateListOf<BrowserTab>()
    var selected by mutableIntStateOf(0)
        private set

    // prompts shown by the UI
    val permQueue = mutableStateListOf<PermRequest>()
    var savePrompt by mutableStateOf<SavePrompt?>(null)
    var loginChoice by mutableStateOf<LoginChoice?>(null)
    var addonPrompt by mutableStateOf<AddonPrompt?>(null)
    var contextMenu by mutableStateOf<ContextInfo?>(null)
    var jsDialog by mutableStateOf<JsDialog?>(null)
    var choiceDialog by mutableStateOf<ChoiceDialog?>(null)

    /** Set by the activity. */
    var appContext: Context? = null

    /** Set by the activity: opens the file picker (multiple?, mime types) and reports the chosen files. */
    var filePickerRequester: ((Boolean, Array<String>, (List<Uri>) -> Unit) -> Unit)? = null

    /** Changes whenever something worth saving about the open tabs changes. */
    fun stateSignature(): String =
        tabs.joinToString("|") { "${it.url}~${it.title}~${it.pinned}~${it.group}~${it.isPrivate}~${it.showHome}" } + "#" + selected

    /** Set by the activity: opens the "save as" file picker and reports the chosen place. */
    var saveAsRequester: ((String, (Uri) -> Unit) -> Unit)? = null

    fun saveAs(url: String) {
        val ask = saveAsRequester ?: return
        ask(downloader.suggestName(url)) { target -> downloader.saveToUri(url, target) }
    }

    /** Set by the activity: asks Android for runtime permissions (camera, mic, location). */
    var androidPermissionRequester: ((Array<String>, (Boolean) -> Unit) -> Unit)? = null

    /** Sessions waiting to be closed once the GeckoView has let go of them. */
    private val toClose = mutableListOf<GeckoSession>()

    val current: BrowserTab get() = tabs[selected]

    /** Web addresses of recently closed tabs, newest last. */
    val closedUrls = mutableStateListOf<String>()
    val closedCount: Int get() = closedUrls.size

    fun reopenClosed() {
        if (closedUrls.isEmpty()) return
        newTab(url = closedUrls.removeAt(closedUrls.lastIndex))
    }

    init {
        runtime.setAutocompleteStorageDelegate(object : Autocomplete.StorageDelegate {
            override fun onLoginFetch(domain: String): GeckoResult<Array<Autocomplete.LoginEntry>>? =
                GeckoResult.fromValue(vault.forDomain(domain).map { it.toEntry() }.toTypedArray())

            override fun onLoginSave(login: Autocomplete.LoginEntry) {
                vault.save(login)
            }
        })

        runtime.webExtensionController.setPromptDelegate(object : WebExtensionController.PromptDelegate {
            override fun onInstallPromptRequest(
                extension: WebExtension,
                permissions: Array<String>,
                origins: Array<String>,
                dataCollectionPermissions: Array<String>
            ): GeckoResult<WebExtension.PermissionPromptResponse>? {
                if (extension.id in Addons.builtIn) {
                    return GeckoResult.fromValue(WebExtension.PermissionPromptResponse(true, true, false))
                }
                val r = GeckoResult<WebExtension.PermissionPromptResponse>()
                val name = extension.metaData?.name ?: extension.id
                addonPrompt = AddonPrompt(name, (permissions + origins).toList()) { ok ->
                    r.complete(WebExtension.PermissionPromptResponse(ok, ok, false))
                }
                return r
            }
        })

        if (!restore()) newTab()
    }

    // ---------- tabs ----------

    private fun makeTab(private: Boolean): BrowserTab {
        val settings = GeckoSessionSettings.Builder().usePrivateMode(private).build()
        val tab = BrowserTab(GeckoSession(settings), private)
        attach(tab)
        tab.session.open(runtime)
        tabs.add(tab)
        return tab
    }

    fun newTab(private: Boolean = false, url: String? = null): BrowserTab {
        val tab = makeTab(private)
        selected = tabs.lastIndex
        if (url != null) openIn(tab, url)
        return tab
    }

    fun select(index: Int) {
        if (index in tabs.indices) {
            selected = index
            ensureLoaded(current)
        }
    }

    private fun ensureLoaded(tab: BrowserTab) {
        val p = tab.pending ?: return
        tab.pending = null
        tab.session.loadUri(p)
    }

    fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs[index]
        if (!tab.isPrivate && !tab.showHome && tab.url.isNotBlank()) {
            closedUrls.add(tab.url)
            while (closedUrls.size > 10) closedUrls.removeAt(0)
        }
        val wasSelected = index == selected
        tabs.removeAt(index)
        if (tabs.isEmpty()) {
            toClose.add(tab.session)
            newTab()
            return
        }
        selected = when {
            selected > index -> selected - 1
            selected >= tabs.size -> tabs.lastIndex
            else -> selected
        }
        ensureLoaded(current)
        if (wasSelected) toClose.add(tab.session) else tab.session.close()
    }

    /** Called by the view after it has switched to the current session. */
    fun flushClosed() {
        if (toClose.isEmpty()) return
        val keep = current.session
        toClose.filter { it !== keep }.forEach { it.close() }
        toClose.clear()
    }

    fun togglePin(tab: BrowserTab) {
        val cur = current
        tab.pinned = !tab.pinned
        tabs.remove(tab)
        val pinnedCount = tabs.count { it.pinned }
        tabs.add(if (tab.pinned) pinnedCount.coerceAtMost(tabs.size) else tabs.size, tab)
        selected = tabs.indexOf(cur).coerceAtLeast(0)
    }

    fun setGroup(tab: BrowserTab, name: String) { tab.group = name.trim() }

    fun groupNames(): List<String> = tabs.map { it.group }.filter { it.isNotBlank() }.distinct()

    fun toggleDesktop(tab: BrowserTab) {
        tab.desktop = !tab.desktop
        val s = tab.session.settings
        s.setUserAgentMode(
            if (tab.desktop) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        )
        s.setViewportMode(
            if (tab.desktop) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        )
        tab.session.reload()
    }

    fun load(input: String) = openIn(current, input)

    private fun openIn(tab: BrowserTab, input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        tab.showHome = false
        tab.pending = null
        tab.session.loadUri(resolve(t))
    }

    // ---------- restore / save ----------

    fun saveTabs() {
        val keep = tabs.filter { !it.isPrivate }
        val arr = JSONArray()
        keep.forEach {
            arr.put(
                JSONObject().put("url", if (it.showHome) "" else it.url).put("title", it.title)
                    .put("pinned", it.pinned).put("group", it.group)
            )
        }
        prefs.savedTabs = arr.toString()
        prefs.savedSelected = keep.indexOf(current).coerceAtLeast(0)
    }

    private fun restore(): Boolean {
        val json = prefs.savedTabs
        if (json.isBlank()) return false
        try {
            val arr = JSONArray(json)
            if (arr.length() == 0) return false
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = makeTab(false)
                t.url = o.getString("url")
                t.title = o.optString("title")
                t.pinned = o.optBoolean("pinned")
                t.group = o.optString("group")
                if (t.url.isNotBlank()) {
                    t.showHome = false
                    t.pending = t.url
                }
            }
            selected = prefs.savedSelected.coerceIn(0, tabs.lastIndex)
            ensureLoaded(current)
            return true
        } catch (e: Exception) {
            return tabs.isNotEmpty()
        }
    }

    // ---------- data ----------

    fun clearBrowsingData(alsoCloseTabs: Boolean) {
        runtime.storageController.clearData(StorageController.ClearFlags.ALL)
        tabs.forEach { it.session.purgeHistory() }
        library.clearHistory()
        library.sitePerms.clear()
        closedUrls.clear()
        if (alsoCloseTabs) {
            val old = tabs.filter { !it.pinned }
            newTab()
            tabs.removeAll(old)
            selected = tabs.lastIndex
            old.forEach { toClose.add(it.session) }
        }
    }

    fun resetSitePerm(p: SitePerm) {
        try {
            val perm = GeckoSession.PermissionDelegate.ContentPermission.fromJson(JSONObject(p.json))
            if (perm != null) {
                runtime.storageController.setPermission(
                    perm, GeckoSession.PermissionDelegate.ContentPermission.VALUE_PROMPT
                )
            }
        } catch (e: Exception) {
        }
        library.removeSitePerm(p)
    }

    // ---------- Gecko delegates ----------

    private fun hostOf(uri: String): String =
        try { Uri.parse(uri).host ?: uri } catch (e: Exception) { uri }

    private fun askContent(perm: GeckoSession.PermissionDelegate.ContentPermission, what: String): GeckoResult<Int> {
        val r = GeckoResult<Int>()
        val host = hostOf(perm.uri)
        permQueue.add(PermRequest(host, what) { allow ->
            library.recordSitePerm(host, what, allow, perm.toJson().toString())
            r.complete(
                if (allow) GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW
                else GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY
            )
        })
        return r
    }

    private fun attach(tab: BrowserTab) {
        tab.session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                tab.loading = true
                tab.blocked = 0
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                tab.loading = false
                if (success && !tab.isPrivate) library.addHistory(tab.url, tab.title)
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                tab.progress = progress
            }
        }

        tab.session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                tab.url = url ?: ""
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                tab.canGoBack = canGoBack
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                tab.canGoForward = canGoForward
            }

            // Links that want a new window open in a new tab; unrequested pop-ups can be dropped.
            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny>? {
                // mailto:, tel:, app links and the like open the matching app, but only after a real tap
                val scheme = try { Uri.parse(request.uri).scheme?.lowercase() } catch (e: Exception) { null }
                if (scheme != null && scheme !in webSchemes) {
                    if (request.hasUserGesture) openExternally(request.uri)
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }
                if (request.target == GeckoSession.NavigationDelegate.TARGET_WINDOW_NEW) {
                    if (request.hasUserGesture || !prefs.on(K_POPUPS)) {
                        newTab(private = tab.isPrivate, url = request.uri)
                    }
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }
                return null
            }
        }

        tab.session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                tab.title = title ?: ""
            }

            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                tab.fullscreen = fullScreen
            }

            override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
                downloader.handle(response)
            }

            override fun onContextMenu(
                session: GeckoSession,
                screenX: Int,
                screenY: Int,
                element: GeckoSession.ContentDelegate.ContextElement
            ) {
                val link = element.linkUri?.takeIf { it.isNotBlank() && !it.startsWith("javascript:") }
                val hasMedia = element.type != GeckoSession.ContentDelegate.ContextElement.TYPE_NONE &&
                    !element.srcUri.isNullOrBlank()
                if (link == null && !hasMedia) return
                contextMenu = ContextInfo(
                    tab.isPrivate,
                    link,
                    if (hasMedia) element.srcUri else null,
                    element.type,
                    element.title,
                    element.altText,
                    element.baseUri
                )
            }
        }

        tab.session.contentBlockingDelegate = object : ContentBlocking.Delegate {
            override fun onContentBlocked(session: GeckoSession, event: ContentBlocking.BlockEvent) {
                tab.blocked++
            }
        }

        tab.session.permissionDelegate = object : GeckoSession.PermissionDelegate {
            override fun onContentPermissionRequest(
                session: GeckoSession,
                perm: GeckoSession.PermissionDelegate.ContentPermission
            ): GeckoResult<Int>? {
                return when (perm.permission) {
                    GeckoSession.PermissionDelegate.PERMISSION_GEOLOCATION ->
                        askContent(perm, "to use your location")
                    GeckoSession.PermissionDelegate.PERMISSION_DESKTOP_NOTIFICATION ->
                        askContent(perm, "to send you notifications")
                    GeckoSession.PermissionDelegate.PERMISSION_PERSISTENT_STORAGE,
                    GeckoSession.PermissionDelegate.PERMISSION_MEDIA_KEY_SYSTEM_ACCESS ->
                        GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW)
                    else -> null
                }
            }

            override fun onMediaPermissionRequest(
                session: GeckoSession,
                uri: String,
                video: Array<GeckoSession.PermissionDelegate.MediaSource>?,
                audio: Array<GeckoSession.PermissionDelegate.MediaSource>?,
                callback: GeckoSession.PermissionDelegate.MediaCallback
            ) {
                val what = when {
                    video != null && audio != null -> "to use your camera and microphone"
                    video != null -> "to use your camera"
                    else -> "to use your microphone"
                }
                permQueue.add(PermRequest(hostOf(uri), what) { allow ->
                    if (allow) callback.grant(video?.firstOrNull(), audio?.firstOrNull()) else callback.reject()
                })
            }

            override fun onAndroidPermissionsRequest(
                session: GeckoSession,
                permissions: Array<String>?,
                callback: GeckoSession.PermissionDelegate.Callback
            ) {
                val ask = androidPermissionRequester
                if (ask == null || permissions == null) {
                    callback.reject()
                } else {
                    ask(permissions) { ok -> if (ok) callback.grant() else callback.reject() }
                }
            }
        }

        tab.session.promptDelegate = object : GeckoSession.PromptDelegate {
            override fun onAlertPrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.AlertPrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
                val r = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                jsDialog = JsDialog(0, prompt.message ?: "", "") { _, _ -> r.complete(prompt.dismiss()) }
                return r
            }

            override fun onButtonPrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.ButtonPrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
                val r = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                jsDialog = JsDialog(1, prompt.message ?: "", "") { ok, _ ->
                    r.complete(
                        prompt.confirm(
                            if (ok) GeckoSession.PromptDelegate.ButtonPrompt.Type.POSITIVE
                            else GeckoSession.PromptDelegate.ButtonPrompt.Type.NEGATIVE
                        )
                    )
                }
                return r
            }

            override fun onTextPrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.TextPrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
                val r = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                jsDialog = JsDialog(2, prompt.message ?: "", prompt.defaultValue ?: "") { ok, text ->
                    r.complete(if (ok) prompt.confirm(text) else prompt.dismiss())
                }
                return r
            }

            override fun onChoicePrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.ChoicePrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
                val r = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                val items = ArrayList<ChoiceItem>()
                fun add(c: GeckoSession.PromptDelegate.ChoicePrompt.Choice) {
                    if (c.separator) return
                    val sub = c.items
                    if (sub != null) {
                        items.add(ChoiceItem(c.id, c.label ?: "", false, true, true))
                        sub.forEach { add(it) }
                    } else {
                        items.add(ChoiceItem(c.id, c.label ?: "", c.selected, c.disabled, false))
                    }
                }
                prompt.choices.forEach { add(it) }
                val multiple = prompt.type == GeckoSession.PromptDelegate.ChoicePrompt.Type.MULTIPLE
                choiceDialog = ChoiceDialog(prompt.message ?: "", multiple, items) { ids ->
                    r.complete(
                        when {
                            ids == null || ids.isEmpty() -> prompt.dismiss()
                            multiple -> prompt.confirm(ids.toTypedArray())
                            else -> prompt.confirm(ids[0])
                        }
                    )
                }
                return r
            }

            override fun onFilePrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.FilePrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
                val ask = filePickerRequester
                val ctx = appContext
                if (ask == null || ctx == null) return GeckoResult.fromValue(prompt.dismiss())
                val r = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                val multiple = prompt.type == GeckoSession.PromptDelegate.FilePrompt.Type.MULTIPLE
                val mimes = (prompt.mimeTypes ?: emptyArray()).filter { it.contains('/') }.toTypedArray()
                ask(multiple, if (mimes.isEmpty()) arrayOf("*/*") else mimes) { uris ->
                    r.complete(
                        when {
                            uris.isEmpty() -> prompt.dismiss()
                            multiple -> prompt.confirm(ctx, uris.toTypedArray())
                            else -> prompt.confirm(ctx, uris[0])
                        }
                    )
                }
                return r
            }

            override fun onLoginSave(
                session: GeckoSession,
                request: GeckoSession.PromptDelegate.AutocompleteRequest<Autocomplete.LoginSaveOption>
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
                if (tab.isPrivate || request.options.isEmpty()) {
                    return GeckoResult.fromValue(request.dismiss())
                }
                val option = request.options[0]
                val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                savePrompt = SavePrompt(
                    option.value.origin ?: "",
                    option.value.username ?: ""
                ) { ok -> result.complete(if (ok) request.confirm(option) else request.dismiss()) }
                return result
            }

            override fun onLoginSelect(
                session: GeckoSession,
                request: GeckoSession.PromptDelegate.AutocompleteRequest<Autocomplete.LoginSelectOption>
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
                if (request.options.isEmpty()) return GeckoResult.fromValue(request.dismiss())
                val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                loginChoice = LoginChoice(
                    request.options[0].value.origin ?: "",
                    request.options.map { it.value.username ?: "(no username)" }
                ) { idx ->
                    result.complete(
                        if (idx == null) request.dismiss() else request.confirm(request.options[idx])
                    )
                }
                return result
            }
        }
    }

    private val webSchemes = setOf(
        "http", "https", "about", "data", "blob", "file", "javascript",
        "moz-extension", "resource", "view-source", "ws", "wss"
    )

    private fun openExternally(u: String) {
        val ctx = appContext ?: return
        try {
            val i = if (u.startsWith("intent:")) {
                Intent.parseUri(u, Intent.URI_INTENT_SCHEME).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    component = null
                    selector = null
                }
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(u))
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "No app can open this link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resolve(t: String): String = when {
        Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*").matches(t) -> t
        t.startsWith("about:") -> t
        !t.contains(' ') && (t.contains('.') || t.startsWith("localhost")) -> "https://$t"
        else -> prefs.searchTemplate().replace("%s", URLEncoder.encode(t, "UTF-8"))
    }
}
