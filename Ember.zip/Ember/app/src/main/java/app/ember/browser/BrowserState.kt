package app.ember.browser

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.StorageController
import java.net.URLEncoder

private const val SEARCH_URL = "https://duckduckgo.com/?q="

private var sRuntime: GeckoRuntime? = null

/** GeckoRuntime must exist exactly once per process. */
fun geckoRuntime(context: Context): GeckoRuntime =
    sRuntime ?: GeckoRuntime.create(context.applicationContext).also { sRuntime = it }

/** One browser tab: a Gecko session plus its observable UI state. */
class Tab(val session: GeckoSession, val isPrivate: Boolean) {
    var showHome by mutableStateOf(true)
    var url by mutableStateOf("")
    var title by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)
    var blocked by mutableIntStateOf(0)
}

class BrowserState(private val runtime: GeckoRuntime, private val prefs: EmberPrefs) {
    val tabs = mutableStateListOf<Tab>()
    var selected by mutableIntStateOf(0)
        private set

    /** Sessions waiting to be closed once the GeckoView has let go of them. */
    private val toClose = mutableListOf<GeckoSession>()

    val current: Tab get() = tabs[selected]

    init {
        newTab()
    }

    fun newTab(private: Boolean = false, url: String? = null): Tab {
        val settings = GeckoSessionSettings.Builder().usePrivateMode(private).build()
        val tab = Tab(GeckoSession(settings), private)
        attach(tab)
        tab.session.open(runtime)
        tabs.add(tab)
        selected = tabs.lastIndex
        if (url != null) openIn(tab, url)
        return tab
    }

    fun select(index: Int) {
        if (index in tabs.indices) selected = index
    }

    fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs[index]
        val wasSelected = index == selected
        tabs.removeAt(index)
        if (tabs.isEmpty()) {
            toClose.add(tab.session)
            newTab()
            return
        }
        selected = when {
            selected > index -> selected - 1
            selected >= tabs.size -> tabs.lastIndex
            else -> selected
        }
        if (wasSelected) toClose.add(tab.session) else tab.session.close()
    }

    /** Called by the view after it has switched to the current session. */
    fun flushClosed() {
        if (toClose.isEmpty()) return
        val keep = current.session
        toClose.filter { it !== keep }.forEach { it.close() }
        toClose.clear()
    }

    fun load(input: String) = openIn(current, input)

    private fun openIn(tab: Tab, input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        tab.showHome = false
        tab.session.loadUri(resolve(t))
    }

    fun clearBrowsingData(alsoCloseTabs: Boolean) {
        runtime.storageController.clearData(StorageController.ClearFlags.ALL)
        tabs.forEach { it.session.purgeHistory() }
        if (alsoCloseTabs) {
            val old = tabs.toList()
            newTab()
            tabs.removeAll(old)
            selected = 0
            old.forEach { toClose.add(it.session) }
        }
    }

    private fun attach(tab: Tab) {
        tab.session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                tab.loading = true
                tab.blocked = 0
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                tab.loading = false
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                tab.progress = progress
            }
        }

        tab.session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                tab.url = url ?: ""
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                tab.canGoBack = canGoBack
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                tab.canGoForward = canGoForward
            }

            // Links that want a new window open in a new tab; unrequested pop-ups can be dropped.
            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny>? {
                if (request.target == GeckoSession.NavigationDelegate.TARGET_WINDOW_NEW) {
                    if (request.hasUserGesture || !prefs.on(K_POPUPS)) {
                        newTab(private = tab.isPrivate, url = request.uri)
                    }
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }
                return null
            }
        }

        tab.session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                tab.title = title ?: ""
            }
        }

        tab.session.contentBlockingDelegate = object : ContentBlocking.Delegate {
            override fun onContentBlocked(session: GeckoSession, event: ContentBlocking.BlockEvent) {
                tab.blocked++
            }
        }
    }

    private fun resolve(t: String): String = when {
        Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*").matches(t) -> t
        t.startsWith("about:") -> t
        !t.contains(' ') && (t.contains('.') || t.startsWith("localhost")) -> "https://$t"
        else -> SEARCH_URL + URLEncoder.encode(t, "UTF-8")
    }
}
