package app.ember.browser

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    prefs: EmberPrefs,
    onShieldChanged: () -> Unit,
    onOpenUblock: () -> Unit,
    onAddons: () -> Unit,
    onSitePerms: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
                .padding(bottom = 24.dp)
        ) {
            Text("Ad-free shield", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            ShieldSwitches(prefs, onShieldChanged)
            OutlinedButton(onClick = onOpenUblock) { Text("Open uBlock dashboard") }

            Spacer(Modifier.height(20.dp))
            Text("Privacy", style = MaterialTheme.typography.titleLarge)
            ToggleList(PrivacyToggles, prefs, onShieldChanged)
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onSitePerms) { Text("Site permissions") }
                FilledTonalButton(onClick = onAddons) { Text("Add-ons") }
            }

            Spacer(Modifier.height(20.dp))
            Text("Browsing", style = MaterialTheme.typography.titleLarge)
            ToggleList(BrowsingToggles, prefs, onShieldChanged)

            Spacer(Modifier.height(20.dp))
            EngineSection(prefs)

            Spacer(Modifier.height(20.dp))
            Text("Appearance", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            ColourControls(prefs)
        }
    }
}

@Composable
private fun EngineSection(prefs: EmberPrefs) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    Text("Search engine", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(4.dp))
    prefs.engines().forEachIndexed { i, e ->
        Row(
            Modifier.fillMaxWidth().clickable { prefs.updateEngine(i) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = prefs.engine == i, onClick = { prefs.updateEngine(i) })
            Text(e.name, Modifier.weight(1f))
            if (i >= BuiltInEngines.size) {
                TextButton(onClick = { prefs.removeEngine(i) }) { Text("Remove") }
            }
        }
    }

    Spacer(Modifier.height(12.dp))
    Text("Add your own", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(6.dp))
    OutlinedTextField(
        value = name,
        onValueChange = { name = it },
        label = { Text("Name") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(
        value = url,
        onValueChange = { url = it },
        label = { Text("Address, with %s where the search goes") },
        placeholder = { Text("https://example.com/search?q=%s") },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
        modifier = Modifier.fillMaxWidth()
    )
    Spacer(Modifier.height(8.dp))
    FilledTonalButton(onClick = {
        if (prefs.addEngine(name, url)) {
            name = ""
            url = ""
            error = false
        } else {
            error = true
        }
    }) { Text("Add search engine") }
    if (error) {
        Text(
            "It needs a name and an http(s) address that contains %s.",
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
