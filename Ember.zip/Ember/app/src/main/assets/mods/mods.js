(function () {
  "use strict";
  if (window.top !== window) return;
  var applied = "";

  function put(css) {
    var root = document.head || document.documentElement;
    if (!root) return;
    var old = document.getElementById("ember-mods-css");
    if (old) old.remove();
    if (!css) return;
    var style = document.createElement("style");
    style.id = "ember-mods-css";
    style.textContent = css;
    root.appendChild(style);
    if (!style.sheet) {
      // some pages refuse inline styles; a constructed stylesheet gets around that
      try {
        var sheet = new CSSStyleSheet();
        sheet.replaceSync(css);
        document.adoptedStyleSheets = document.adoptedStyleSheets.concat([sheet]);
      } catch (e) { /* ignore */ }
    }
  }

  browser.runtime.sendMessage({ type: "get-css", url: location.href }).then(function (res) {
    if (!res || !res.css) return;
    applied = res.css;
    put(applied);
    // pages that rebuild <head> lose the style; put it back
    new MutationObserver(function () {
      if (applied && !document.getElementById("ember-mods-css")) put(applied);
    }).observe(document.documentElement, { childList: true });
  }).catch(function () { /* ignore */ });
})();
