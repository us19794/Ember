// Pages ask for their mod styles; the app (Ember) answers with the CSS of every enabled mod that matches.
browser.runtime.onMessage.addListener(function (msg) {
  if (msg && msg.type === "get-css") {
    return browser.runtime
      .sendNativeMessage("ember", { type: "css", url: msg.url })
      .catch(function () { return { css: "" }; });
  }
});
