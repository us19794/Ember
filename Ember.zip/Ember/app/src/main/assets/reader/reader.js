(function () {
  "use strict";
  if (window.top !== window || window.__emberReader) return;
  window.__emberReader = true;

  var THEMES = {
    dark:  { bg: "#0b0b0b", fg: "#e8e8e8", mute: "#9a9a9a", link: "#ff8a57", bar: "#1a1a1a" },
    sepia: { bg: "#f4ecd8", fg: "#3b3226", mute: "#7a6b55", link: "#a8481e", bar: "#e6dcc2" },
    light: { bg: "#ffffff", fg: "#1a1a1a", mute: "#666666", link: "#b3401a", bar: "#eeeeee" }
  };
  var ORDER = ["dark", "sepia", "light"];
  var themeName = "dark";
  var size = 19;
  var pill = null;
  var overlay = null;

  function el(tag, css, text) {
    var e = document.createElement(tag);
    if (css) e.style.cssText = css;
    if (text) e.textContent = text;
    return e;
  }

  function showPill() {
    if (pill || document.getElementById("ember-reader-pill")) return;
    pill = el("button",
      "position:fixed;right:0;top:62%;z-index:2147483646;padding:10px 14px 10px 16px;border:0;" +
      "border-radius:22px 0 0 22px;background:#ff6a2b;color:#111;font:600 14px Georgia,serif;" +
      "opacity:.92;box-shadow:0 2px 10px rgba(0,0,0,.4);", "Reader");
    pill.id = "ember-reader-pill";
    pill.addEventListener("click", openReader);
    (document.body || document.documentElement).appendChild(pill);
  }

  function openReader() {
    var article = null;
    try { article = new Readability(document.cloneNode(true)).parse(); } catch (e) { article = null; }
    if (!article || !article.content || (article.textContent || "").trim().length < 80) {
      pill.textContent = "No article here";
      setTimeout(function () { pill.textContent = "Reader"; }, 1600);
      return;
    }
    buildOverlay(article);
  }

  function buildOverlay(article) {
    overlay = el("div");
    overlay.id = "ember-reader-overlay";
    var style = el("style");
    var bar = el("div");
    var wrap = el("div");
    var title = el("h1", "", article.title || document.title);
    var meta = el("div", "", [article.byline, article.siteName].filter(Boolean).join(" · "));
    var content = el("div");
    content.innerHTML = article.content;

    function button(label, fn) {
      var b = el("button", "border:0;border-radius:16px;padding:7px 14px;margin-right:8px;font:600 13px Georgia,serif;background:rgba(127,127,127,.25);color:inherit;", label);
      b.addEventListener("click", fn);
      return b;
    }
    bar.appendChild(button("Smaller", function () { size = Math.max(14, size - 1); apply(); }));
    bar.appendChild(button("Larger", function () { size = Math.min(30, size + 1); apply(); }));
    bar.appendChild(button("Theme", function () {
      themeName = ORDER[(ORDER.indexOf(themeName) + 1) % ORDER.length]; apply();
    }));
    bar.appendChild(button("Close", close));

    wrap.appendChild(title);
    wrap.appendChild(meta);
    wrap.appendChild(content);
    overlay.appendChild(style);
    overlay.appendChild(bar);
    overlay.appendChild(wrap);

    function apply() {
      var t = THEMES[themeName];
      overlay.style.cssText = "position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483647;overflow:auto;" +
        "-webkit-overflow-scrolling:touch;background:" + t.bg + ";color:" + t.fg + ";";
      bar.style.cssText = "position:sticky;top:0;padding:10px 14px;background:" + t.bar + ";color:" + t.fg + ";z-index:1;";
      wrap.style.cssText = "max-width:680px;margin:0 auto;padding:18px 22px 200px;font:" + size + "px/1.65 Georgia,'Noto Serif',serif;";
      meta.style.cssText = "color:" + t.mute + ";font-size:.8em;margin-bottom:1.2em;";
      style.textContent =
        "#ember-reader-overlay a{color:" + t.link + "}" +
        "#ember-reader-overlay h1{font-size:1.6em;line-height:1.25;margin:.6em 0 .3em}" +
        "#ember-reader-overlay img,#ember-reader-overlay video,#ember-reader-overlay figure{max-width:100%;height:auto}" +
        "#ember-reader-overlay pre{white-space:pre-wrap;overflow:auto}" +
        "#ember-reader-overlay blockquote{border-left:3px solid " + t.mute + ";margin-left:0;padding-left:1em;color:" + t.mute + "}";
    }

    function close() {
      if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
      document.documentElement.style.overflow = "";
      overlay = null;
    }

    apply();
    document.documentElement.style.overflow = "hidden";
    document.documentElement.appendChild(overlay);
  }

  function ensure() {
    try {
      if (overlay) return;
      if (document.contentType && document.contentType !== "text/html") return;
      if (!document.body) return;
      if (!document.getElementById("ember-reader-pill")) {
        pill = null;
        showPill();
      }
    } catch (e) { /* ignore */ }
  }

  ensure();
  setTimeout(ensure, 1500);
  setInterval(ensure, 3000);
})();
