# Ember

Gecko-based (Firefox engine) web browser for Android. arm64 only.

Build: push this folder to a GitHub repo (workflow lives in `.github/workflows/build.yml`,
also provided as `project.yml`), run **Actions > Build Ember APK**, download the `Ember-debug-apk` artifact.
Local: `gradle :app:assembleDebug` (Gradle 8.10+, JDK 17).

Set as default: open Ember > menu > "Set as default browser".
Bump the engine in `app/build.gradle.kts` (`geckoVersion`).
