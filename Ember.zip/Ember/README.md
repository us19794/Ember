# Ember

Gecko-based (Firefox engine) web browser for Android. arm64 only. Ships uBlock Origin (bundled in app/src/main/assets/ublock).

- Serif typography, Material 3, dot-matrix (Nothing-style) icons
- Home page with a haptic fidget spinner and a customisable colour scheme
- Default-browser ready (menu > "Set as default browser")

Build: push this folder to GitHub (workflow: `.github/workflows/build.yml`, also shipped as `project.yml`),
run **Actions > Build Ember APK**, download the `Ember-debug-apk` artifact.
Local: `gradle :app:assembleDebug` (Gradle 8.13+, JDK 17, Android SDK 36).
Engine version: `geckoVersion` in `app/build.gradle.kts`.
